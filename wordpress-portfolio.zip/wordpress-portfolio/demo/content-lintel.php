<?php
/**
 * Demo content for Lintel: Kingpost Engineering, a fictional civil and
 * structural engineering firm in Port Harcourt.
 *
 * @package WordPress_Portfolio
 */

/**
 * Creates the Lintel demo site.
 *
 * @return void
 */
function portfolio_demo_lintel() {
	update_option( 'blogname', 'Kingpost Engineering' );
	update_option( 'blogdescription', 'Civil and structural engineering, Port Harcourt' );

	// Services, in the order they should appear.
	$services = array(
		array(
			'title'   => 'Geotechnical investigation',
			'excerpt' => 'Boreholes, soil tests and foundation advice for soft and waterlogged ground.',
			'body'    => array(
				array( 'p', 'Most foundation problems start before the first concrete pour, with assumptions about the ground. We drill, sample and test so the design starts from measured soil properties rather than guesses.' ),
				array( 'h2', 'What the investigation covers' ),
				array( 'checklist', array( 'Boreholes and cone penetration tests to the depth the loads demand', 'Laboratory tests for strength, consolidation and chemistry', 'Groundwater levels through the wet season', 'A written foundation recommendation with options and costs' ), 'lintel-checklist' ),
				array( 'p', 'Reports are signed by a registered geotechnical engineer and written so that a client, not just another engineer, can follow the reasoning.' ),
			),
		),
		array(
			'title'   => 'Structural design',
			'excerpt' => 'Calculations and drawings for buildings, bridges and industrial structures, each one independently checked.',
			'body'    => array(
				array( 'p', 'We design in reinforced concrete, structural steel and timber, to British and Eurocode standards as the client and the approving authority require.' ),
				array( 'p', 'Every design is checked by a second engineer who did not prepare it. The check is recorded on the drawing register and nothing is issued for construction until it is signed.' ),
			),
		),
		array(
			'title'   => 'Foundations and piling',
			'excerpt' => 'Bored and driven piles, rafts and ground improvement for heavy loads on weak soil.',
			'body'    => array(
				array( 'p', 'Our own rigs install bored piles up to 900 mm diameter and 30 m deep, with integrity testing on every pile before the caps are cast.' ),
			),
		),
		array(
			'title'   => 'Roads and drainage',
			'excerpt' => 'Road pavements and drainage sized for the heavy rainfall of the Niger Delta.',
			'body'    => array(
				array( 'p', 'We design drainage first and the road second, because water is what destroys roads here. Culverts and channels are sized from local rainfall records, with room for the storms that are getting heavier.' ),
			),
		),
		array(
			'title'   => 'Marine and jetty works',
			'excerpt' => 'Jetties, slipways and shore protection along creeks and rivers.',
			'body'    => array(
				array( 'p', 'Tidal work needs careful sequencing and the right protection against corrosion. We plan piling around the tide tables and specify coatings and cover for a 50-year life in salt water.' ),
			),
		),
		array(
			'title'   => 'Building construction',
			'excerpt' => 'Design and build of offices, warehouses and schools, delivered by our own site teams.',
			'body'    => array(
				array( 'p', 'One contract covers design, construction and a twelve-month defects period, so there is no gap between the people who draw a building and the people who build it.' ),
			),
		),
	);

	$service_links = array();

	foreach ( $services as $order => $service ) {
		$service_id      = portfolio_demo_insert(
			array(
				'post_type'    => 'gw_service',
				'post_title'   => $service['title'],
				'post_excerpt' => $service['excerpt'],
				'post_content' => portfolio_demo_blocks( $service['body'] ),
				'menu_order'   => $order + 1,
			)
		);
		$service_links[] = array(
			'title' => $service['title'],
			'url'   => get_permalink( $service_id ),
		);
	}

	// Project types and projects, newest first.
	$types = array();
	foreach ( array( 'Bridges and roads', 'Buildings', 'Marine and drainage', 'Industrial' ) as $type ) {
		$types[ $type ] = portfolio_demo_term( $type, 'gw_project_type' );
	}

	$projects = array(
		array(
			'title'    => 'Woji Creek Footbridge',
			'type'     => 'Bridges and roads',
			'image'    => 'woji-creek-footbridge.png',
			'date'     => '2026-09-18 10:00:00',
			'summary'  => 'A 24 m steel truss footbridge that links two halves of a new housing estate across a tidal creek.',
			'meta'     => array( 'Private estate developer', 'Woji, Port Harcourt', '2026', 'Design and build', '9 months', 'completed' ),
			'brief'    => 'Residents were walking a 2 km detour to reach the school and the market on the other side of the creek. The developer needed a crossing that would not obstruct small boats and could be installed without working in the water.',
			'approach' => 'We chose a Warren truss that could be fabricated in our yard in two halves, galvanised, and lifted onto the abutments in a single day. The abutments sit on bored piles taken into the dense sand below the creek mud.',
			'outcome'  => 'The bridge opened two weeks ahead of programme. Around 1,500 people cross it every day, and the developer has asked us to design the estate\'s second crossing.',
		),
		array(
			'title'    => 'Trans-Amadi Warehouse Foundations',
			'type'     => 'Industrial',
			'image'    => 'trans-amadi-warehouse-foundations.png',
			'date'     => '2026-06-02 10:00:00',
			'summary'  => 'Piled foundations and a ground-bearing slab for a 6,000 m² distribution warehouse on reclaimed land.',
			'meta'     => array( 'Logistics company', 'Trans-Amadi, Port Harcourt', '2025', 'Piling and ground slab', '5 months', 'completed' ),
			'brief'    => 'The site had been raised with fill over soft clay. The client needed a slab that could carry high racking without the settlement cracks that had damaged their previous warehouse.',
			'approach' => 'Boreholes showed 9 m of compressible clay. We installed 214 bored piles to the sand below and designed a suspended slab, so the racking loads never rest on the clay.',
			'outcome'  => 'Two years on, level surveys show less than 3 mm of movement across the slab. The racking has been fully loaded since handover.',
		),
		array(
			'title'    => 'Rumuokoro Drainage Upgrade',
			'type'     => 'Marine and drainage',
			'image'    => 'rumuokoro-drainage-upgrade.png',
			'date'     => '2026-03-12 10:00:00',
			'summary'  => '2.1 km of twin-cell box culverts under a busy road that used to flood after every heavy storm.',
			'meta'     => array( 'State public works agency', 'Rumuokoro, Port Harcourt', '2025', 'Design and construction', '11 months', 'completed' ),
			'brief'    => 'The existing open drains were undersized and blocked, and the road flooded to knee depth several times each rainy season. Traffic had to keep moving throughout the works.',
			'approach' => 'We sized the culverts from 30 years of local rainfall data, then built them in 60 m sections at night, so two lanes stayed open every day.',
			'outcome'  => 'The road has not flooded since the culverts were completed, including during the heaviest storm of the following season.',
		),
		array(
			'title'    => 'Onne Service Jetty',
			'type'     => 'Marine and drainage',
			'image'    => 'onne-service-jetty.png',
			'date'     => '2025-11-20 10:00:00',
			'summary'  => 'A 60 m piled jetty where supply boats load and unload at any state of the tide.',
			'meta'     => array( 'Marine services company', 'Onne, Rivers State', '2024', 'Design, piling and deck', '14 months', 'completed' ),
			'brief'    => 'The client\'s boats could only berth for four hours around high tide. They needed a jetty long enough to reach deep water and strong enough for a mobile crane.',
			'approach' => 'Steel tubular piles were driven from a floating rig, then capped with precast deck units to keep work over the water short and safe.',
			'outcome'  => 'Boats now berth around the clock, and the client has cut average turnaround time by more than half.',
		),
		array(
			'title'    => 'Eleme School Block',
			'type'     => 'Buildings',
			'image'    => 'eleme-school-block.png',
			'date'     => '2025-08-05 10:00:00',
			'summary'  => 'A two-storey, twelve-classroom block designed and built for a community trust.',
			'meta'     => array( 'Community trust', 'Eleme, Rivers State', '2025', 'Design and build', '10 months', 'completed' ),
			'brief'    => 'The trust had a fixed budget and wanted a building that would stay cool without air conditioning and need little maintenance.',
			'approach' => 'Deep roof overhangs, cross ventilation and a raft foundation suited to the site\'s variable soil kept both the running and the building costs down.',
			'outcome'  => 'The block was finished within budget and is now used by 480 pupils.',
		),
		array(
			'title'    => 'Bonny Island Tank Bases',
			'type'     => 'Industrial',
			'image'    => 'bonny-island-tank-bases.png',
			'date'     => '2025-05-14 10:00:00',
			'summary'  => 'Ring-wall foundations for three 30 m diameter storage tanks on a coastal site.',
			'meta'     => array( '', 'Bonny Island, Rivers State', '2026', 'Foundation design and construction', '7 months', 'in-progress' ),
			'brief'    => 'The tanks needed foundations that would tolerate settlement under a full hydrotest without distorting the tank shells.',
			'approach' => 'We designed reinforced concrete ring walls on improved ground and are monitoring settlement through each stage of filling.',
			'outcome'  => 'The first two bases have passed hydrotest within the settlement limits. The third is under construction.',
		),
	);

	$meta_keys = array( '_gw_client', '_gw_location', '_gw_year', '_gw_scope', '_gw_duration', '_gw_status' );

	foreach ( $projects as $order => $project ) {
		$project_id = portfolio_demo_insert(
			array(
				'post_type'    => 'gw_project',
				'post_title'   => $project['title'],
				'post_excerpt' => $project['summary'],
				'post_date'    => $project['date'],
				'menu_order'   => $order,
				'meta_input'   => array_combine( $meta_keys, $project['meta'] ),
				'post_content' => portfolio_demo_blocks(
					array(
						array( 'h2', 'The brief' ),
						array( 'p', $project['brief'] ),
						array( 'h2', 'Our approach' ),
						array( 'p', $project['approach'] ),
						array( 'h2', 'Outcome' ),
						array( 'p', $project['outcome'] ),
					)
				),
			)
		);

		wp_set_object_terms( $project_id, array( $types[ $project['type'] ] ), 'gw_project_type' );
		portfolio_demo_image( $project['image'], 'General arrangement drawing of the ' . $project['title'], $project_id );
	}

	// Testimonials.
	$testimonials = array(
		array( 'Chiamaka Eze', 'Development manager', 'Private estate developer', 'They found the soft layer our first contractor missed, redesigned the foundations and still finished early. The weekly reports meant I never had to chase anyone for an update.' ),
		array( 'Ibrahim Danjuma', 'Facilities manager', 'Logistics company', 'The slab has carried full racking for two years without a crack. When we call about anything, the engineer who designed it picks up the phone.' ),
		array( 'Tamuno Briggs', 'Project officer', 'Community trust', 'They explained every decision to our board in plain language and kept the site safe for the children next door.' ),
	);

	foreach ( $testimonials as $order => $testimonial ) {
		portfolio_demo_insert(
			array(
				'post_type'    => 'gw_testimonial',
				'post_title'   => $testimonial[0],
				'post_content' => portfolio_demo_blocks( array( array( 'p', $testimonial[3] ) ) ),
				'menu_order'   => $order,
				'meta_input'   => array(
					'_gw_role'         => $testimonial[1],
					'_gw_organisation' => $testimonial[2],
				),
			)
		);
	}

	// Articles.
	$author   = portfolio_demo_author( 'tari', 'Tari Pepple', 'Senior structural engineer at Kingpost Engineering.' );
	$category = portfolio_demo_term( 'Engineering notes', 'category' );
	$articles = array(
		array(
			'title'   => 'Why soft ground changes the foundation design',
			'date'    => '2026-10-20 09:00:00',
			'excerpt' => 'The same building can need a strip footing on one site and 200 piles on the next. The difference is under the surface.',
			'body'    => array(
				array( 'p', 'Clients are often surprised that two identical buildings a few kilometres apart can need completely different foundations. The building is the same; the ground is not.' ),
				array( 'h2', 'What makes ground soft' ),
				array( 'p', 'Much of Port Harcourt sits on recent river and creek deposits: clays and silts that were laid down under water and still hold a lot of it. Under load they squeeze slowly, sometimes for years, and a building on top settles with them.' ),
				array( 'h2', 'The three common answers' ),
				array( 'ul', array( 'A raft, which spreads the load so the pressure on the soil stays low', 'Ground improvement, which strengthens the soil before building', 'Piles, which carry the load through the soft layer to firmer ground below' ) ),
				array( 'p', 'Which one is right depends on how deep the soft layer goes, how heavy the building is and how much movement it can tolerate. A site investigation answers the first question; the design answers the other two.' ),
				array( 'h2', 'Why it is worth testing first' ),
				array( 'p', 'A borehole costs a small fraction of a foundation, and it is the only way to know which of the three answers you need. Skipping it is the most expensive saving on any project.' ),
			),
		),
		array(
			'title'   => 'Sizing drains for 2,400 mm of rain a year',
			'date'    => '2026-09-08 09:00:00',
			'excerpt' => 'Port Harcourt gets about three times London\'s annual rainfall, much of it in short, heavy bursts. Drains have to be designed for the bursts.',
			'body'    => array(
				array( 'p', 'Annual totals tell you how wet a place is. They do not tell you how big a drain needs to be. For that you need the intensity of the worst storms you plan to handle.' ),
				array( 'h2', 'Start from storms, not averages' ),
				array( 'p', 'We size drains from rainfall intensity records for storms of different return periods: how much rain falls in 15 minutes, an hour or a day in a storm expected once every 10, 25 or 50 years.' ),
				array( 'h2', 'Leave room for change' ),
				array( 'p', 'Heavy storms are becoming more frequent. On public roads we add an allowance to the design intensity and check what happens when a drain is overwhelmed, so the water goes somewhere harmless.' ),
			),
		),
		array(
			'title'   => 'What to prepare before an engineer\'s site visit',
			'date'    => '2026-08-14 09:00:00',
			'excerpt' => 'Five things that turn a first site visit into a useful one.',
			'body'    => array(
				array( 'p', 'A first visit is most useful when the engineer can see the site and the paperwork together. These five things make the biggest difference.' ),
				array( 'checklist', array( 'The survey plan or title documents showing the boundaries', 'Any existing drawings, even old or incomplete ones', 'A rough idea of the budget and the date you need the building', 'Photos of the site in the rainy season, if the visit is in the dry season', 'Contact details for anyone who must approve the work' ), 'lintel-checklist' ),
				array( 'p', 'None of these are required. If you do not have them, we will tell you which ones matter for your project and how to get them.' ),
			),
		),
		array(
			'title'   => 'Protecting steel structures near salt water',
			'date'    => '2026-07-02 09:00:00',
			'excerpt' => 'On the coast, corrosion protection decides how long a steel structure lasts.',
			'body'    => array(
				array( 'p', 'Steel near salt water can lose a millimetre of thickness every few years if it is left unprotected. On a jetty pile, that adds up quickly.' ),
				array( 'h2', 'Layers of protection' ),
				array( 'p', 'We combine sacrificial steel thickness, coatings and, where the structure is long-lived, cathodic protection. Each layer covers the weaknesses of the others.' ),
				array( 'p', 'The splash zone, where waves wet and dry the steel all day, is the hardest place to protect, so it gets the thickest coating and the closest inspection.' ),
			),
		),
	);

	foreach ( $articles as $article ) {
		portfolio_demo_insert(
			array(
				'post_title'    => $article['title'],
				'post_excerpt'  => $article['excerpt'],
				'post_date'     => $article['date'],
				'post_author'   => $author,
				'post_content'  => portfolio_demo_blocks( $article['body'] ),
				'post_category' => array( $category ),
			)
		);
	}

	// Pages.
	$home = portfolio_demo_insert(
		array(
			'post_type'    => 'page',
			'post_title'   => 'Home',
			'post_content' => portfolio_demo_pattern( 'lintel', 'process' ) . "\n\n" . portfolio_demo_pattern( 'lintel', 'safety-record' ),
		)
	);

	$about = portfolio_demo_insert(
		array(
			'post_type'    => 'page',
			'post_title'   => 'About',
			'post_excerpt' => 'A civil and structural engineering firm that designs, builds and maintains, so one team answers for the whole structure.',
			'post_content' => portfolio_demo_pattern( 'lintel', 'about' ) . "\n\n" . portfolio_demo_pattern( 'lintel', 'faq' ),
		)
	);

	$contact = portfolio_demo_insert(
		array(
			'post_type'    => 'page',
			'post_title'   => 'Contact',
			'post_excerpt' => 'Tell us about your site. An engineer will reply within two working days.',
			'post_content' => portfolio_demo_pattern( 'lintel', 'contact' ),
		)
	);

	$insights = portfolio_demo_insert(
		array(
			'post_type'    => 'page',
			'post_title'   => 'Insights',
			'post_excerpt' => 'Notes from our engineers on ground, water and building in the Niger Delta.',
		)
	);

	portfolio_demo_privacy_page( 'Kingpost Engineering is a fictional company created to demonstrate the Lintel theme. This page shows where a real privacy policy would go.' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home );
	update_option( 'page_for_posts', $insights );

	// Menus.
	portfolio_demo_menu(
		'Main',
		'primary',
		array(
			array(
				'title'    => 'Services',
				'url'      => home_url( '/services/' ),
				'children' => $service_links,
			),
			array(
				'title' => 'Projects',
				'url'   => home_url( '/projects/' ),
			),
			array(
				'title' => 'About',
				'url'   => get_permalink( $about ),
			),
			array(
				'title' => 'Insights',
				'url'   => get_permalink( $insights ),
			),
		)
	);

	portfolio_demo_menu(
		'Footer',
		'footer',
		array(
			array(
				'title' => 'About',
				'url'   => get_permalink( $about ),
			),
			array(
				'title' => 'Projects',
				'url'   => home_url( '/projects/' ),
			),
			array(
				'title' => 'Insights',
				'url'   => get_permalink( $insights ),
			),
			array(
				'title' => 'Contact',
				'url'   => get_permalink( $contact ),
			),
		)
	);

	// Theme options.
	$mods = array(
		'lintel_cta_url'      => get_permalink( $contact ),
		'lintel_phone'        => '+234 84 000 0000',
		'lintel_email'        => 'projects@example.com',
		'lintel_address'      => "12 Example Road, Trans-Amadi\nPort Harcourt, Rivers State",
		'lintel_hours'        => 'Monday to Friday, 8am to 5pm',
		'lintel_registration' => 'RC 1234567',
	);

	foreach ( $mods as $name => $value ) {
		set_theme_mod( $name, $value );
	}
}
