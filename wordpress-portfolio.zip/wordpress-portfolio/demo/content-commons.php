<?php
/**
 * Demo content for Commons: Creekside Mangrove Trust, a fictional
 * non-profit in Rivers State.
 *
 * @package WordPress_Portfolio
 */

/**
 * Creates the Commons demo site.
 *
 * @return void
 */
function portfolio_demo_commons() {
	update_option( 'blogname', 'Creekside Mangrove Trust' );
	update_option( 'blogdescription', 'Mangrove restoration and youth training in Rivers State' );

	$author   = portfolio_demo_author( 'ibiso', 'Ibiso Jack', 'Programme lead at Creekside Mangrove Trust.' );
	$category = portfolio_demo_term( 'From the creeks', 'category' );

	$stories = array(
		array(
			'title'   => 'Fourteen nurseries and counting',
			'date'    => '2026-10-02 09:00:00',
			'image'   => 'story-nurseries.png',
			'excerpt' => 'Each community nursery is run by local volunteers. Here is how a new one gets started.',
			'body'    => array(
				array( 'p', 'A nursery starts with a conversation, not a shovel. Before any seedlings arrive, we meet the community, agree where the nursery will sit and who will look after it.' ),
				array( 'h2', 'What a nursery needs' ),
				array( 'ul', array( 'Shade and a fresh water source', 'A team of at least six volunteers', 'A stretch of creek bank where the seedlings will be planted' ) ),
				array( 'p', 'Seedlings stay in the nursery for four to six months, until their roots can hold against the tide.' ),
			),
		),
		array(
			'title'   => 'A week with the youth rangers',
			'date'    => '2026-09-14 09:00:00',
			'image'   => 'story-rangers.png',
			'excerpt' => 'Boat safety on Monday, seedling counts on Wednesday and a clean-up on Saturday.',
			'body'    => array(
				array( 'p', 'Rangers are paid for every day they work, because training should not cost young people the income they would otherwise earn.' ),
				array( 'p', 'Most weeks mix classroom sessions with time on the water: counting surviving seedlings, mapping erosion and teaching visiting school groups.' ),
			),
		),
		array(
			'title'   => 'Why mangroves matter for the fish on your plate',
			'date'    => '2026-08-03 09:00:00',
			'image'   => 'story-fish.png',
			'excerpt' => 'Mangrove roots are nurseries for fish, crabs and shrimp. Lose the trees and the catch follows.',
			'body'    => array(
				array( 'p', 'Young fish shelter among mangrove roots until they are big enough for open water. Where the trees are cut, fishers report smaller and fewer catches within a few seasons.' ),
				array( 'quote', 'The fish came back to our side of the creek two years after the planting.' ),
				array( 'p', 'Replanting is slow, but the fishers we work with are already measuring the difference.' ),
			),
		),
		array(
			'title'   => 'Our 2025 annual report',
			'date'    => '2026-06-20 09:00:00',
			'image'   => 'story-report.png',
			'excerpt' => 'Audited accounts, what we planted and what we learned from the seedlings that did not survive.',
			'body'    => array(
				array( 'p', 'The report covers every naira we received and spent, checked by an independent auditor.' ),
				array( 'p', 'We also report what went wrong. A third of the seedlings planted on one site were lost to a late storm, and we have changed how we choose planting dates as a result.' ),
			),
		),
	);

	foreach ( $stories as $story ) {
		$story_id = portfolio_demo_insert(
			array(
				'post_title'    => $story['title'],
				'post_excerpt'  => $story['excerpt'],
				'post_date'     => $story['date'],
				'post_author'   => $author,
				'post_content'  => portfolio_demo_blocks( $story['body'] ),
				'post_category' => array( $category ),
			)
		);

		portfolio_demo_image( $story['image'], '', $story_id );
	}

	$home_patterns = array( 'hero', 'programmes', 'impact', 'quote', 'get-involved', 'latest-stories' );

	$home = portfolio_demo_insert(
		array(
			'post_type'    => 'page',
			'post_title'   => 'Home',
			'post_content' => implode( "\n\n", array_map( 'portfolio_demo_commons_pattern', $home_patterns ) ),
			'meta_input'   => array( '_wp_page_template' => 'page-no-title' ),
		)
	);

	$about = portfolio_demo_insert(
		array(
			'post_type'    => 'page',
			'post_title'   => 'About',
			'post_excerpt' => 'We started in 2016 when twelve fishers asked for help replanting the mangroves on their creek.',
			'post_content' => portfolio_demo_blocks(
				array(
					array( 'p', 'Creekside Mangrove Trust is a registered charity based in Port Harcourt. We work in partnership with fourteen creek communities, who choose where to plant and run the nurseries themselves.' ),
					array( 'h2', 'How we work' ),
					array( 'ul', array( 'Communities decide where and when to plant', 'Young people are paid for the work they do', 'Every figure we publish is independently audited' ) ),
				)
			) . "\n\n" . portfolio_demo_commons_pattern( 'impact' ),
		)
	);

	$involved = portfolio_demo_insert(
		array(
			'post_type'    => 'page',
			'post_name'    => 'get-involved',
			'post_title'   => 'Get involved',
			'post_excerpt' => 'Give, volunteer or partner with us. Every route leads to more mangroves on the creek bank.',
			'post_content' => portfolio_demo_commons_pattern( 'get-involved' ) . "\n\n" . portfolio_demo_commons_pattern( 'contact' ),
		)
	);

	$stories_page = portfolio_demo_insert(
		array(
			'post_type'  => 'page',
			'post_title' => 'Stories',
		)
	);

	portfolio_demo_privacy_page( 'Creekside Mangrove Trust is a fictional organisation created to demonstrate the Commons theme. This page shows where a real privacy policy would go.' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home );
	update_option( 'page_for_posts', $stories_page );

	// The header's Navigation block falls back to the newest menu.
	$links = '';
	foreach ( array( $about, $stories_page, $involved ) as $page_id ) {
		$links .= sprintf(
			'<!-- wp:navigation-link {"label":"%1$s","type":"page","id":%2$d,"url":"%3$s","kind":"post-type"} /-->',
			esc_attr( get_the_title( $page_id ) ),
			$page_id,
			esc_url( get_permalink( $page_id ) )
		);
	}

	portfolio_demo_insert(
		array(
			'post_type'    => 'wp_navigation',
			'post_title'   => 'Main',
			'post_content' => $links,
		)
	);
}

/**
 * Returns the markup of a Commons pattern.
 *
 * @param string $slug Pattern file name without .php.
 * @return string
 */
function portfolio_demo_commons_pattern( $slug ) {
	return portfolio_demo_pattern( 'commons', $slug );
}
