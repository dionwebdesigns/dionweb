<?php
/**
 * Demo content for the themes in this repository.
 *
 * Run with WP-CLI from the WordPress root, naming the theme to set up:
 *
 *     wp eval-file wp-content/portfolio-demo/demo-content.php lintel --user=admin
 *     wp eval-file wp-content/portfolio-demo/demo-content.php commons --user=admin
 *
 * Everything the script creates is tagged, so running it again replaces the
 * previous demo rather than duplicating it. All organisations, people,
 * projects and quotes in the demo are fictional.
 *
 * @package WordPress_Portfolio
 */

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
	return;
}

require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';
require_once __DIR__ . '/content-lintel.php';
require_once __DIR__ . '/content-commons.php';

/**
 * Deletes everything a previous run created.
 *
 * @return void
 */
function portfolio_demo_reset() {
	$previous = get_posts(
		array(
			'post_type'      => 'any',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_key'       => '_portfolio_demo', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One-off setup script.
		)
	);

	$attachments = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_key'       => '_portfolio_demo', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One-off setup script.
		)
	);

	foreach ( array_merge( $previous, $attachments ) as $post_id ) {
		wp_delete_post( $post_id, true );
	}

	require_once ABSPATH . 'wp-admin/includes/user.php';

	$authors = get_users(
		array(
			'meta_key' => '_portfolio_demo', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One-off setup script.
			'fields'   => 'ID',
		)
	);

	foreach ( $authors as $author_id ) {
		wp_delete_user( (int) $author_id );
	}

	foreach ( array( 'gw_project_type', 'category' ) as $taxonomy ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'meta_key'   => '_portfolio_demo', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One-off setup script.
			)
		);

		foreach ( is_wp_error( $terms ) ? array() : $terms as $term ) {
			wp_delete_term( $term->term_id, $taxonomy );
		}
	}

	foreach ( wp_get_nav_menus() as $menu ) {
		if ( 0 === strpos( $menu->name, 'Demo:' ) ) {
			wp_delete_nav_menu( $menu->term_id );
		}
	}

	// WordPress fills the first widget area with default widgets on install.
	$sidebars = get_option( 'sidebars_widgets', array() );
	foreach ( array_keys( $sidebars ) as $sidebar ) {
		if ( 'wp_inactive_widgets' !== $sidebar && 'array_version' !== $sidebar ) {
			$sidebars[ $sidebar ] = array();
		}
	}
	update_option( 'sidebars_widgets', $sidebars );

	// WordPress's own sample content would show up among the demo articles.
	foreach ( array(
		'hello-world' => 'post',
		'sample-page' => 'page',
	) as $slug => $type ) {
		$sample = get_page_by_path( $slug, OBJECT, $type );

		if ( $sample ) {
			wp_delete_post( $sample->ID, true );
		}
	}
}

/**
 * Inserts a post and tags it as demo content.
 *
 * @param array $postarr Arguments for wp_insert_post().
 * @return int Post ID.
 */
function portfolio_demo_insert( array $postarr ) {
	$postarr = wp_parse_args(
		$postarr,
		array(
			'post_status' => 'publish',
			'post_type'   => 'post',
		)
	);

	$postarr['meta_input'] = array_merge(
		isset( $postarr['meta_input'] ) ? $postarr['meta_input'] : array(),
		array( '_portfolio_demo' => 1 )
	);

	$post_id = wp_insert_post( wp_slash( $postarr ), true );

	if ( is_wp_error( $post_id ) ) {
		WP_CLI::error( $post_id->get_error_message() );
	}

	return (int) $post_id;
}

/**
 * Creates a term and tags it as demo content.
 *
 * @param string $name     Term name.
 * @param string $taxonomy Taxonomy.
 * @return int Term ID.
 */
function portfolio_demo_term( $name, $taxonomy ) {
	$term = wp_insert_term( $name, $taxonomy );

	if ( is_wp_error( $term ) ) {
		$existing = get_term_by( 'name', $name, $taxonomy );
		return $existing ? (int) $existing->term_id : 0;
	}

	update_term_meta( $term['term_id'], '_portfolio_demo', 1 );

	return (int) $term['term_id'];
}

/**
 * Creates a demo author, so articles are not credited to "admin".
 *
 * @param string $login        User login.
 * @param string $display_name Name shown on articles.
 * @param string $bio          Short biography.
 * @return int User ID.
 */
function portfolio_demo_author( $login, $display_name, $bio ) {
	$user_id = wp_insert_user(
		array(
			'user_login'   => 'demo-' . $login,
			'user_pass'    => wp_generate_password( 24 ),
			'user_email'   => 'demo-' . $login . '@example.com',
			'display_name' => $display_name,
			'description'  => $bio,
			'role'         => 'author',
		)
	);

	if ( is_wp_error( $user_id ) ) {
		WP_CLI::error( $user_id->get_error_message() );
	}

	update_user_meta( $user_id, '_portfolio_demo', 1 );

	return (int) $user_id;
}

/**
 * Imports an image from demo/images and attaches it to a post.
 *
 * @param string $file    File name in demo/images.
 * @param string $alt     Alternative text.
 * @param int    $post_id Post to attach the image to and use it as the featured image of.
 * @return int Attachment ID, or 0 on failure.
 */
function portfolio_demo_image( $file, $alt, $post_id ) {
	$source = __DIR__ . '/images/' . $file;

	if ( ! file_exists( $source ) ) {
		WP_CLI::warning( "Missing demo image: {$file}" );
		return 0;
	}

	$temporary = wp_tempnam( $file );
	copy( $source, $temporary );

	$attachment_id = media_handle_sideload(
		array(
			'name'     => $file,
			'tmp_name' => $temporary,
		),
		$post_id
	);

	if ( is_wp_error( $attachment_id ) ) {
		WP_CLI::warning( $attachment_id->get_error_message() );
		return 0;
	}

	update_post_meta( $attachment_id, '_portfolio_demo', 1 );
	update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
	set_post_thumbnail( $post_id, $attachment_id );

	return (int) $attachment_id;
}

/**
 * Creates a menu from a list of items and assigns it to a theme location.
 *
 * Each item is an array with a title, a url, and optional children.
 *
 * @param string $name     Menu name, without the "Demo:" prefix.
 * @param string $location Theme location, or an empty string for none.
 * @param array  $items    Menu items.
 * @return int Menu ID.
 */
function portfolio_demo_menu( $name, $location, array $items ) {
	$menu_id = wp_create_nav_menu( 'Demo: ' . $name );

	foreach ( $items as $item ) {
		$parent_id = wp_update_nav_menu_item(
			$menu_id,
			0,
			array(
				'menu-item-title'  => $item['title'],
				'menu-item-url'    => $item['url'],
				'menu-item-status' => 'publish',
			)
		);

		foreach ( isset( $item['children'] ) ? $item['children'] : array() as $child ) {
			wp_update_nav_menu_item(
				$menu_id,
				0,
				array(
					'menu-item-title'     => $child['title'],
					'menu-item-url'       => $child['url'],
					'menu-item-status'    => 'publish',
					'menu-item-parent-id' => $parent_id,
				)
			);
		}
	}

	if ( $location ) {
		$locations              = get_theme_mod( 'nav_menu_locations', array() );
		$locations[ $location ] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );
	}

	return (int) $menu_id;
}

/**
 * Returns the block markup of a theme pattern file, read directly so the
 * script works before the theme's patterns are registered.
 *
 * @param string $theme Theme folder.
 * @param string $slug  Pattern file name without .php.
 * @return string
 */
function portfolio_demo_pattern( $theme, $slug ) {
	ob_start();
	include get_theme_root() . "/{$theme}/patterns/{$slug}.php";
	return trim( (string) ob_get_clean() );
}

/**
 * Turns a compact list of blocks into block markup.
 *
 * Each block is an array of a type and its content:
 * p, h2 and h3 take text; ul and checklist take a list of items.
 *
 * @param array $blocks Blocks to convert.
 * @return string Block markup.
 */
function portfolio_demo_blocks( array $blocks ) {
	$markup = array();

	foreach ( $blocks as $block ) {
		list( $type, $content ) = $block;

		switch ( $type ) {
			case 'h2':
				$markup[] = "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">{$content}</h2>\n<!-- /wp:heading -->";
				break;
			case 'h3':
				$markup[] = "<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">{$content}</h3>\n<!-- /wp:heading -->";
				break;
			case 'ul':
			case 'checklist':
				$items = '';
				foreach ( $content as $item ) {
					$items .= "<!-- wp:list-item -->\n<li>{$item}</li>\n<!-- /wp:list-item -->\n";
				}
				$markup[] = 'checklist' === $type
					? "<!-- wp:list {\"className\":\"is-style-{$block[2]}\"} -->\n<ul class=\"wp-block-list is-style-{$block[2]}\">{$items}</ul>\n<!-- /wp:list -->"
					: "<!-- wp:list -->\n<ul class=\"wp-block-list\">{$items}</ul>\n<!-- /wp:list -->";
				break;
			case 'quote':
				$markup[] = "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><!-- wp:paragraph -->\n<p>{$content}</p>\n<!-- /wp:paragraph --></blockquote>\n<!-- /wp:quote -->";
				break;
			case 'raw':
				$markup[] = $content;
				break;
			default:
				$markup[] = "<!-- wp:paragraph -->\n<p>{$content}</p>\n<!-- /wp:paragraph -->";
		}
	}

	return implode( "\n\n", $markup );
}

/**
 * Makes sure the Groundwork plugin is active and its types are registered
 * in this request.
 *
 * @return void
 */
function portfolio_demo_require_groundwork() {
	if ( ! post_type_exists( 'gw_project' ) ) {
		$result = activate_plugin( 'groundwork/groundwork.php' );

		if ( is_wp_error( $result ) ) {
			WP_CLI::error( 'Groundwork could not be activated: ' . $result->get_error_message() );
		}

		( new \Groundwork\Post_Types() )->register();
		( new \Groundwork\Meta() )->register();
	}
}

/**
 * Publishes the privacy policy page WordPress drafts on install, so the
 * footer link appears.
 *
 * @param string $text Policy text.
 * @return void
 */
function portfolio_demo_privacy_page( $text ) {
	$page_id = (int) get_option( 'wp_page_for_privacy_policy' );

	if ( ! $page_id || ! get_post( $page_id ) ) {
		$page_id = portfolio_demo_insert(
			array(
				'post_type'  => 'page',
				'post_title' => 'Privacy Policy',
			)
		);
		update_option( 'wp_page_for_privacy_policy', $page_id );
	}

	wp_update_post(
		wp_slash(
			array(
				'ID'           => $page_id,
				'post_status'  => 'publish',
				'post_content' => portfolio_demo_blocks( array( array( 'p', $text ) ) ),
			)
		)
	);
}

$portfolio_demo_theme = isset( $args[0] ) ? sanitize_key( $args[0] ) : get_template();

if ( ! in_array( $portfolio_demo_theme, array( 'lintel', 'commons' ), true ) ) {
	WP_CLI::error( 'Name the theme to set up: lintel or commons.' );
}

WP_CLI::log( "Setting up the {$portfolio_demo_theme} demo." );

update_option( 'permalink_structure', '/%postname%/' );
portfolio_demo_require_groundwork();

if ( get_stylesheet() !== $portfolio_demo_theme ) {
	switch_theme( $portfolio_demo_theme );
}

// Run the theme switch routines now. Otherwise WordPress runs them on the
// next page load and maps the old menu locations over the new demo menus.
check_theme_switched();

portfolio_demo_reset();

if ( 'lintel' === $portfolio_demo_theme ) {
	portfolio_demo_lintel();
} else {
	portfolio_demo_commons();
}

flush_rewrite_rules();

WP_CLI::success( "The {$portfolio_demo_theme} demo is ready: " . home_url( '/' ) );
