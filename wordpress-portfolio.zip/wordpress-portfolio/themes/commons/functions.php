<?php
/**
 * Commons functions.
 *
 * A block theme needs very little PHP: theme.json, templates and patterns
 * do the work. This file loads the stylesheet and registers block styles
 * and the pattern category.
 *
 * @package Commons
 */

defined( 'ABSPATH' ) || exit;

/**
 * Loads the stylesheet on the front end and in the editor.
 *
 * @return void
 */
function commons_setup() {
	add_editor_style( 'style.css' );

	// Patterns come from the theme's patterns folder only.
	remove_theme_support( 'core-block-patterns' );
}
add_action( 'after_setup_theme', 'commons_setup' );

/**
 * Enqueues the stylesheet.
 *
 * @return void
 */
function commons_enqueue_styles() {
	$theme = wp_get_theme( get_template() );

	wp_enqueue_style( 'commons-style', get_stylesheet_uri(), array(), $theme->get( 'Version' ) );
}
add_action( 'wp_enqueue_scripts', 'commons_enqueue_styles' );

/**
 * Registers the pattern category and block styles.
 *
 * @return void
 */
function commons_register_block_extras() {
	register_block_pattern_category(
		'commons',
		array(
			'label'       => __( 'Commons', 'commons' ),
			'description' => __( 'Sections for non-profit and community sites.', 'commons' ),
		)
	);

	register_block_style(
		'core/table',
		array(
			'name'  => 'commons-ledger',
			'label' => __( 'Ledger', 'commons' ),
		)
	);
}
add_action( 'init', 'commons_register_block_extras' );
