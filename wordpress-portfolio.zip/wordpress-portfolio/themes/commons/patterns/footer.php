<?php
/**
 * Title: Footer
 * Slug: commons/footer
 * Categories: footer
 * Block Types: core/template-part/footer
 * Inserter: false
 *
 * @package Commons
 */

?>
<!-- wp:group {"align":"full","className":"is-style-section-mangrove","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-section-mangrove" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column {"width":"40%"} -->
		<div class="wp-block-column" style="flex-basis:40%">
			<!-- wp:site-title {"level":0} /-->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'We restore mangrove forests with the fishing communities who depend on them, and train young people to look after them.', 'commons' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"30%"} -->
		<div class="wp-block-column" style="flex-basis:30%">
			<!-- wp:heading {"level":2,"fontSize":"medium"} -->
			<h2 class="wp-block-heading has-medium-font-size"><?php esc_html_e( 'Visit us', 'commons' ); ?></h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( '7 Example Close, Old GRA, Port Harcourt, Rivers State', 'commons' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"30%"} -->
		<div class="wp-block-column" style="flex-basis:30%">
			<!-- wp:heading {"level":2,"fontSize":"medium"} -->
			<h2 class="wp-block-heading has-medium-font-size"><?php esc_html_e( 'Get in touch', 'commons' ); ?></h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><a href="mailto:hello@example.org">hello@example.org</a><br>+234 84 000 0001</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:separator {"align":"wide","className":"is-style-wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|30"}}}} -->
	<hr class="wp-block-separator alignwide has-alpha-channel-opacity is-style-wide" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--30)"/>
	<!-- /wp:separator -->

	<!-- wp:paragraph {"align":"wide","fontSize":"small"} -->
	<?php /* translators: %s: current year. */ ?>
	<p class="alignwide has-small-font-size"><?php echo esc_html( sprintf( __( '© %s Creekside Mangrove Trust. Registered charity CAC/IT/123456.', 'commons' ), gmdate( 'Y' ) ) ); ?></p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
