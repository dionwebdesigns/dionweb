<?php
/**
 * Title: Contact details and form
 * Slug: commons/contact
 * Categories: commons, contact
 * Keywords: contact, form, enquiry, volunteer
 * Description: How to reach the team, beside an enquiry form. The form needs the Groundwork plugin.
 * Viewport Width: 1280
 *
 * @package Commons
 */

?>
<!-- wp:group {"align":"full","anchor":"contact","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div id="contact" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column {"width":"38%"} -->
		<div class="wp-block-column" style="flex-basis:38%">
			<!-- wp:heading {"fontSize":"xx-large"} -->
			<h2 class="wp-block-heading has-xx-large-font-size"><?php esc_html_e( 'Talk to us', 'commons' ); ?></h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Tell us how you would like to help. Our volunteer coordinator replies to every message within three working days.', 'commons' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:paragraph -->
			<p><strong><?php esc_html_e( 'Office hours', 'commons' ); ?></strong><br><?php esc_html_e( 'Monday to Friday, 9am to 4pm', 'commons' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"62%"} -->
		<div class="wp-block-column" style="flex-basis:62%">
			<?php if ( function_exists( 'groundwork_get_contact_form' ) ) : ?>
			<!-- wp:groundwork/contact-form {"buttonLabel":"<?php echo esc_attr__( 'Send message', 'commons' ); ?>","subjects":"<?php echo esc_attr( __( 'I would like to volunteer', 'commons' ) . '\n' . __( 'I would like to donate', 'commons' ) . '\n' . __( 'Partnership or sponsorship', 'commons' ) . '\n' . __( 'Something else', 'commons' ) ); ?>"} /-->
			<?php else : ?>
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Activate the Groundwork plugin to show an enquiry form here.', 'commons' ); ?></p>
			<!-- /wp:paragraph -->
			<?php endif; ?>
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
