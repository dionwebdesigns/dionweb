<?php
/**
 * Title: No results
 * Slug: commons/hidden-no-results
 * Inserter: false
 *
 * @package Commons
 */

?>
<!-- wp:paragraph -->
<p><?php esc_html_e( 'Nothing matches yet. Try different words, or browse the latest stories.', 'commons' ); ?></p>
<!-- /wp:paragraph -->
