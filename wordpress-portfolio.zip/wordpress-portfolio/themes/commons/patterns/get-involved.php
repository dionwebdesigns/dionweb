<?php
/**
 * Title: Ways to help
 * Slug: commons/get-involved
 * Categories: commons, call-to-action
 * Keywords: donate, volunteer, partner, support, help
 * Description: Three ways to support the organisation, each with a clear next step.
 * Viewport Width: 1280
 *
 * @package Commons
 */

$commons_ways = array(
	array(
		'title'  => __( 'Give', 'commons' ),
		'text'   => __( 'A gift of 10,000 naira grows and plants 50 seedlings. Monthly gifts let us plan each planting season.', 'commons' ),
		'button' => __( 'Donate', 'commons' ),
		'style'  => '',
	),
	array(
		'title'  => __( 'Volunteer', 'commons' ),
		'text'   => __( 'Join a planting day or a creek clean-up. We provide boots, gloves, lunch and transport from Port Harcourt.', 'commons' ),
		'button' => __( 'Volunteer with us', 'commons' ),
		'style'  => 'is-style-outline',
	),
	array(
		'title'  => __( 'Partner', 'commons' ),
		'text'   => __( 'Companies and schools can sponsor a nursery or a stretch of creek bank, with a yearly report on what grew.', 'commons' ),
		'button' => __( 'Talk to us', 'commons' ),
		'style'  => 'is-style-outline',
	),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:heading {"align":"wide","fontSize":"xx-large","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}}} -->
	<h2 class="wp-block-heading alignwide has-xx-large-font-size" style="margin-bottom:var(--wp--preset--spacing--50)"><?php esc_html_e( 'Three ways to help', 'commons' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-columns alignwide">
		<?php foreach ( $commons_ways as $commons_way ) : ?>
		<!-- wp:column {"className":"is-style-section-mist","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}},"border":{"radius":"6px"}}} -->
		<div class="wp-block-column is-style-section-mist" style="border-radius:6px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)">
			<!-- wp:heading {"level":3,"fontSize":"x-large"} -->
			<h3 class="wp-block-heading has-x-large-font-size"><?php echo esc_html( $commons_way['title'] ); ?></h3>
			<!-- /wp:heading -->

			<!-- wp:paragraph -->
			<p><?php echo esc_html( $commons_way['text'] ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:buttons -->
			<div class="wp-block-buttons">
				<?php if ( $commons_way['style'] ) : ?>
				<!-- wp:button {"className":"<?php echo esc_attr( $commons_way['style'] ); ?>"} -->
				<div class="wp-block-button <?php echo esc_attr( $commons_way['style'] ); ?>"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/get-involved/#contact' ) ); ?>"><?php echo esc_html( $commons_way['button'] ); ?></a></div>
				<!-- /wp:button -->
				<?php else : ?>
				<!-- wp:button -->
				<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/get-involved/#contact' ) ); ?>"><?php echo esc_html( $commons_way['button'] ); ?></a></div>
				<!-- /wp:button -->
				<?php endif; ?>
			</div>
			<!-- /wp:buttons -->
		</div>
		<!-- /wp:column -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
