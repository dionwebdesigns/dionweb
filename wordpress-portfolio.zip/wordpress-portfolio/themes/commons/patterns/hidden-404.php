<?php
/**
 * Title: Page not found
 * Slug: commons/hidden-404
 * Inserter: false
 *
 * @package Commons
 */

?>
<!-- wp:heading {"level":1,"fontSize":"huge"} -->
<h1 class="wp-block-heading has-huge-font-size"><?php esc_html_e( 'Page not found', 'commons' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size"><?php esc_html_e( 'This page has moved or never existed. Search the site, or go back to the home page.', 'commons' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:pattern {"slug":"commons/hidden-search"} /-->
