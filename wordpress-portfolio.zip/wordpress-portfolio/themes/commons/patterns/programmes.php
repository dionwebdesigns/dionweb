<?php
/**
 * Title: Programmes
 * Slug: commons/programmes
 * Categories: commons, featured
 * Keywords: programmes, services, what we do
 * Description: A short introduction and three programmes, each with an icon.
 * Viewport Width: 1280
 *
 * @package Commons
 */

$commons_programmes = array(
	array(
		'icon'  => 'icon-replanting.svg',
		'title' => __( 'Replanting', 'commons' ),
		'text'  => __( 'Community nurseries grow seedlings, and volunteers plant them along eroded creek banks in the rainy season.', 'commons' ),
	),
	array(
		'icon'  => 'icon-rangers.svg',
		'title' => __( 'Youth rangers', 'commons' ),
		'text'  => __( 'Paid training for young people aged 18 to 25 in planting, monitoring and boat safety.', 'commons' ),
	),
	array(
		'icon'  => 'icon-creeks.svg',
		'title' => __( 'Clean creeks', 'commons' ),
		'text'  => __( 'Monthly clean-ups that clear plastic and oil-soaked waste from the water the seedlings need.', 'commons' ),
	),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:group {"align":"wide","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"640px","justifyContent":"left"}} -->
	<div class="wp-block-group alignwide" style="margin-bottom:var(--wp--preset--spacing--50)">
		<!-- wp:heading {"fontSize":"xx-large"} -->
		<h2 class="wp-block-heading has-xx-large-font-size"><?php esc_html_e( 'What we do', 'commons' ); ?></h2>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"fontSize":"large"} -->
		<p class="has-large-font-size"><?php esc_html_e( 'Three programmes, run with the communities who live beside the creeks and know them best.', 'commons' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
	<div class="wp-block-columns alignwide">
		<?php foreach ( $commons_programmes as $commons_programme ) : ?>
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"width":"64px","height":"64px","sizeSlug":"full","linkDestination":"none"} -->
			<figure class="wp-block-image size-full is-resized"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/' . $commons_programme['icon'] ) ); ?>" alt="" style="width:64px;height:64px"/></figure>
			<!-- /wp:image -->

			<!-- wp:heading {"level":3} -->
			<h3 class="wp-block-heading"><?php echo esc_html( $commons_programme['title'] ); ?></h3>
			<!-- /wp:heading -->

			<!-- wp:paragraph -->
			<p><?php echo esc_html( $commons_programme['text'] ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<?php endforeach; ?>
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
