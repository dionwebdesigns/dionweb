<?php
/**
 * Title: Impact ledger
 * Slug: commons/impact
 * Categories: commons, featured
 * Keywords: impact, numbers, results, annual report, statistics
 * Description: A year's results as a ledger, the way an annual report presents them, beside a note on how the figures are checked.
 * Viewport Width: 1280
 *
 * @package Commons
 */

?>
<!-- wp:group {"align":"full","className":"is-style-section-mist","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-section-mist" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column {"width":"40%"} -->
		<div class="wp-block-column" style="flex-basis:40%">
			<!-- wp:heading {"fontSize":"xx-large"} -->
			<h2 class="wp-block-heading has-xx-large-font-size"><?php esc_html_e( '2025 in numbers', 'commons' ); ?></h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'An independent auditor checks every figure before we publish it. The full accounts are in our annual report.', 'commons' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"60%"} -->
		<div class="wp-block-column" style="flex-basis:60%">
			<!-- wp:table {"className":"is-style-commons-ledger"} -->
			<figure class="wp-block-table is-style-commons-ledger"><table class="has-fixed-layout"><tbody><tr><td><?php esc_html_e( 'Mangrove seedlings planted', 'commons' ); ?></td><td>48,200</td></tr><tr><td><?php esc_html_e( 'Hectares of creek bank restored', 'commons' ); ?></td><td>61</td></tr><tr><td><?php esc_html_e( 'Youth rangers trained and paid', 'commons' ); ?></td><td>140</td></tr><tr><td><?php esc_html_e( 'Partner communities', 'commons' ); ?></td><td>14</td></tr><tr><td><?php esc_html_e( 'Share of spending that went to programmes', 'commons' ); ?></td><td>87%</td></tr></tbody></table></figure>
			<!-- /wp:table -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
