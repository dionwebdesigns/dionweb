<?php
/**
 * Title: Search form
 * Slug: commons/hidden-search
 * Inserter: false
 *
 * @package Commons
 */

?>
<!-- wp:search {"label":"<?php echo esc_attr__( 'Search', 'commons' ); ?>","showLabel":false,"placeholder":"<?php echo esc_attr__( 'Search stories and pages', 'commons' ); ?>","buttonText":"<?php echo esc_attr__( 'Search', 'commons' ); ?>"} /-->
