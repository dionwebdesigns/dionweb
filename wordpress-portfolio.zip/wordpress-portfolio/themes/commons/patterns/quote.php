<?php
/**
 * Title: Community voice
 * Slug: commons/quote
 * Categories: commons, testimonials
 * Keywords: quote, testimonial, story, voice
 * Description: One quote from someone the work affects, set large.
 * Viewport Width: 1280
 *
 * @package Commons
 */

?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"860px"}} -->
<div class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:quote -->
	<blockquote class="wp-block-quote"><!-- wp:paragraph -->
	<p><?php esc_html_e( 'The fish came back to our side of the creek two years after the planting. Now my children help at the nursery on Saturdays.', 'commons' ); ?></p>
	<!-- /wp:paragraph --><cite><?php esc_html_e( 'Blessing Owaji, fisher and nursery volunteer', 'commons' ); ?></cite></blockquote>
	<!-- /wp:quote -->
</div>
<!-- /wp:group -->
