<?php
/**
 * Title: Stories heading
 * Slug: commons/hidden-blog-heading
 * Inserter: false
 *
 * @package Commons
 */

?>
<!-- wp:heading {"level":1,"fontSize":"huge"} -->
<h1 class="wp-block-heading has-huge-font-size"><?php esc_html_e( 'Stories', 'commons' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size"><?php esc_html_e( 'News from the creeks, the nurseries and the people who look after them.', 'commons' ); ?></p>
<!-- /wp:paragraph -->
