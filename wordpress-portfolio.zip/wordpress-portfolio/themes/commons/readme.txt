=== Commons ===
Contributors: emediong
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A block theme for non-profits and community organisations.

== Description ==

Commons is a full site editing theme. Everything is editable in the Site Editor: templates, the header and footer, colours and type.

Features:

* Eight templates and two template parts, built entirely from blocks
* Patterns for a mission-led hero, programmes, an impact ledger, a community quote, ways to help, latest stories and a contact section
* Two style variations, Evening (dark) and Indigo, and two section styles
* Body text in Atkinson Hyperlegible Next, a typeface designed for readers with low vision
* Self-hosted fonts, no external requests
* Works with the Groundwork plugin's contact form block

== Installation ==

1. In your admin panel, go to Appearance > Themes and click Add New.
2. Click Upload Theme, choose the theme's .zip file and click Install Now.
3. Click Activate, then open Appearance > Editor to customise it.

== Changelog ==

= 1.0.0 =
* Initial release.

== Copyright ==

Commons WordPress Theme, (C) 2026 Innocent Emediong Friday.
Commons is distributed under the terms of the GNU GPL v2 or later.

This theme bundles the following third-party resources:

Zilla Slab
Copyright 2017 The Mozilla Foundation
License: SIL Open Font License, Version 1.1, https://openfontlicense.org

Atkinson Hyperlegible Next
Copyright 2020-2024 The Atkinson Hyperlegible Next Project Authors (https://github.com/googlefonts/atkinson-hyperlegible-next)
License: SIL Open Font License, Version 1.1, https://openfontlicense.org

Font files from Fontsource (https://fontsource.org).
The geometric illustrations are original work, released under the GPL.
