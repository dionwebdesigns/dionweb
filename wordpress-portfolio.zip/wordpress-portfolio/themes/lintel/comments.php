<?php
/**
 * Comments.
 *
 * @package Lintel
 */

if ( post_password_required() ) {
	return;
}

$lintel_comment_count = (int) get_comments_number();
?>
<section id="comments" class="comments container container--content">
	<?php if ( have_comments() ) : ?>
		<h2 class="comments__title">
			<?php
			printf(
				/* translators: %d: number of comments. */
				esc_html( _n( '%d comment', '%d comments', $lintel_comment_count, 'lintel' ) ),
				(int) $lintel_comment_count
			);
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 48,
				)
			);
			?>
		</ol>

		<?php
		the_comments_navigation(
			array(
				'prev_text' => __( 'Older comments', 'lintel' ),
				'next_text' => __( 'Newer comments', 'lintel' ),
			)
		);
		?>

		<?php if ( ! comments_open() ) : ?>
			<p class="comments__closed"><?php esc_html_e( 'Comments are closed.', 'lintel' ); ?></p>
		<?php endif; ?>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'title_reply'        => __( 'Leave a comment', 'lintel' ),
			'title_reply_before' => '<h2 id="reply-title" class="comment-reply-title">',
			'title_reply_after'  => '</h2>',
			'class_submit'       => 'button button--primary',
			'label_submit'       => __( 'Post comment', 'lintel' ),
		)
	);
	?>
</section>
