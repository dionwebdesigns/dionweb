/**
 * Main navigation: the mobile menu toggle and submenu toggles.
 *
 * Without JavaScript the menu stays expanded (see the .no-js rules in
 * style.css), so every link is always reachable.
 */
( function () {
	const header = document.querySelector( '.site-header' );
	const toggle = header && header.querySelector( '.menu-toggle' );
	const nav = header && header.querySelector( '.site-nav' );
	const strings = window.lintelNavigation || {};

	if ( ! toggle || ! nav ) {
		return;
	}

	function setMenu( open ) {
		toggle.setAttribute( 'aria-expanded', String( open ) );
		nav.classList.toggle( 'is-open', open );
		document.body.classList.toggle( 'has-open-menu', open );
	}

	toggle.addEventListener( 'click', function () {
		setMenu( toggle.getAttribute( 'aria-expanded' ) !== 'true' );
	} );

	// Escape closes the menu and returns focus to the button that opened it.
	document.addEventListener( 'keydown', function ( event ) {
		if ( event.key === 'Escape' && nav.classList.contains( 'is-open' ) ) {
			setMenu( false );
			toggle.focus();
		}
	} );

	// Close the mobile menu if the window grows to the desktop layout.
	window
		.matchMedia( '(min-width: 64em)' )
		.addEventListener( 'change', function ( event ) {
			if ( event.matches ) {
				setMenu( false );
			}
		} );

	nav.querySelectorAll( '.submenu-toggle' ).forEach( function ( button ) {
		const item = button.closest( '.menu-item' );
		const label = button.querySelector( '.screen-reader-text' );
		const title = item.querySelector( 'a' ).textContent.trim();

		button.addEventListener( 'click', function () {
			const open = button.getAttribute( 'aria-expanded' ) !== 'true';

			button.setAttribute( 'aria-expanded', String( open ) );
			item.classList.toggle( 'is-submenu-open', open );

			if ( label && strings.expand && strings.collapse ) {
				label.textContent =
					( open ? strings.collapse : strings.expand ) + ': ' + title;
			}
		} );
	} );
} )();
