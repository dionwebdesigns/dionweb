<?php
/**
 * Project type archive. Shares the projects archive layout, which
 * highlights the current type in the filter.
 *
 * @package Lintel
 */

get_template_part( 'archive-gw_project' );
