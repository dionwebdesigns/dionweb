<?php
/**
 * Page not found.
 *
 * @package Lintel
 */

get_header();

lintel_page_header(
	array(
		'title'       => __( 'Page not found', 'lintel' ),
		'description' => __( 'This page has moved or never existed. Search the site, or start again from one of the pages below.', 'lintel' ),
	)
);
?>

<div class="container section not-found">
	<?php get_search_form(); ?>

	<ul class="not-found__links" role="list">
		<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home page', 'lintel' ); ?></a></li>
		<?php if ( lintel_groundwork_active() ) : ?>
			<li><a href="<?php echo esc_url( (string) get_post_type_archive_link( 'gw_service' ) ); ?>"><?php esc_html_e( 'Services', 'lintel' ); ?></a></li>
			<li><a href="<?php echo esc_url( (string) get_post_type_archive_link( 'gw_project' ) ); ?>"><?php esc_html_e( 'Projects', 'lintel' ); ?></a></li>
		<?php endif; ?>
		<?php if ( lintel_get_mod( 'cta_url' ) ) : ?>
			<li><a href="<?php echo esc_url( lintel_get_mod( 'cta_url' ) ); ?>"><?php echo esc_html( lintel_get_mod( 'cta_label' ) ); ?></a></li>
		<?php endif; ?>
	</ul>
</div>

<?php
get_footer();
