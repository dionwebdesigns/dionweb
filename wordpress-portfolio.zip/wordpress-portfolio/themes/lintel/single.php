<?php
/**
 * Single article.
 *
 * @package Lintel
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'article' ); ?>>
		<header class="article__header">
			<div class="container article__header-inner">
				<?php lintel_entry_meta(); ?>
				<h1 class="article__title"><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="article__lead"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
				<?php endif; ?>
				<p class="article__byline">
					<?php
					printf(
						/* translators: %s: author name. */
						esc_html__( 'By %s', 'lintel' ),
						'<a href="' . esc_url( get_author_posts_url( (int) get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>'
					);
					?>
				</p>
			</div>
		</header>

		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="article__media container">
				<?php the_post_thumbnail( 'lintel-wide' ); ?>
				<?php if ( get_the_post_thumbnail_caption() ) : ?>
					<figcaption><?php the_post_thumbnail_caption(); ?></figcaption>
				<?php endif; ?>
			</figure>
		<?php endif; ?>

		<div class="entry-content is-layout-constrained has-global-padding">
			<?php
			the_content();

			wp_link_pages(
				array(
					'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Page', 'lintel' ) . '">',
					'after'  => '</nav>',
				)
			);
			?>
		</div>

		<footer class="article__footer container container--content">
			<?php lintel_entry_tags(); ?>
		</footer>
	</article>

	<div class="container container--content">
		<?php
		the_post_navigation(
			array(
				'prev_text' => '<span class="post-navigation__label">' . esc_html__( 'Previous article', 'lintel' ) . '</span><span class="post-navigation__title">%title</span>',
				'next_text' => '<span class="post-navigation__label">' . esc_html__( 'Next article', 'lintel' ) . '</span><span class="post-navigation__title">%title</span>',
			)
		);
		?>
	</div>
	<?php
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
endwhile;

get_footer();
