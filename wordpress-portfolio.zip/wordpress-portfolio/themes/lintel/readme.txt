=== Lintel ===
Contributors: emediong
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A classic WordPress theme for engineering and construction firms.

== Description ==

Lintel's front page reads like an engineering drawing sheet: grid references along the top edge, a line drawing of a truss bridge that sets itself out on load, and a title block of key facts. Below it come services, selected projects, client quotes and the latest articles.

Features:

* PHP templates for every view, built from reusable template parts
* Page templates: "Page without title" and "Landing page"
* Six block patterns, three block styles and a theme.json that matches the editor to the front end
* Customizer options for the hero, the title block facts, the call to action and company details, with live preview
* Accessible, keyboard-friendly navigation with submenu toggles
* Self-hosted fonts, no external requests
* Integrates with the Groundwork plugin for services, projects and testimonials. The theme works without it.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click Add New.
2. Click Upload Theme, choose the theme's .zip file and click Install Now.
3. Click Activate.
4. Optional: install and activate the Groundwork plugin to add services, projects and testimonials.

== Changelog ==

= 1.0.0 =
* Initial release.

== Copyright ==

Lintel WordPress Theme, (C) 2026 Innocent Emediong Friday.
Lintel is distributed under the terms of the GNU GPL v2 or later.

This theme bundles the following third-party resources:

Barlow and Barlow Condensed
Copyright 2017 The Barlow Project Authors (https://github.com/jpt/barlow)
License: SIL Open Font License, Version 1.1, https://openfontlicense.org
Font files from Fontsource (https://fontsource.org)

The truss drawing and all other images are original work, released under the GPL.
