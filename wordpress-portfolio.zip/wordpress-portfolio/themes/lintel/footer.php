<?php
/**
 * Site footer: call to action, company details, menus and the title
 * block strip that closes every page, like the bottom of a drawing sheet.
 *
 * @package Lintel
 */

$lintel_is_landing   = is_page_template( 'page-templates/template-landing.php' );
$lintel_address      = lintel_get_mod( 'address' );
$lintel_phone        = lintel_get_mod( 'phone' );
$lintel_email        = lintel_get_mod( 'email' );
$lintel_hours        = lintel_get_mod( 'hours' );
$lintel_registration = lintel_get_mod( 'registration' );
?>
</main>

<footer class="site-footer">
	<?php
	if ( ! $lintel_is_landing ) {
		get_template_part( 'template-parts/footer/footer-cta' );
	}
	?>

	<div class="container site-footer__grid">
		<section class="site-footer__company" aria-label="<?php esc_attr_e( 'Contact details', 'lintel' ); ?>">
			<p class="site-footer__name"><?php bloginfo( 'name' ); ?></p>

			<?php if ( $lintel_address ) : ?>
				<address class="site-footer__address"><?php echo nl2br( esc_html( $lintel_address ) ); ?></address>
			<?php endif; ?>

			<ul class="site-footer__contact" role="list">
				<?php if ( $lintel_phone ) : ?>
					<li><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $lintel_phone ) ); ?>"><?php echo esc_html( $lintel_phone ); ?></a></li>
				<?php endif; ?>
				<?php if ( $lintel_email ) : ?>
					<li><a href="<?php echo esc_url( 'mailto:' . $lintel_email ); ?>"><?php echo esc_html( $lintel_email ); ?></a></li>
				<?php endif; ?>
				<?php if ( $lintel_hours ) : ?>
					<li><?php echo esc_html( $lintel_hours ); ?></li>
				<?php endif; ?>
			</ul>
		</section>

		<?php if ( ! $lintel_is_landing && has_nav_menu( 'footer' ) ) : ?>
			<nav class="site-footer__nav" aria-label="<?php esc_attr_e( 'Company', 'lintel' ); ?>">
				<h2 class="site-footer__heading"><?php esc_html_e( 'Company', 'lintel' ); ?></h2>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'container'      => false,
						'menu_class'     => 'site-footer__menu',
						'depth'          => 1,
						'fallback_cb'    => false,
					)
				);
				?>
			</nav>
		<?php endif; ?>

		<?php
		if ( ! $lintel_is_landing && lintel_groundwork_active() ) :
			$lintel_footer_services = lintel_services_query( 6 );

			if ( $lintel_footer_services->have_posts() ) :
				?>
				<nav class="site-footer__nav" aria-label="<?php esc_attr_e( 'Services', 'lintel' ); ?>">
					<h2 class="site-footer__heading"><?php esc_html_e( 'Services', 'lintel' ); ?></h2>
					<ul class="site-footer__menu" role="list">
						<?php
						while ( $lintel_footer_services->have_posts() ) :
							$lintel_footer_services->the_post();
							?>
							<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
						<?php endwhile; ?>
					</ul>
				</nav>
				<?php
				wp_reset_postdata();
			endif;
		endif;
		?>

		<?php if ( ! $lintel_is_landing && is_active_sidebar( 'footer-1' ) ) : ?>
			<div class="site-footer__widgets">
				<?php dynamic_sidebar( 'footer-1' ); ?>
			</div>
		<?php endif; ?>
	</div>

	<div class="container">
		<div class="site-footer__sheet">
			<p class="site-footer__cell">
				&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>
			</p>
			<?php if ( $lintel_registration ) : ?>
				<p class="site-footer__cell"><?php echo esc_html( $lintel_registration ); ?></p>
			<?php endif; ?>
			<?php if ( get_privacy_policy_url() ) : ?>
				<p class="site-footer__cell"><?php the_privacy_policy_link(); ?></p>
			<?php endif; ?>
			<p class="site-footer__cell site-footer__cell--end">
				<a href="#content"><?php esc_html_e( 'Back to top', 'lintel' ); ?></a>
			</p>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
