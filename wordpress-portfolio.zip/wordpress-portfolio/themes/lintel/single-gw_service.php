<?php
/**
 * Single service.
 *
 * @package Lintel
 */

get_header();

while ( have_posts() ) :
	the_post();

	lintel_page_header(
		array(
			'title'       => get_the_title(),
			'description' => has_excerpt() ? get_the_excerpt() : '',
			'parent'      => __( 'Services', 'lintel' ),
			'parent_url'  => (string) get_post_type_archive_link( 'gw_service' ),
		)
	);
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-body' ); ?>>
		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="page-body__media container">
				<?php the_post_thumbnail( 'lintel-wide' ); ?>
			</figure>
		<?php endif; ?>

		<div class="entry-content is-layout-constrained has-global-padding">
			<?php the_content(); ?>
		</div>
	</article>
	<?php
endwhile;

get_footer();
