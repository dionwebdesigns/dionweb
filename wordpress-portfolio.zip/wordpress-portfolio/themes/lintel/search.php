<?php
/**
 * Search results.
 *
 * @package Lintel
 */

get_header();

global $wp_query;

lintel_page_header(
	array(
		/* translators: %s: search terms. */
		'title'       => sprintf( esc_html__( 'Results for "%s"', 'lintel' ), esc_html( get_search_query() ) ),
		'description' => sprintf(
			/* translators: %d: number of results. */
			_n( '%d page matches your search.', '%d pages match your search.', (int) $wp_query->found_posts, 'lintel' ),
			(int) $wp_query->found_posts
		),
	)
);
?>

<div class="container section">
	<div class="search-again">
		<?php get_search_form(); ?>
	</div>

	<?php if ( have_posts() ) : ?>
		<div class="post-list">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content/content' );
			endwhile;
			?>
		</div>
		<?php lintel_posts_pagination(); ?>
	<?php else : ?>
		<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
	<?php endif; ?>
</div>

<?php
get_footer();
