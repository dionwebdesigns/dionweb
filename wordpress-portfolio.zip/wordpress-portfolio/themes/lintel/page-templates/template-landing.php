<?php
/**
 * Template Name: Landing page
 *
 * For campaigns and adverts: the logo stays, but the menu and footer
 * links are removed so visitors focus on one action.
 *
 * @package Lintel
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-body page-body--landing' ); ?>>
		<h1 class="screen-reader-text"><?php the_title(); ?></h1>
		<div class="entry-content is-layout-constrained has-global-padding">
			<?php the_content(); ?>
		</div>
	</article>
	<?php
endwhile;

get_footer();
