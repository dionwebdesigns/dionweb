<?php
/**
 * Template Name: Page without title
 * Template Post Type: page, gw_service
 *
 * For pages built entirely from patterns, such as an About page that
 * opens with its own full-width section.
 *
 * @package Lintel
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-body page-body--untitled' ); ?>>
		<h1 class="screen-reader-text"><?php the_title(); ?></h1>
		<div class="entry-content is-layout-constrained has-global-padding">
			<?php the_content(); ?>
		</div>
	</article>
	<?php
endwhile;

get_footer();
