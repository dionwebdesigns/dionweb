<?php
/**
 * Services archive.
 *
 * @package Lintel
 */

get_header();

lintel_page_header(
	array(
		'title'       => post_type_archive_title( '', false ),
		'description' => __( 'Engineering and construction services, from the first soil test to maintenance after handover.', 'lintel' ),
	)
);

$lintel_index = 0;
?>

<div class="container section">
	<?php if ( have_posts() ) : ?>
		<ul class="services-list services-list--full" role="list">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<li class="service">
					<?php lintel_the_service_glyph( $lintel_index ); ?>
					<div class="service__body">
						<h2 class="service__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<p class="service__summary"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
					</div>
				</li>
				<?php
				++$lintel_index;
			endwhile;
			?>
		</ul>
	<?php else : ?>
		<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
	<?php endif; ?>
</div>

<?php
get_footer();
