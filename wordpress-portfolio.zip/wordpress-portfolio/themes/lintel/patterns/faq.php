<?php
/**
 * Title: Frequently asked questions
 * Slug: lintel/faq
 * Categories: lintel, text
 * Keywords: faq, questions, answers, accordion
 * Description: A heading beside questions that open to show their answers.
 * Viewport Width: 1280
 *
 * @package Lintel
 */

?>
<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"},"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:column {"width":"36%"} -->
	<div class="wp-block-column" style="flex-basis:36%">
		<!-- wp:heading {"fontSize":"xx-large"} -->
		<h2 class="wp-block-heading has-xx-large-font-size"><?php esc_html_e( 'Questions clients ask first', 'lintel' ); ?></h2>
		<!-- /wp:heading -->
	</div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"64%"} -->
	<div class="wp-block-column" style="flex-basis:64%">
		<!-- wp:details -->
		<details class="wp-block-details"><summary><?php esc_html_e( 'Do you work outside Port Harcourt?', 'lintel' ); ?></summary>
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Yes. Most of our work is in Rivers, Bayelsa and Akwa Ibom, and we take projects anywhere in Nigeria when the scope justifies a site team.', 'lintel' ); ?></p>
			<!-- /wp:paragraph -->
		</details>
		<!-- /wp:details -->

		<!-- wp:details -->
		<details class="wp-block-details"><summary><?php esc_html_e( 'Can you do the design only, or the construction only?', 'lintel' ); ?></summary>
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Both. Some clients bring us in for design and supervision, others hand us the whole job from survey to handover.', 'lintel' ); ?></p>
			<!-- /wp:paragraph -->
		</details>
		<!-- /wp:details -->

		<!-- wp:details -->
		<details class="wp-block-details"><summary><?php esc_html_e( 'How long does a site visit take, and is there a fee?', 'lintel' ); ?></summary>
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Usually two to three hours. The first visit is free within Port Harcourt. Elsewhere we charge travel at cost and tell you the amount before we book.', 'lintel' ); ?></p>
			<!-- /wp:paragraph -->
		</details>
		<!-- /wp:details -->

		<!-- wp:details -->
		<details class="wp-block-details"><summary><?php esc_html_e( 'Who checks the design?', 'lintel' ); ?></summary>
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'A second registered engineer who did not prepare it. Nothing is built until that check is signed.', 'lintel' ); ?></p>
			<!-- /wp:paragraph -->
		</details>
		<!-- /wp:details -->
	</div>
	<!-- /wp:column -->
</div>
<!-- /wp:columns -->
