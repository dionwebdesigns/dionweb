<?php
/**
 * Title: About the firm
 * Slug: lintel/about
 * Categories: lintel, about
 * Keywords: about, company, history, team
 * Description: The firm's story beside a title block of key facts.
 * Viewport Width: 1280
 *
 * @package Lintel
 */

?>
<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"},"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:column {"width":"58%"} -->
	<div class="wp-block-column" style="flex-basis:58%">
		<!-- wp:heading {"fontSize":"xx-large"} -->
		<h2 class="wp-block-heading has-xx-large-font-size"><?php esc_html_e( 'Engineers who build what they design', 'lintel' ); ?></h2>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"fontSize":"large"} -->
		<p class="has-large-font-size"><?php esc_html_e( 'We started as a two-person design office and took on construction when clients asked us to stand behind our drawings on site.', 'lintel' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:paragraph -->
		<p><?php esc_html_e( 'Today one team designs, builds and maintains each structure. The engineer who signs the calculations visits the site every week, and the same people answer the phone after handover.', 'lintel' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:paragraph -->
		<p><?php esc_html_e( 'Most of our work is on soft, wet ground, where foundations decide whether a building lasts. That is the problem we know best.', 'lintel' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"42%"} -->
	<div class="wp-block-column" style="flex-basis:42%">
		<!-- wp:table {"className":"is-style-lintel-title-block"} -->
		<figure class="wp-block-table is-style-lintel-title-block"><table class="has-fixed-layout"><tbody><tr><td><?php esc_html_e( 'Founded', 'lintel' ); ?></td><td>2009</td></tr><tr><td><?php esc_html_e( 'Staff', 'lintel' ); ?></td><td>64</td></tr><tr><td><?php esc_html_e( 'Registered engineers', 'lintel' ); ?></td><td>18</td></tr><tr><td><?php esc_html_e( 'Plant and equipment', 'lintel' ); ?></td><td><?php esc_html_e( 'Owned, not hired', 'lintel' ); ?></td></tr><tr><td><?php esc_html_e( 'Defects period', 'lintel' ); ?></td><td><?php esc_html_e( '12 months on every project', 'lintel' ); ?></td></tr></tbody></table></figure>
		<!-- /wp:table -->
	</div>
	<!-- /wp:column -->
</div>
<!-- /wp:columns -->
