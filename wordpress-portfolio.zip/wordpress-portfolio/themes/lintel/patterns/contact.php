<?php
/**
 * Title: Contact details and form
 * Slug: lintel/contact
 * Categories: lintel, contact
 * Keywords: contact, enquiry, form, address, phone
 * Description: Office details beside an enquiry form. The form needs the Groundwork plugin.
 * Viewport Width: 1280
 *
 * @package Lintel
 */

?>
<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"},"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns alignwide" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50)">
	<!-- wp:column {"width":"36%"} -->
	<div class="wp-block-column" style="flex-basis:36%">
		<!-- wp:heading {"fontSize":"x-large"} -->
		<h2 class="wp-block-heading has-x-large-font-size"><?php esc_html_e( 'Talk to an engineer', 'lintel' ); ?></h2>
		<!-- /wp:heading -->

		<!-- wp:paragraph -->
		<p><?php esc_html_e( 'Tell us about the site, the deadline and any drawings you already have. An engineer will call you back within two working days.', 'lintel' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:table {"className":"is-style-lintel-title-block"} -->
		<figure class="wp-block-table is-style-lintel-title-block"><table class="has-fixed-layout"><tbody><tr><td><?php esc_html_e( 'Office', 'lintel' ); ?></td><td><?php esc_html_e( '12 Example Road, Trans-Amadi, Port Harcourt', 'lintel' ); ?></td></tr><tr><td><?php esc_html_e( 'Phone', 'lintel' ); ?></td><td>+234 84 000 0000</td></tr><tr><td><?php esc_html_e( 'Email', 'lintel' ); ?></td><td>projects@example.com</td></tr><tr><td><?php esc_html_e( 'Hours', 'lintel' ); ?></td><td><?php esc_html_e( 'Monday to Friday, 8am to 5pm', 'lintel' ); ?></td></tr></tbody></table></figure>
		<!-- /wp:table -->
	</div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"64%"} -->
	<div class="wp-block-column" style="flex-basis:64%">
		<?php if ( function_exists( 'groundwork_get_contact_form' ) ) : ?>
			<!-- wp:groundwork/contact-form {"buttonLabel":"<?php echo esc_attr__( 'Request a site visit', 'lintel' ); ?>","showCompany":true,"subjects":"<?php echo esc_attr( __( 'Site visit', 'lintel' ) . '\n' . __( 'Design only', 'lintel' ) . '\n' . __( 'Design and build', 'lintel' ) . '\n' . __( 'Something else', 'lintel' ) ); ?>"} /-->
		<?php else : ?>
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Activate the Groundwork plugin to show an enquiry form here, or replace this paragraph with your own form.', 'lintel' ); ?></p>
			<!-- /wp:paragraph -->
		<?php endif; ?>
	</div>
	<!-- /wp:column -->
</div>
<!-- /wp:columns -->
