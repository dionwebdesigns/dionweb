<?php
/**
 * Title: Safety and quality record
 * Slug: lintel/safety-record
 * Categories: lintel, featured
 * Keywords: safety, quality, HSE, record, certification
 * Description: A steel panel with commitments as a checklist and figures in a title block table.
 * Viewport Width: 1280
 *
 * @package Lintel
 */

?>
<!-- wp:group {"align":"full","className":"is-style-lintel-dark","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull is-style-lintel-dark" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
	<!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-columns alignwide">
		<!-- wp:column {"width":"55%"} -->
		<div class="wp-block-column" style="flex-basis:55%">
			<!-- wp:heading {"fontSize":"xx-large"} -->
			<h2 class="wp-block-heading has-xx-large-font-size"><?php esc_html_e( 'Safety and quality record', 'lintel' ); ?></h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"fontSize":"large"} -->
			<p class="has-large-font-size"><?php esc_html_e( 'Every site follows the same safety plan, and every design is checked by an engineer who did not draw it.', 'lintel' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:list {"className":"is-style-lintel-checklist"} -->
			<ul class="wp-block-list is-style-lintel-checklist">
				<!-- wp:list-item -->
				<li><?php esc_html_e( 'Engineers registered with COREN', 'lintel' ); ?></li>
				<!-- /wp:list-item -->

				<!-- wp:list-item -->
				<li><?php esc_html_e( 'A toolbox talk before every shift', 'lintel' ); ?></li>
				<!-- /wp:list-item -->

				<!-- wp:list-item -->
				<li><?php esc_html_e( 'An independent check of every design', 'lintel' ); ?></li>
				<!-- /wp:list-item -->

				<!-- wp:list-item -->
				<li><?php esc_html_e( 'A monthly safety report to the client', 'lintel' ); ?></li>
				<!-- /wp:list-item -->
			</ul>
			<!-- /wp:list -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%">
			<!-- wp:table {"className":"is-style-lintel-title-block"} -->
			<figure class="wp-block-table is-style-lintel-title-block"><table class="has-fixed-layout"><tbody><tr><td><?php esc_html_e( 'Days without a lost-time incident', 'lintel' ); ?></td><td>1,284</td></tr><tr><td><?php esc_html_e( 'Site inspections in 2025', 'lintel' ); ?></td><td>412</td></tr><tr><td><?php esc_html_e( 'Designs independently checked', 'lintel' ); ?></td><td>100%</td></tr><tr><td><?php esc_html_e( 'Insurance', 'lintel' ); ?></td><td><?php esc_html_e( 'Contractor\'s all-risk', 'lintel' ); ?></td></tr></tbody></table></figure>
			<!-- /wp:table -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
