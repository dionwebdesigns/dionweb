<?php
/**
 * Site header: document head, skip link, logo, navigation and the main
 * call to action.
 *
 * @package Lintel
 */

$lintel_is_landing = is_page_template( 'page-templates/template-landing.php' );
?>
<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'lintel' ); ?></a>

<header class="site-header<?php echo $lintel_is_landing ? ' site-header--minimal' : ''; ?>">
	<div class="container site-header__inner">
		<div class="site-branding">
			<?php lintel_site_branding(); ?>
		</div>

		<?php if ( ! $lintel_is_landing && has_nav_menu( 'primary' ) ) : ?>
			<button class="menu-toggle" type="button" aria-controls="site-navigation" aria-expanded="false">
				<span class="menu-toggle__icon" aria-hidden="true"></span>
				<span class="menu-toggle__label"><?php esc_html_e( 'Menu', 'lintel' ); ?></span>
			</button>

			<nav id="site-navigation" class="site-nav" aria-label="<?php esc_attr_e( 'Main', 'lintel' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'site-nav__menu',
						'depth'          => 2,
						'fallback_cb'    => false,
					)
				);
				?>
				<div class="site-nav__cta">
					<?php lintel_cta_button(); ?>
				</div>
			</nav>
		<?php endif; ?>

		<?php if ( ! $lintel_is_landing ) : ?>
			<div class="site-header__cta">
				<?php lintel_cta_button(); ?>
			</div>
		<?php endif; ?>
	</div>
</header>

<main id="content" class="site-main" tabindex="-1">
