<?php
/**
 * Search form.
 *
 * @package Lintel
 */

$lintel_search_id = wp_unique_id( 'search-' );
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="search-form__label" for="<?php echo esc_attr( $lintel_search_id ); ?>"><?php esc_html_e( 'Search this site', 'lintel' ); ?></label>
	<div class="search-form__row">
		<input type="search" id="<?php echo esc_attr( $lintel_search_id ); ?>" class="search-form__field" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" />
		<button type="submit" class="button button--primary"><?php esc_html_e( 'Search', 'lintel' ); ?></button>
	</div>
</form>
