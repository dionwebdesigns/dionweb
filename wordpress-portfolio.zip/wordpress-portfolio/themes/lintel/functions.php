<?php
/**
 * Lintel functions and definitions.
 *
 * Each concern lives in its own file under inc/, so this file only loads
 * them in order.
 *
 * @package Lintel
 */

defined( 'ABSPATH' ) || exit;

define( 'LINTEL_VERSION', wp_get_theme( get_template() )->get( 'Version' ) );

require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/enqueue.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/groundwork.php';
