<?php
/**
 * Projects archive, with links to filter by project type.
 * Also used for project type archives (see taxonomy-gw_project_type.php).
 *
 * @package Lintel
 */

get_header();

$lintel_archive_url = (string) get_post_type_archive_link( 'gw_project' );
$lintel_current     = is_tax( 'gw_project_type' ) ? get_queried_object() : null;
$lintel_types       = get_terms(
	array(
		'taxonomy'   => 'gw_project_type',
		'hide_empty' => true,
	)
);

lintel_page_header(
	array(
		'title'       => $lintel_current ? single_term_title( '', false ) : post_type_archive_title( '', false ),
		'description' => $lintel_current ? term_description() : __( 'Completed and ongoing work, with the brief, the approach and the outcome of each project.', 'lintel' ),
		'parent'      => $lintel_current ? __( 'Projects', 'lintel' ) : '',
		'parent_url'  => $lintel_archive_url,
	)
);
?>

<div class="container section">
	<?php if ( $lintel_types && ! is_wp_error( $lintel_types ) && count( $lintel_types ) > 1 ) : ?>
		<nav class="filter" aria-label="<?php esc_attr_e( 'Project types', 'lintel' ); ?>">
			<ul class="filter__list" role="list">
				<li>
					<a class="filter__link" href="<?php echo esc_url( $lintel_archive_url ); ?>"<?php echo $lintel_current ? '' : ' aria-current="page"'; ?>><?php esc_html_e( 'All', 'lintel' ); ?></a>
				</li>
				<?php foreach ( $lintel_types as $lintel_term ) : ?>
					<li>
						<a class="filter__link" href="<?php echo esc_url( (string) get_term_link( $lintel_term ) ); ?>"<?php echo $lintel_current && $lintel_current->term_id === $lintel_term->term_id ? ' aria-current="page"' : ''; ?>>
							<?php echo esc_html( $lintel_term->name ); ?>
							<span class="filter__count"><?php echo esc_html( number_format_i18n( $lintel_term->count ) ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</nav>
	<?php endif; ?>

	<?php if ( have_posts() ) : ?>
		<div class="project-grid">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/cards/card-project' );
			endwhile;
			?>
		</div>
		<?php lintel_posts_pagination(); ?>
	<?php else : ?>
		<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
	<?php endif; ?>
</div>

<?php
get_footer();
