<?php
/**
 * Main template: the blog index and the fallback for every other view.
 *
 * @package Lintel
 */

get_header();

if ( is_home() && ! is_front_page() ) {
	$lintel_blog_page = (int) get_option( 'page_for_posts' );

	lintel_page_header(
		array(
			'title'       => get_the_title( $lintel_blog_page ),
			'description' => get_post_field( 'post_excerpt', $lintel_blog_page ),
		)
	);
} else {
	lintel_page_header( array( 'title' => __( 'Latest articles', 'lintel' ) ) );
}
?>

<div class="container section">
	<?php if ( have_posts() ) : ?>
		<div class="post-list">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content/content', get_post_type() );
			endwhile;
			?>
		</div>
		<?php lintel_posts_pagination(); ?>
	<?php else : ?>
		<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
	<?php endif; ?>
</div>

<?php
get_footer();
