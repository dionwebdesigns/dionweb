<?php
/**
 * Front page.
 *
 * Fixed sections come from template parts. Anything added to the front
 * page in the editor (for example the "How a project runs" pattern) is
 * shown between the projects and the testimonial.
 *
 * @package Lintel
 */

// When the front page shows latest posts, use the blog template instead.
if ( is_home() ) {
	require get_home_template();
	return;
}

get_header();

get_template_part( 'template-parts/front-page/hero' );
get_template_part( 'template-parts/front-page/services' );
get_template_part( 'template-parts/front-page/projects' );

while ( have_posts() ) :
	the_post();

	if ( '' !== trim( get_the_content() ) ) :
		?>
		<div class="front-page-content entry-content is-layout-constrained has-global-padding">
			<?php the_content(); ?>
		</div>
		<?php
	endif;
endwhile;

get_template_part( 'template-parts/front-page/testimonial' );
get_template_part( 'template-parts/front-page/insights' );

get_footer();
