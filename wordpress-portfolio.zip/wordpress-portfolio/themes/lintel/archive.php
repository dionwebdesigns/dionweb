<?php
/**
 * Archives: categories, tags, authors and dates.
 *
 * @package Lintel
 */

get_header();

lintel_page_header(
	array(
		'title'       => get_the_archive_title(),
		'description' => get_the_archive_description(),
	)
);
?>

<div class="container section">
	<?php if ( have_posts() ) : ?>
		<div class="post-list">
			<?php
			while ( have_posts() ) :
				the_post();
				get_template_part( 'template-parts/content/content', get_post_type() );
			endwhile;
			?>
		</div>
		<?php lintel_posts_pagination(); ?>
	<?php else : ?>
		<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
	<?php endif; ?>
</div>

<?php
get_footer();
