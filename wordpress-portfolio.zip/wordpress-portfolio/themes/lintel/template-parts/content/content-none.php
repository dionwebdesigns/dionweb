<?php
/**
 * Shown when a list has nothing in it.
 *
 * @package Lintel
 */

?>
<section class="no-results">
	<?php if ( is_search() ) : ?>
		<h2 class="no-results__title"><?php esc_html_e( 'No matches', 'lintel' ); ?></h2>
		<p><?php esc_html_e( 'Try fewer or different words, or check the spelling.', 'lintel' ); ?></p>
		<?php get_search_form(); ?>
	<?php elseif ( is_home() && current_user_can( 'publish_posts' ) ) : ?>
		<h2 class="no-results__title"><?php esc_html_e( 'No articles yet', 'lintel' ); ?></h2>
		<p>
			<a href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>"><?php esc_html_e( 'Write your first article', 'lintel' ); ?></a>
		</p>
	<?php else : ?>
		<h2 class="no-results__title"><?php esc_html_e( 'Nothing here yet', 'lintel' ); ?></h2>
		<p><?php esc_html_e( 'Search the site, or go back to the home page.', 'lintel' ); ?></p>
		<?php get_search_form(); ?>
	<?php endif; ?>
</section>
