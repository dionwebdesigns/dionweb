<?php
/**
 * An article in a list: blog index, archives and search results.
 *
 * @package Lintel
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-row' ); ?>>
	<div class="post-row__meta">
		<?php lintel_posted_on(); ?>
	</div>

	<div class="post-row__body">
		<?php if ( is_search() && 'post' !== get_post_type() ) : ?>
			<p class="post-row__type"><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ); ?></p>
		<?php endif; ?>

		<h2 class="post-row__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<p class="post-row__excerpt"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>

		<?php if ( 'post' === get_post_type() ) : ?>
			<p class="post-row__reading-time"><?php echo esc_html( lintel_reading_time() ); ?></p>
		<?php endif; ?>
	</div>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="post-row__media">
			<?php the_post_thumbnail( 'lintel-card', array( 'alt' => '' ) ); ?>
		</div>
	<?php endif; ?>
</article>
