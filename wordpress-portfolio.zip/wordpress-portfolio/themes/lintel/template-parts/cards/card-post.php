<?php
/**
 * Article card: text first, for the front page and related articles.
 *
 * @package Lintel
 */

?>
<article class="post-card">
	<p class="post-card__meta"><?php lintel_posted_on(); ?></p>
	<h3 class="post-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	<p class="post-card__excerpt"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
</article>
