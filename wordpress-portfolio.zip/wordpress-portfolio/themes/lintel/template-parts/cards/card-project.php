<?php
/**
 * Project card, used on the front page, the projects archive and in
 * "More projects" lists.
 *
 * Accepts $args['size']: "large" for the featured project, otherwise "default".
 *
 * @package Lintel
 */

$lintel_size    = isset( $args['size'] ) && 'large' === $args['size'] ? 'large' : 'default';
$lintel_type    = lintel_project_type();
$lintel_caption = lintel_project_caption();
?>
<article class="project-card project-card--<?php echo esc_attr( $lintel_size ); ?>">
	<div class="project-card__media">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php the_post_thumbnail( 'large' === $lintel_size ? 'lintel-wide' : 'lintel-card', array( 'alt' => '' ) ); ?>
		<?php else : ?>
			<div class="project-card__placeholder" aria-hidden="true"></div>
		<?php endif; ?>
	</div>

	<div class="project-card__body">
		<?php if ( $lintel_type ) : ?>
			<p class="project-card__type"><?php echo esc_html( $lintel_type->name ); ?></p>
		<?php endif; ?>

		<h3 class="project-card__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h3>

		<?php if ( $lintel_caption ) : ?>
			<p class="project-card__meta">
				<?php foreach ( $lintel_caption as $lintel_caption_item ) : ?>
					<span><?php echo esc_html( $lintel_caption_item ); ?></span>
				<?php endforeach; ?>
			</p>
		<?php endif; ?>

		<?php if ( 'large' === $lintel_size && has_excerpt() ) : ?>
			<p class="project-card__summary"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
		<?php endif; ?>
	</div>
</article>
