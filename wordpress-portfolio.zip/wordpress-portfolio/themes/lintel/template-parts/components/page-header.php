<?php
/**
 * Page header used by pages, archives, search results and single views.
 *
 * Accepts $args: title, description (basic HTML allowed), parent and
 * parent_url (a link back to the section the page belongs to).
 *
 * @package Lintel
 */

$lintel_title       = isset( $args['title'] ) ? (string) $args['title'] : get_the_title();
$lintel_description = isset( $args['description'] ) ? (string) $args['description'] : '';
$lintel_parent      = isset( $args['parent'] ) ? (string) $args['parent'] : '';
$lintel_parent_url  = isset( $args['parent_url'] ) ? (string) $args['parent_url'] : '';
?>
<header class="page-header">
	<div class="container page-header__inner">
		<?php if ( $lintel_parent && $lintel_parent_url ) : ?>
			<p class="page-header__parent">
				<a href="<?php echo esc_url( $lintel_parent_url ); ?>"><?php echo esc_html( $lintel_parent ); ?></a>
			</p>
		<?php endif; ?>

		<h1 class="page-header__title"><?php echo wp_kses_post( $lintel_title ); ?></h1>

		<?php if ( $lintel_description ) : ?>
			<div class="page-header__description"><?php echo wp_kses_post( wpautop( $lintel_description ) ); ?></div>
		<?php endif; ?>
	</div>
</header>
