<?php
/**
 * Title block: a ruled table of facts, modelled on the title block in the
 * corner of an engineering drawing.
 *
 * Expects $args['items'] as a list of label and value pairs, and an
 * optional $args['modifier'] such as "dark" or "stacked".
 *
 * @package Lintel
 */

$lintel_items    = isset( $args['items'] ) ? (array) $args['items'] : array();
$lintel_modifier = isset( $args['modifier'] ) ? sanitize_html_class( $args['modifier'] ) : '';

if ( ! $lintel_items ) {
	return;
}
?>
<dl class="title-block<?php echo $lintel_modifier ? ' title-block--' . esc_attr( $lintel_modifier ) : ''; ?>">
	<?php foreach ( $lintel_items as $lintel_item ) : ?>
		<div class="title-block__cell">
			<dt class="title-block__label"><?php echo esc_html( $lintel_item['label'] ); ?></dt>
			<dd class="title-block__value"><?php echo esc_html( $lintel_item['value'] ); ?></dd>
		</div>
	<?php endforeach; ?>
</dl>
