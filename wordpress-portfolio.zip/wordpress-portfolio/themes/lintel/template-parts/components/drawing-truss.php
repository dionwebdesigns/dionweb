<?php
/**
 * Line drawing of a Warren truss bridge, set out like a general
 * arrangement drawing: members, deck, supports, abutments, water level,
 * dimensions and one detail callout.
 *
 * Decorative, so it is hidden from assistive technology. Every stroke has
 * pathLength="1", which lets the stylesheet draw the lines in once on load.
 *
 * @package Lintel
 */

?>
<svg class="drawing" viewBox="0 0 600 390" role="presentation" aria-hidden="true" focusable="false">
	<g class="drawing__ground" fill="none">
		<rect x="20" y="284" width="64" height="56" pathLength="1" />
		<rect x="516" y="284" width="64" height="56" pathLength="1" />
		<path d="M28 340 52 316M44 340 76 308M60 340 84 316M524 340 548 316M540 340 572 308M556 340 580 316" pathLength="1" />
		<path class="drawing__water" d="M84 322H516" pathLength="1" />
		<path d="M292 312h16l-8 10ZM294 328h12M297 333h6" pathLength="1" />
	</g>

	<g class="drawing__members" fill="none">
		<path d="M60 250H540" pathLength="1" />
		<path d="M100 150H500" pathLength="1" />
		<path d="M60 250 100 150 140 250 180 150 220 250 260 150 300 250 340 150 380 250 420 150 460 250 500 150 540 250" pathLength="1" />
		<path d="M180 150v100M260 150v100M340 150v100M420 150v100" pathLength="1" />
		<rect x="50" y="250" width="500" height="12" pathLength="1" />
		<path d="M60 262 48 284h24ZM540 262l-12 22h24ZM526 290h28" pathLength="1" />
	</g>

	<g class="drawing__dimensions" fill="none">
		<path d="M60 344v24M540 344v24M60 360H540M54 366l12-12M534 366l12-12" pathLength="1" />
		<path d="M508 150h76M556 250h28M576 150v100M570 156l12-12M570 256l12-12" pathLength="1" />
		<path d="M18 236h12l-6 10ZM10 250h40" pathLength="1" />
	</g>

	<g class="drawing__labels">
		<text x="300" y="352" text-anchor="middle">24 000</text>
		<text x="590" y="204" text-anchor="middle" transform="rotate(-90 590 200)">4 800</text>
		<text x="30" y="228" text-anchor="middle">+6.250</text>
	</g>

	<g class="drawing__callout" fill="none">
		<circle cx="340" cy="150" r="11" pathLength="1" />
		<path d="M348 142 376 104H436" pathLength="1" />
		<text x="440" y="108">Detail A</text>
	</g>
</svg>
