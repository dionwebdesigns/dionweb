<?php
/**
 * Footer call to action. Hidden on the page the button links to.
 *
 * @package Lintel
 */

$lintel_cta = lintel_get_cta();

if ( is_singular() && untrailingslashit( (string) get_permalink() ) === untrailingslashit( $lintel_cta['url'] ) ) {
	return;
}
?>
<div class="footer-cta">
	<div class="container footer-cta__inner">
		<div class="footer-cta__copy">
			<h2 class="footer-cta__title"><?php echo esc_html( lintel_get_mod( 'cta_heading' ) ); ?></h2>
			<p class="footer-cta__text"><?php echo esc_html( lintel_get_mod( 'cta_text' ) ); ?></p>
		</div>
		<?php lintel_cta_button( 'accent' ); ?>
	</div>
</div>
