<?php
/**
 * Front page projects: one featured project beside two smaller ones.
 * Needs the Groundwork plugin.
 *
 * @package Lintel
 */

if ( ! lintel_groundwork_active() ) {
	return;
}

$lintel_projects = lintel_projects_query( 3 );

if ( ! $lintel_projects->have_posts() ) {
	return;
}
?>
<section class="section section--muted section--projects" aria-labelledby="projects-title">
	<div class="container">
		<div class="section__head">
			<h2 id="projects-title" class="section__title"><?php esc_html_e( 'Selected projects', 'lintel' ); ?></h2>
			<a class="section__link" href="<?php echo esc_url( (string) get_post_type_archive_link( 'gw_project' ) ); ?>"><?php esc_html_e( 'All projects', 'lintel' ); ?></a>
		</div>

		<div class="project-feature">
			<?php
			while ( $lintel_projects->have_posts() ) :
				$lintel_projects->the_post();
				get_template_part(
					'template-parts/cards/card-project',
					null,
					array( 'size' => 0 === $lintel_projects->current_post ? 'large' : 'default' )
				);
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>
