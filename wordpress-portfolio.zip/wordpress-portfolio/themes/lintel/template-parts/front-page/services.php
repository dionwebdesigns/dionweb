<?php
/**
 * Front page services list. Needs the Groundwork plugin.
 *
 * @package Lintel
 */

if ( ! lintel_groundwork_active() ) {
	return;
}

$lintel_services = lintel_services_query( 6 );

if ( ! $lintel_services->have_posts() ) {
	return;
}

$lintel_index = 0;
?>
<section class="section section--services" aria-labelledby="services-title">
	<div class="container split">
		<div class="split__aside">
			<h2 id="services-title" class="section__title"><?php esc_html_e( 'What we do', 'lintel' ); ?></h2>
			<p class="section__intro"><?php esc_html_e( 'One team carries the design and the responsibility, from soil investigation to handover.', 'lintel' ); ?></p>
			<p><a class="section__link" href="<?php echo esc_url( (string) get_post_type_archive_link( 'gw_service' ) ); ?>"><?php esc_html_e( 'All services', 'lintel' ); ?></a></p>
		</div>

		<ul class="services-list split__main" role="list">
			<?php
			while ( $lintel_services->have_posts() ) :
				$lintel_services->the_post();
				?>
				<li class="service">
					<?php lintel_the_service_glyph( $lintel_index ); ?>
					<div class="service__body">
						<h3 class="service__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<?php if ( has_excerpt() ) : ?>
							<p class="service__summary"><?php echo esc_html( get_the_excerpt() ); ?></p>
						<?php endif; ?>
					</div>
				</li>
				<?php
				++$lintel_index;
			endwhile;
			wp_reset_postdata();
			?>
		</ul>
	</div>
</section>
