<?php
/**
 * Front page: the three latest articles.
 *
 * @package Lintel
 */

$lintel_posts = new WP_Query(
	array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => 3,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);

if ( ! $lintel_posts->have_posts() ) {
	return;
}

$lintel_blog_url = get_option( 'page_for_posts' ) ? get_permalink( (int) get_option( 'page_for_posts' ) ) : home_url( '/' );
?>
<section class="section section--insights" aria-labelledby="insights-title">
	<div class="container">
		<div class="section__head">
			<h2 id="insights-title" class="section__title"><?php esc_html_e( 'Insights', 'lintel' ); ?></h2>
			<a class="section__link" href="<?php echo esc_url( (string) $lintel_blog_url ); ?>"><?php esc_html_e( 'All articles', 'lintel' ); ?></a>
		</div>

		<div class="post-grid">
			<?php
			while ( $lintel_posts->have_posts() ) :
				$lintel_posts->the_post();
				get_template_part( 'template-parts/cards/card-post' );
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>
