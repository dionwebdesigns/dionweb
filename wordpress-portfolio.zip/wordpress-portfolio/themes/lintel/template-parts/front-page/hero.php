<?php
/**
 * Front page hero, laid out like a drawing sheet: grid references along
 * the top edge, the headline, a line drawing, and a title block of facts.
 *
 * @package Lintel
 */

$lintel_secondary_label = lintel_get_mod( 'hero_secondary_label' );
$lintel_secondary_url   = lintel_get_mod( 'hero_secondary_url' );
?>
<section class="hero" aria-labelledby="hero-title">
	<div class="hero__refs" aria-hidden="true">
		<span>A</span><span>B</span><span>C</span><span>D</span><span>E</span><span>F</span>
	</div>

	<div class="container hero__inner">
		<div class="hero__content">
			<h1 id="hero-title" class="hero__title"><?php echo esc_html( lintel_get_mod( 'hero_heading' ) ); ?></h1>
			<p class="hero__intro"><?php echo esc_html( lintel_get_mod( 'hero_text' ) ); ?></p>

			<div class="hero__actions">
				<?php lintel_cta_button( 'accent' ); ?>
				<?php if ( $lintel_secondary_label && $lintel_secondary_url ) : ?>
					<a class="button button--ghost" href="<?php echo esc_url( $lintel_secondary_url ); ?>"><?php echo esc_html( $lintel_secondary_label ); ?></a>
				<?php endif; ?>
			</div>
		</div>

		<div class="hero__drawing">
			<?php get_template_part( 'template-parts/components/drawing-truss' ); ?>
		</div>
	</div>

	<div class="container hero__facts">
		<?php lintel_title_block( lintel_get_facts(), 'dark' ); ?>
	</div>
</section>
