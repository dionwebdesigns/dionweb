<?php
/**
 * Front page testimonial, rendered by the Groundwork Testimonials block
 * so the markup and the editor preview stay identical.
 *
 * @package Lintel
 */

if ( ! lintel_groundwork_active() ) {
	return;
}

$lintel_testimonial = do_blocks( '<!-- wp:groundwork/testimonials {"number":1} /-->' );

if ( '' === trim( $lintel_testimonial ) ) {
	return;
}
?>
<section class="section section--testimonial" aria-labelledby="testimonial-title">
	<div class="container container--narrow">
		<h2 id="testimonial-title" class="screen-reader-text"><?php esc_html_e( 'What clients say', 'lintel' ); ?></h2>
		<?php echo $lintel_testimonial; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Block markup, escaped in the block's render.php. ?>
	</div>
</section>
