<?php
/**
 * Filters that adjust WordPress output for this theme.
 *
 * @package Lintel
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adds body classes used by the stylesheet.
 *
 * @param string[] $classes Existing classes.
 * @return string[]
 */
function lintel_body_classes( $classes ) {
	if ( is_singular() && ! is_front_page() ) {
		$classes[] = 'is-singular';
	}

	if ( is_page_template( 'page-templates/template-landing.php' ) ) {
		$classes[] = 'is-landing-page';
	}

	return $classes;
}
add_filter( 'body_class', 'lintel_body_classes' );

/**
 * Removes the "Category:" style prefix from archive titles. The page
 * header already makes the context clear.
 */
add_filter( 'get_the_archive_title_prefix', '__return_empty_string' );

/**
 * Shortens automatic excerpts to fit the cards.
 *
 * @return int
 */
function lintel_excerpt_length() {
	return 28;
}
add_filter( 'excerpt_length', 'lintel_excerpt_length' );

/**
 * Ends automatic excerpts with an ellipsis instead of "[...]".
 *
 * @return string
 */
function lintel_excerpt_more() {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'lintel_excerpt_more' );

/**
 * Adds a toggle button after each main menu item that has a submenu, so
 * submenus open by keyboard and touch as well as on hover.
 *
 * @param string   $item_output Menu item HTML.
 * @param WP_Post  $item        Menu item.
 * @param int      $depth       Depth of the item.
 * @param stdClass $args        Menu arguments.
 * @return string
 */
function lintel_add_submenu_toggle( $item_output, $item, $depth, $args ) {
	if ( 'primary' !== $args->theme_location || ! in_array( 'menu-item-has-children', (array) $item->classes, true ) ) {
		return $item_output;
	}

	return $item_output . sprintf(
		'<button type="button" class="submenu-toggle" aria-expanded="false"><span class="screen-reader-text">%s</span></button>',
		/* translators: %s: menu item title. */
		esc_html( sprintf( __( 'Show submenu for %s', 'lintel' ), wp_strip_all_tags( $item->title ) ) )
	);
}
add_filter( 'walker_nav_menu_start_el', 'lintel_add_submenu_toggle', 10, 4 );

/**
 * Adds a pingback discovery header to single posts that accept pingbacks.
 *
 * @return void
 */
function lintel_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">' . "\n", esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'lintel_pingback_header' );
