<?php
/**
 * Scripts and styles.
 *
 * @package Lintel
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueues the stylesheet, the navigation script and the comment reply script.
 *
 * @return void
 */
function lintel_enqueue_assets() {
	wp_enqueue_style( 'lintel-style', get_stylesheet_uri(), array(), LINTEL_VERSION );
	wp_enqueue_style( 'lintel-blocks', get_template_directory_uri() . '/assets/css/blocks.css', array( 'lintel-style' ), LINTEL_VERSION );

	wp_enqueue_script(
		'lintel-navigation',
		get_template_directory_uri() . '/assets/js/navigation.js',
		array(),
		LINTEL_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	wp_localize_script(
		'lintel-navigation',
		'lintelNavigation',
		array(
			'expand'   => __( 'Show submenu', 'lintel' ),
			'collapse' => __( 'Hide submenu', 'lintel' ),
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'lintel_enqueue_assets' );

/**
 * Preloads the two font files used above the fold, so the hero headline
 * does not reflow when its font arrives.
 *
 * @return void
 */
function lintel_preload_fonts() {
	$fonts = array( 'barlow-latin-400-normal.woff2', 'barlow-condensed-latin-700-normal.woff2' );

	foreach ( $fonts as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_template_directory_uri() . '/assets/fonts/' . $font )
		);
	}
}
add_action( 'wp_head', 'lintel_preload_fonts', 1 );

/**
 * Swaps the no-js class for js before the page renders, so the mobile
 * menu only collapses when the script that opens it can run.
 *
 * @return void
 */
function lintel_javascript_detection() {
	wp_print_inline_script_tag( "document.documentElement.classList.replace('no-js','js');" );
}
add_action( 'wp_head', 'lintel_javascript_detection', 0 );
