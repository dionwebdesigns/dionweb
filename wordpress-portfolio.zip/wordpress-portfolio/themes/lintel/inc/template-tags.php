<?php
/**
 * Template tags: small functions called from templates.
 *
 * @package Lintel
 */

defined( 'ABSPATH' ) || exit;

/**
 * Outputs the publish date as a machine-readable <time> element.
 *
 * @return void
 */
function lintel_posted_on() {
	printf(
		'<time class="entry-date" datetime="%1$s">%2$s</time>',
		esc_attr( get_the_date( DATE_W3C ) ),
		esc_html( get_the_date() )
	);
}

/**
 * Estimates reading time at 220 words a minute.
 *
 * @param int|WP_Post|null $post Post or ID. Defaults to the current post.
 * @return string For example "4 min read".
 */
function lintel_reading_time( $post = null ) {
	$post    = get_post( $post );
	$words   = $post ? str_word_count( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) ) : 0;
	$minutes = max( 1, (int) ceil( $words / 220 ) );

	/* translators: %d: number of minutes. */
	return sprintf( _n( '%d min read', '%d min read', $minutes, 'lintel' ), $minutes );
}

/**
 * Outputs the date, reading time and first category of a post.
 *
 * @return void
 */
function lintel_entry_meta() {
	$categories = get_the_category();
	?>
	<p class="entry-meta">
		<?php if ( $categories ) : ?>
			<a class="entry-meta__category" href="<?php echo esc_url( get_category_link( $categories[0] ) ); ?>"><?php echo esc_html( $categories[0]->name ); ?></a>
		<?php endif; ?>
		<span><?php lintel_posted_on(); ?></span>
		<span><?php echo esc_html( lintel_reading_time() ); ?></span>
	</p>
	<?php
}

/**
 * Outputs the tags of the current post.
 *
 * @return void
 */
function lintel_entry_tags() {
	$tags = get_the_tag_list( '<ul class="entry-tags" aria-label="' . esc_attr__( 'Tags', 'lintel' ) . '"><li>', '</li><li>', '</li></ul>' );

	if ( $tags && ! is_wp_error( $tags ) ) {
		echo wp_kses_post( $tags );
	}
}

/**
 * Outputs pagination for archive and search pages.
 *
 * @return void
 */
function lintel_posts_pagination() {
	the_posts_pagination(
		array(
			'mid_size'           => 1,
			'prev_text'          => __( 'Previous', 'lintel' ),
			'next_text'          => __( 'Next', 'lintel' ),
			'before_page_number' => '<span class="screen-reader-text">' . __( 'Page', 'lintel' ) . ' </span>',
		)
	);
}

/**
 * Outputs the header at the top of pages, archives and search results.
 *
 * @param array $args {
 *     Optional. Header content.
 *
 *     @type string $title       Heading text. Defaults to the current page title.
 *     @type string $description Text under the heading. Plain text or basic HTML.
 *     @type string $parent      Label of the parent section link, if any.
 *     @type string $parent_url  URL of the parent section.
 * }
 * @return void
 */
function lintel_page_header( array $args = array() ) {
	get_template_part( 'template-parts/components/page-header', null, $args );
}

/**
 * Outputs a title block: the ruled table of facts found in the corner of
 * every engineering drawing. Used for company facts and project data.
 *
 * @param array<int, array{label: string, value: string}> $items    Rows to show.
 * @param string                                          $modifier Optional style variant, such as "dark" or "stacked".
 * @return void
 */
function lintel_title_block( array $items, $modifier = '' ) {
	get_template_part(
		'template-parts/components/title-block',
		null,
		array(
			'items'    => $items,
			'modifier' => $modifier,
		)
	);
}

/**
 * Returns the label and URL of the site's main call to action, used in
 * the header and the footer so the action keeps one name everywhere.
 *
 * @return array{label: string, url: string}
 */
function lintel_get_cta() {
	return array(
		'label' => lintel_get_mod( 'cta_label' ),
		'url'   => lintel_get_mod( 'cta_url' ),
	);
}

/**
 * Outputs the site's main call to action as a button.
 *
 * @param string $variant Button style: "primary" or "accent".
 * @return void
 */
function lintel_cta_button( $variant = 'primary' ) {
	$cta = lintel_get_cta();

	if ( '' === $cta['label'] || '' === $cta['url'] ) {
		return;
	}

	printf(
		'<a class="button button--%1$s" href="%2$s">%3$s</a>',
		esc_attr( $variant ),
		esc_url( $cta['url'] ),
		esc_html( $cta['label'] )
	);
}

/**
 * Outputs the logo, or the site name with the theme's mark when no logo
 * has been uploaded.
 *
 * @return void
 */
function lintel_site_branding() {
	if ( has_custom_logo() ) {
		the_custom_logo();
		return;
	}

	$tag = is_front_page() && is_home() ? 'h1' : 'p';

	printf(
		'<%1$s class="site-title"><a href="%2$s" rel="home"><span class="site-title__mark" aria-hidden="true"></span>%3$s</a></%1$s>',
		tag_escape( $tag ),
		esc_url( home_url( '/' ) ),
		esc_html( get_bloginfo( 'name' ) )
	);
}
