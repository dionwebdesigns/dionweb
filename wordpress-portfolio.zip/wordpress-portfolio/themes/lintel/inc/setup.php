<?php
/**
 * Theme setup: supports, menus, image sizes, widget areas and block styles.
 *
 * @package Lintel
 */

defined( 'ABSPATH' ) || exit;

if ( ! isset( $content_width ) ) {
	$content_width = 680; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Core global read by embeds and image sizes.
}

/**
 * Registers theme supports, menus and image sizes.
 *
 * @return void
 */
function lintel_setup() {
	load_theme_textdomain( 'lintel', get_template_directory() . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 48,
			'width'       => 200,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_theme_support( 'editor-styles' );
	add_editor_style( array( 'assets/css/blocks.css', 'assets/css/editor-style.css' ) );

	// Patterns come from the theme's patterns folder only.
	remove_theme_support( 'core-block-patterns' );

	register_nav_menus(
		array(
			'primary' => __( 'Main menu', 'lintel' ),
			'footer'  => __( 'Footer menu', 'lintel' ),
		)
	);

	add_image_size( 'lintel-card', 800, 600, true );
	add_image_size( 'lintel-wide', 1600, 900, true );
}
add_action( 'after_setup_theme', 'lintel_setup' );

/**
 * Registers the footer widget area.
 *
 * @return void
 */
function lintel_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Footer', 'lintel' ),
			'id'            => 'footer-1',
			'description'   => __( 'Shown as an extra column in the site footer.', 'lintel' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'lintel_widgets_init' );

/**
 * Registers the theme's block styles and pattern category.
 *
 * @return void
 */
function lintel_register_block_styles() {
	register_block_style(
		'core/group',
		array(
			'name'  => 'lintel-dark',
			'label' => __( 'Steel panel', 'lintel' ),
		)
	);

	register_block_style(
		'core/table',
		array(
			'name'  => 'lintel-title-block',
			'label' => __( 'Title block', 'lintel' ),
		)
	);

	register_block_style(
		'core/list',
		array(
			'name'  => 'lintel-checklist',
			'label' => __( 'Checklist', 'lintel' ),
		)
	);

	register_block_pattern_category(
		'lintel',
		array(
			'label'       => __( 'Lintel', 'lintel' ),
			'description' => __( 'Sections designed for engineering and construction sites.', 'lintel' ),
		)
	);
}
add_action( 'init', 'lintel_register_block_styles' );
