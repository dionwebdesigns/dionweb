<?php
/**
 * Customizer options.
 *
 * Every option is described once in lintel_customizer_options(), which
 * drives the settings, the controls and the defaults.
 *
 * @package Lintel
 */

defined( 'ABSPATH' ) || exit;

/**
 * Describes every theme option.
 *
 * @return array<string, array{section: string, label: string, type: string, default: string, description?: string, partial?: string}>
 */
function lintel_customizer_options() {
	$options = array(
		'hero_heading'         => array(
			'section' => 'lintel_hero',
			'label'   => __( 'Heading', 'lintel' ),
			'type'    => 'textarea',
			'default' => __( 'Engineering that stands on difficult ground.', 'lintel' ),
			'partial' => '.hero__title',
		),
		'hero_text'            => array(
			'section' => 'lintel_hero',
			'label'   => __( 'Introduction', 'lintel' ),
			'type'    => 'textarea',
			'default' => __( 'We design and build foundations, bridges, drainage and industrial structures, from the first soil test to handover.', 'lintel' ),
			'partial' => '.hero__intro',
		),
		'hero_secondary_label' => array(
			'section'     => 'lintel_hero',
			'label'       => __( 'Second button label', 'lintel' ),
			'description' => __( 'The first button uses the main call to action.', 'lintel' ),
			'type'        => 'text',
			'default'     => __( 'See our projects', 'lintel' ),
		),
		'hero_secondary_url'   => array(
			'section' => 'lintel_hero',
			'label'   => __( 'Second button link', 'lintel' ),
			'type'    => 'url',
			'default' => lintel_groundwork_active() ? home_url( '/projects/' ) : '',
		),
		'cta_label'            => array(
			'section'     => 'lintel_cta',
			'label'       => __( 'Button label', 'lintel' ),
			'description' => __( 'Used in the header, the hero and the footer.', 'lintel' ),
			'type'        => 'text',
			'default'     => __( 'Request a site visit', 'lintel' ),
		),
		'cta_url'              => array(
			'section' => 'lintel_cta',
			'label'   => __( 'Button link', 'lintel' ),
			'type'    => 'url',
			'default' => home_url( '/contact/' ),
		),
		'cta_heading'          => array(
			'section' => 'lintel_cta',
			'label'   => __( 'Footer heading', 'lintel' ),
			'type'    => 'text',
			'default' => __( 'Planning a project?', 'lintel' ),
			'partial' => '.footer-cta__title',
		),
		'cta_text'             => array(
			'section' => 'lintel_cta',
			'label'   => __( 'Footer text', 'lintel' ),
			'type'    => 'textarea',
			'default' => __( 'Tell us about the site and your deadline. An engineer will call you back within two working days.', 'lintel' ),
			'partial' => '.footer-cta__text',
		),
		'phone'                => array(
			'section' => 'lintel_company',
			'label'   => __( 'Phone number', 'lintel' ),
			'type'    => 'text',
			'default' => '',
		),
		'email'                => array(
			'section' => 'lintel_company',
			'label'   => __( 'Email address', 'lintel' ),
			'type'    => 'email',
			'default' => '',
		),
		'address'              => array(
			'section' => 'lintel_company',
			'label'   => __( 'Address', 'lintel' ),
			'type'    => 'textarea',
			'default' => '',
		),
		'hours'                => array(
			'section' => 'lintel_company',
			'label'   => __( 'Opening hours', 'lintel' ),
			'type'    => 'text',
			'default' => '',
		),
		'registration'         => array(
			'section'     => 'lintel_company',
			'label'       => __( 'Registration', 'lintel' ),
			'description' => __( 'For example your company registration number.', 'lintel' ),
			'type'        => 'text',
			'default'     => '',
		),
	);

	$facts = array(
		1 => array( __( 'Established', 'lintel' ), '2009' ),
		2 => array( __( 'Projects delivered', 'lintel' ), '140+' ),
		3 => array( __( 'Registered engineers', 'lintel' ), '18' ),
		4 => array( __( 'Head office', 'lintel' ), __( 'Port Harcourt', 'lintel' ) ),
	);

	foreach ( $facts as $number => $fact ) {
		$options[ "fact_{$number}_label" ] = array(
			'section' => 'lintel_facts',
			/* translators: %d: fact number, 1 to 4. */
			'label'   => sprintf( __( 'Fact %d label', 'lintel' ), $number ),
			'type'    => 'text',
			'default' => $fact[0],
		);
		$options[ "fact_{$number}_value" ] = array(
			'section' => 'lintel_facts',
			/* translators: %d: fact number, 1 to 4. */
			'label'   => sprintf( __( 'Fact %d value', 'lintel' ), $number ),
			'type'    => 'text',
			'default' => $fact[1],
		);
	}

	return $options;
}

/**
 * Returns a theme option, falling back to its default.
 *
 * @param string $key Option key without the lintel_ prefix.
 * @return string
 */
function lintel_get_mod( $key ) {
	$options = lintel_customizer_options();
	$default = isset( $options[ $key ] ) ? $options[ $key ]['default'] : '';

	return (string) get_theme_mod( 'lintel_' . $key, $default );
}

/**
 * Returns the four facts shown in the hero's title block, skipping empty ones.
 *
 * @return array<int, array{label: string, value: string}>
 */
function lintel_get_facts() {
	$facts = array();

	for ( $number = 1; $number <= 4; $number++ ) {
		$label = lintel_get_mod( "fact_{$number}_label" );
		$value = lintel_get_mod( "fact_{$number}_value" );

		if ( '' !== $label && '' !== $value ) {
			$facts[] = array(
				'label' => $label,
				'value' => $value,
			);
		}
	}

	return $facts;
}

/**
 * Registers sections, settings, controls and live-preview partials.
 *
 * @param WP_Customize_Manager $wp_customize Customizer instance.
 * @return void
 */
function lintel_customize_register( $wp_customize ) {
	$wp_customize->add_panel(
		'lintel_options',
		array(
			'title'    => __( 'Theme options', 'lintel' ),
			'priority' => 30,
		)
	);

	$sections = array(
		'lintel_hero'    => __( 'Front page hero', 'lintel' ),
		'lintel_facts'   => __( 'Title block facts', 'lintel' ),
		'lintel_cta'     => __( 'Call to action', 'lintel' ),
		'lintel_company' => __( 'Company details', 'lintel' ),
	);

	foreach ( $sections as $id => $title ) {
		$wp_customize->add_section(
			$id,
			array(
				'title' => $title,
				'panel' => 'lintel_options',
			)
		);
	}

	$sanitizers = array(
		'text'     => 'sanitize_text_field',
		'textarea' => 'sanitize_textarea_field',
		'url'      => 'esc_url_raw',
		'email'    => 'sanitize_email',
	);

	foreach ( lintel_customizer_options() as $key => $option ) {
		$setting_id = 'lintel_' . $key;

		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $option['default'],
				'sanitize_callback' => $sanitizers[ $option['type'] ],
				'transport'         => isset( $option['partial'] ) ? 'postMessage' : 'refresh',
			)
		);

		$wp_customize->add_control(
			$setting_id,
			array(
				'label'       => $option['label'],
				'description' => isset( $option['description'] ) ? $option['description'] : '',
				'section'     => $option['section'],
				'type'        => $option['type'],
			)
		);

		if ( isset( $option['partial'] ) && isset( $wp_customize->selective_refresh ) ) {
			$wp_customize->selective_refresh->add_partial(
				$setting_id,
				array(
					'selector'        => $option['partial'],
					'render_callback' => static function () use ( $key ) {
						echo esc_html( lintel_get_mod( $key ) );
					},
				)
			);
		}
	}
}
add_action( 'customize_register', 'lintel_customize_register' );
