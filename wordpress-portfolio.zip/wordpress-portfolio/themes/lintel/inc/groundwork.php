<?php
/**
 * Integration with the Groundwork plugin.
 *
 * Lintel works without the plugin. When Groundwork is active, the front
 * page gains services, projects and testimonials sections, and projects
 * get their own case study template.
 *
 * @package Lintel
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the Groundwork plugin is active.
 *
 * @return bool
 */
function lintel_groundwork_active() {
	return function_exists( 'groundwork_get_project_details' );
}

/**
 * Orders the services archive by hand and fits the projects archive to
 * whole rows of three cards.
 *
 * @param WP_Query $query Query being prepared.
 * @return void
 */
function lintel_adjust_archive_queries( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}

	if ( $query->is_post_type_archive( 'gw_service' ) ) {
		$query->set(
			'orderby',
			array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			)
		);
		$query->set( 'posts_per_page', 50 );
	}

	if ( $query->is_post_type_archive( 'gw_project' ) || $query->is_tax( 'gw_project_type' ) ) {
		$query->set( 'posts_per_page', 9 );
	}
}
add_action( 'pre_get_posts', 'lintel_adjust_archive_queries' );

/**
 * Queries published services in their custom order.
 *
 * @param int $number Maximum number of services.
 * @return WP_Query
 */
function lintel_services_query( $number = 6 ) {
	return new WP_Query(
		array(
			'post_type'      => 'gw_service',
			'post_status'    => 'publish',
			'posts_per_page' => $number,
			'orderby'        => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
			'no_found_rows'  => true,
		)
	);
}

/**
 * Queries published projects, newest first.
 *
 * @param int   $number  Maximum number of projects.
 * @param array $extra   Extra WP_Query arguments.
 * @return WP_Query
 */
function lintel_projects_query( $number = 3, array $extra = array() ) {
	return new WP_Query(
		array_merge(
			array(
				'post_type'      => 'gw_project',
				'post_status'    => 'publish',
				'posts_per_page' => $number,
				'no_found_rows'  => true,
			),
			$extra
		)
	);
}

/**
 * Returns the location and year of a project, for card captions.
 *
 * @param int|WP_Post|null $post Project. Defaults to the current post.
 * @return string[]
 */
function lintel_project_caption( $post = null ) {
	if ( ! lintel_groundwork_active() ) {
		return array();
	}

	$details = groundwork_get_project_details( $post );

	return array_values(
		array_filter(
			array(
				isset( $details['location'] ) ? $details['location']['value'] : '',
				isset( $details['year'] ) ? $details['year']['value'] : '',
			)
		)
	);
}

/**
 * Returns the first project type of a project.
 *
 * @param int|WP_Post|null $post Project. Defaults to the current post.
 * @return WP_Term|null
 */
function lintel_project_type( $post = null ) {
	$terms = get_the_terms( get_post( $post ), 'gw_project_type' );

	return $terms && ! is_wp_error( $terms ) ? $terms[0] : null;
}

/**
 * Returns a small outlined geometric glyph that marks a service in a list.
 *
 * The shapes echo the symbols used on engineering drawings. They are
 * decorative, so they are hidden from assistive technology.
 *
 * @param int $index Position of the service in the list, from 0.
 * @return string SVG markup.
 */
function lintel_service_glyph( $index ) {
	$shapes = array(
		'<rect x="3" y="3" width="18" height="18" />',
		'<path d="M12 3 21 20H3Z" />',
		'<circle cx="12" cy="12" r="9" />',
		'<path d="M3 21V12a9 9 0 0 1 18 0v9Z" />',
		'<path d="M12 2.5 21.5 12 12 21.5 2.5 12Z" />',
		'<path d="M7 3h10l5 9-5 9H7l-5-9Z" />',
	);

	return sprintf(
		'<svg class="service__glyph" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.5">%s</svg>',
		$shapes[ absint( $index ) % count( $shapes ) ]
	);
}

/**
 * Outputs a service glyph through an SVG allow-list.
 *
 * @param int $index Position of the service in the list, from 0.
 * @return void
 */
function lintel_the_service_glyph( $index ) {
	$shape_attributes = array(
		'x'      => true,
		'y'      => true,
		'width'  => true,
		'height' => true,
		'cx'     => true,
		'cy'     => true,
		'r'      => true,
		'd'      => true,
	);

	echo wp_kses(
		lintel_service_glyph( $index ),
		array(
			'svg'    => array(
				'class'        => true,
				'viewbox'      => true,
				'width'        => true,
				'height'       => true,
				'aria-hidden'  => true,
				'focusable'    => true,
				'fill'         => true,
				'stroke'       => true,
				'stroke-width' => true,
			),
			'rect'   => $shape_attributes,
			'circle' => $shape_attributes,
			'path'   => $shape_attributes,
		)
	);
}
