<?php
/**
 * Single project, laid out as a case study with a project data sheet.
 *
 * @package Lintel
 */

get_header();

while ( have_posts() ) :
	the_post();

	$lintel_project_id = get_the_ID();
	$lintel_type       = lintel_project_type();
	$lintel_data       = array();

	if ( $lintel_type ) {
		$lintel_data[] = array(
			'label' => __( 'Type', 'lintel' ),
			'value' => $lintel_type->name,
		);
	}

	if ( lintel_groundwork_active() ) {
		$lintel_data = array_merge( $lintel_data, array_values( groundwork_get_project_details() ) );
	}

	lintel_page_header(
		array(
			'title'       => get_the_title(),
			'description' => has_excerpt() ? get_the_excerpt() : '',
			'parent'      => __( 'Projects', 'lintel' ),
			'parent_url'  => (string) get_post_type_archive_link( 'gw_project' ),
		)
	);
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'project' ); ?>>
		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="project__media container">
				<?php the_post_thumbnail( 'lintel-wide' ); ?>
			</figure>
		<?php endif; ?>

		<div class="container project__layout">
			<div class="project__content entry-content">
				<?php the_content(); ?>
			</div>

			<?php if ( $lintel_data ) : ?>
				<aside class="project__data" aria-labelledby="project-data-title">
					<h2 id="project-data-title" class="project__data-title"><?php esc_html_e( 'Project data', 'lintel' ); ?></h2>
					<?php lintel_title_block( $lintel_data, 'stacked' ); ?>
				</aside>
			<?php endif; ?>
		</div>
	</article>
	<?php
endwhile;

$lintel_related_args = array( 'post__not_in' => array( $lintel_project_id ) );

if ( $lintel_type ) {
	// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One term filter, three posts.
	$lintel_related_args['tax_query'] = array(
		array(
			'taxonomy' => 'gw_project_type',
			'terms'    => $lintel_type->term_id,
		),
	);
}

$lintel_related = lintel_projects_query( 3, $lintel_related_args );

if ( ! $lintel_related->have_posts() ) {
	unset( $lintel_related_args['tax_query'] );
	$lintel_related = lintel_projects_query( 3, $lintel_related_args );
}

if ( $lintel_related->have_posts() ) :
	?>
	<section class="section section--muted" aria-labelledby="related-title">
		<div class="container">
			<div class="section__head">
				<h2 id="related-title" class="section__title"><?php esc_html_e( 'More projects', 'lintel' ); ?></h2>
				<a class="section__link" href="<?php echo esc_url( (string) get_post_type_archive_link( 'gw_project' ) ); ?>"><?php esc_html_e( 'All projects', 'lintel' ); ?></a>
			</div>
			<div class="project-grid">
				<?php
				while ( $lintel_related->have_posts() ) :
					$lintel_related->the_post();
					get_template_part( 'template-parts/cards/card-project' );
				endwhile;
				wp_reset_postdata();
				?>
			</div>
		</div>
	</section>
	<?php
endif;

get_footer();
