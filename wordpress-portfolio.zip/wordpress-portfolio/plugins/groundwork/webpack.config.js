/**
 * Extends the @wordpress/scripts build.
 *
 * The default config finds every block.json under src/. The editor sidebar
 * panel is not a block, so it is added as an extra entry point.
 */
const defaultConfig = require( '@wordpress/scripts/config/webpack.config' );

module.exports = {
	...defaultConfig,
	entry: () => ( {
		...defaultConfig.entry(),
		'details-panel/index': './src/details-panel/index.js',
	} ),
};
