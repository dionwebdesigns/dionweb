<?php
/**
 * Plugin Name:       Groundwork
 * Plugin URI:        https://github.com/emediong/wordpress-portfolio
 * Description:       Site functionality that should outlive any theme: projects, services and testimonials, three editor blocks and a secure contact form.
 * Version:           1.0.0
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Author:            Innocent Emediong Friday
 * Author URI:        https://emediong.dev
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       groundwork
 * Domain Path:       /languages
 *
 * @package Groundwork
 */

namespace Groundwork;

defined( 'ABSPATH' ) || exit;

define( 'GROUNDWORK_VERSION', '1.0.0' );
define( 'GROUNDWORK_FILE', __FILE__ );
define( 'GROUNDWORK_PATH', plugin_dir_path( __FILE__ ) );
define( 'GROUNDWORK_URL', plugin_dir_url( __FILE__ ) );

/*
 * Classes follow the WordPress file naming convention:
 * Groundwork\Contact_Form lives in includes/class-contact-form.php.
 */
spl_autoload_register(
	static function ( $class_name ) {
		$prefix = __NAMESPACE__ . '\\';

		if ( 0 !== strpos( $class_name, $prefix ) ) {
			return;
		}

		$relative = substr( $class_name, strlen( $prefix ) );
		$file     = GROUNDWORK_PATH . 'includes/class-' . strtolower( str_replace( '_', '-', $relative ) ) . '.php';

		if ( is_readable( $file ) ) {
			require_once $file;
		}
	}
);

require_once GROUNDWORK_PATH . 'includes/functions.php';

register_activation_hook( __FILE__, array( Plugin::class, 'activate' ) );
register_deactivation_hook( __FILE__, array( Plugin::class, 'deactivate' ) );

Plugin::instance()->boot();
