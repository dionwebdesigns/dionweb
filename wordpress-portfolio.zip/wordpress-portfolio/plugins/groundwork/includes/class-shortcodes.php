<?php
/**
 * Shortcodes.
 *
 * @package Groundwork
 */

namespace Groundwork;

defined( 'ABSPATH' ) || exit;

/**
 * Makes the blocks available where the block editor is not used, such as
 * page builders (Elementor, WPBakery), widgets and the Classic Editor.
 *
 * Each shortcode renders the matching block, so there is one template and
 * one stylesheet per component.
 *
 * Usage:
 *     [groundwork_projects count="6" columns="3" type="bridges-and-roads"]
 *     [groundwork_testimonials count="2"]
 *     [groundwork_contact_form button="Request a quote"]
 */
final class Shortcodes {

	/**
	 * Registers the shortcodes.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'init', array( $this, 'register' ) );
	}

	/**
	 * Adds each shortcode.
	 *
	 * @return void
	 */
	public function register(): void {
		add_shortcode( 'groundwork_projects', array( $this, 'projects' ) );
		add_shortcode( 'groundwork_testimonials', array( $this, 'testimonials' ) );
		add_shortcode( 'groundwork_contact_form', array( $this, 'contact_form' ) );
	}

	/**
	 * Renders [groundwork_projects].
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public function projects( $atts ): string {
		$atts = shortcode_atts(
			array(
				'count'   => 6,
				'columns' => 3,
				'type'    => '',
				'orderby' => 'date',
			),
			$atts,
			'groundwork_projects'
		);

		return $this->render(
			'groundwork/project-grid',
			array(
				'number'      => absint( $atts['count'] ),
				'columns'     => absint( $atts['columns'] ),
				'projectType' => sanitize_title( $atts['type'] ),
				'orderBy'     => sanitize_key( $atts['orderby'] ),
			)
		);
	}

	/**
	 * Renders [groundwork_testimonials].
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public function testimonials( $atts ): string {
		$atts = shortcode_atts(
			array(
				'count'   => 3,
				'columns' => 1,
			),
			$atts,
			'groundwork_testimonials'
		);

		return $this->render(
			'groundwork/testimonials',
			array(
				'number'  => absint( $atts['count'] ),
				'columns' => absint( $atts['columns'] ),
			)
		);
	}

	/**
	 * Renders [groundwork_contact_form].
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public function contact_form( $atts ): string {
		$atts = shortcode_atts(
			array(
				'button'  => '',
				'phone'   => 'yes',
				'company' => 'no',
			),
			$atts,
			'groundwork_contact_form'
		);

		return $this->render(
			'groundwork/contact-form',
			array(
				'buttonLabel' => sanitize_text_field( $atts['button'] ),
				'showPhone'   => 'no' !== $atts['phone'],
				'showCompany' => 'yes' === $atts['company'],
			)
		);
	}

	/**
	 * Renders a block from attributes.
	 *
	 * @param string $name       Block name.
	 * @param array  $attributes Block attributes.
	 * @return string
	 */
	private function render( string $name, array $attributes ): string {
		return render_block(
			array(
				'blockName'    => $name,
				'attrs'        => $attributes,
				'innerBlocks'  => array(),
				'innerHTML'    => '',
				'innerContent' => array(),
			)
		);
	}
}
