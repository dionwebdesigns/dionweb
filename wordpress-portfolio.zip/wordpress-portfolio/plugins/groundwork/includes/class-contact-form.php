<?php
/**
 * Contact form processing.
 *
 * @package Groundwork
 */

namespace Groundwork;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

defined( 'ABSPATH' ) || exit;

/**
 * Validates, stores and emails enquiries sent through the contact form.
 *
 * The form works two ways that share one code path, process():
 * - With JavaScript it posts JSON to a REST API route and shows the result
 *   in place, with errors next to the fields they belong to.
 * - Without JavaScript it posts to admin-post.php, and the visitor is sent
 *   back to the form, which shows the same result.
 *
 * Spam is filtered without a CAPTCHA: a hidden honeypot field, a signed
 * timestamp that rejects instant submissions, and a rate limit per address.
 */
final class Contact_Form {

	public const ACTION         = 'groundwork_contact';
	public const REST_NAMESPACE = 'groundwork/v1';
	public const REST_ROUTE     = '/enquiries';
	public const RESULT_PARAM   = 'gw_form';
	private const MIN_SECONDS   = 3;
	private const MAX_AGE       = 2 * DAY_IN_SECONDS;
	private const RATE_LIMIT    = 5;
	private const RATE_WINDOW   = 10 * MINUTE_IN_SECONDS;

	/**
	 * Hooks the REST route and the no-JavaScript handler into WordPress.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'rest_api_init', array( $this, 'register_route' ) );
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle_post' ) );
		add_action( 'admin_post_nopriv_' . self::ACTION, array( $this, 'handle_post' ) );
	}

	/**
	 * Fields accepted from the form, with their labels and limits.
	 *
	 * @return array<string, array{label: string, required: bool, max: int}>
	 */
	public static function fields(): array {
		return array(
			'name'    => array(
				'label'    => __( 'Full name', 'groundwork' ),
				'required' => true,
				'max'      => 100,
			),
			'email'   => array(
				'label'    => __( 'Email address', 'groundwork' ),
				'required' => true,
				'max'      => 254,
			),
			'phone'   => array(
				'label'    => __( 'Phone number', 'groundwork' ),
				'required' => false,
				'max'      => 30,
			),
			'company' => array(
				'label'    => __( 'Company or organisation', 'groundwork' ),
				'required' => false,
				'max'      => 120,
			),
			'subject' => array(
				'label'    => __( 'Enquiry type', 'groundwork' ),
				'required' => false,
				'max'      => 120,
			),
			'message' => array(
				'label'    => __( 'Message', 'groundwork' ),
				'required' => true,
				'max'      => 5000,
			),
		);
	}

	/**
	 * Registers POST /wp-json/groundwork/v1/enquiries.
	 *
	 * @return void
	 */
	public function register_route(): void {
		$args = array();

		foreach ( array_merge( array_keys( self::fields() ), array( 'website', '_gw_nonce', '_gw_ts', '_gw_source' ) ) as $param ) {
			$args[ $param ] = array(
				'type'     => 'string',
				'required' => false,
			);
		}

		register_rest_route(
			self::REST_NAMESPACE,
			self::REST_ROUTE,
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle_rest' ),
				// The form is public. Each request is verified in process().
				'permission_callback' => '__return_true',
				'args'                => $args,
			)
		);
	}

	/**
	 * Handles a submission sent by the form's JavaScript.
	 *
	 * @param WP_REST_Request $request Incoming request.
	 * @return WP_REST_Response
	 */
	public function handle_rest( WP_REST_Request $request ): WP_REST_Response {
		$result = $this->process( (array) $request->get_params(), $this->client_ip() );

		if ( is_wp_error( $result ) ) {
			$data = (array) $result->get_error_data();

			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => $result->get_error_message(),
					'errors'  => isset( $data['fields'] ) ? $data['fields'] : (object) array(),
				),
				isset( $data['status'] ) ? (int) $data['status'] : 400
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => $result,
			),
			201
		);
	}

	/**
	 * Handles a submission from a browser without JavaScript, then sends the
	 * visitor back to the form with a short-lived key to the result.
	 *
	 * @return void
	 */
	public function handle_post(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The nonce is verified and every field is sanitised in process().
		$input  = (array) wp_unslash( $_POST );
		$result = $this->process( $input, $this->client_ip() );
		$key    = wp_generate_password( 20, false );
		$anchor = isset( $input['_gw_anchor'] ) ? sanitize_html_class( (string) $input['_gw_anchor'] ) : '';

		if ( is_wp_error( $result ) ) {
			$data   = (array) $result->get_error_data();
			$values = $this->sanitize( $input );

			// Keep a mistyped address so the visitor can correct it rather than retype it.
			$values['email'] = isset( $input['email'] ) ? sanitize_text_field( (string) $input['email'] ) : '';

			$state = array(
				'status'  => 'error',
				'message' => $result->get_error_message(),
				'errors'  => isset( $data['fields'] ) ? $data['fields'] : array(),
				'values'  => $values,
			);
		} else {
			$state = array(
				'status'  => 'sent',
				'message' => $result,
				'errors'  => array(),
				'values'  => array(),
			);
		}

		$state['anchor'] = $anchor;

		set_transient( 'groundwork_form_' . $key, $state, 10 * MINUTE_IN_SECONDS );

		$referer  = wp_get_referer();
		$redirect = $referer ? remove_query_arg( self::RESULT_PARAM, $referer ) : home_url( '/' );
		$redirect = add_query_arg( self::RESULT_PARAM, $key, $redirect );

		wp_safe_redirect( $anchor ? $redirect . '#' . $anchor : $redirect );
		exit;
	}

	/**
	 * Returns the result stored for a visitor without JavaScript, but only to
	 * the form that sent it when a page has more than one.
	 *
	 * The result expires after ten minutes rather than on first read, because
	 * plugins that build excerpts can render a page before the visitor sees it.
	 *
	 * @param string $key     Key from the redirect URL.
	 * @param string $form_id HTML ID of the form being rendered.
	 * @return array{status: string, message: string, errors: array, values: array}|null
	 */
	public static function get_result( string $key, string $form_id ): ?array {
		$key = preg_replace( '/[^A-Za-z0-9]/', '', $key );

		if ( '' === $key ) {
			return null;
		}

		$state = get_transient( 'groundwork_form_' . $key );

		if ( ! is_array( $state ) || ( ! empty( $state['anchor'] ) && $state['anchor'] !== $form_id ) ) {
			return null;
		}

		return $state;
	}

	/**
	 * Checks a submission and, when it passes, stores and emails it.
	 *
	 * @param array  $input Submitted values, already unslashed.
	 * @param string $ip    Sender's IP address, used for rate limiting.
	 * @return string|WP_Error Success message, or why the enquiry was refused.
	 */
	public function process( array $input, string $ip ) {
		$nonce = isset( $input['_gw_nonce'] ) ? (string) $input['_gw_nonce'] : '';

		if ( ! wp_verify_nonce( $nonce, self::ACTION ) ) {
			return new WP_Error(
				'groundwork_expired',
				__( 'This form has expired. Refresh the page, then send your enquiry again.', 'groundwork' ),
				array( 'status' => 403 )
			);
		}

		// Real visitors never see the honeypot field. Bots that fill it are
		// told the enquiry was sent, so they learn nothing about the filter.
		if ( ! empty( $input['website'] ) ) {
			return self::success_message();
		}

		if ( ! $this->verify_timestamp( isset( $input['_gw_ts'] ) ? (string) $input['_gw_ts'] : '' ) ) {
			return new WP_Error(
				'groundwork_too_fast',
				__( 'The form was sent too quickly. Check your details, then send it again.', 'groundwork' ),
				array( 'status' => 400 )
			);
		}

		if ( $this->is_rate_limited( $ip ) ) {
			return new WP_Error(
				'groundwork_rate_limited',
				__( 'Several enquiries have just been sent from your connection. Try again in ten minutes.', 'groundwork' ),
				array( 'status' => 429 )
			);
		}

		$data   = $this->sanitize( $input );
		$errors = $this->validate( $data );

		if ( $errors ) {
			return new WP_Error(
				'groundwork_invalid',
				__( 'Check the highlighted fields, then send the form again.', 'groundwork' ),
				array(
					'status' => 422,
					'fields' => $errors,
				)
			);
		}

		$this->record_attempt( $ip );

		$data['source'] = isset( $input['_gw_source'] ) ? esc_url_raw( (string) $input['_gw_source'] ) : '';

		$enquiry_id = Settings::get( 'store_enquiries' ) ? Enquiries::store( $data ) : 0;
		$sent       = $this->send_email( $data );

		if ( ! $sent && ! $enquiry_id ) {
			return new WP_Error(
				'groundwork_not_sent',
				__( 'Your enquiry could not be delivered. Email us directly and we will reply as soon as we can.', 'groundwork' ),
				array( 'status' => 500 )
			);
		}

		/**
		 * Fires after an enquiry passes every check.
		 *
		 * Use it to send the enquiry to a CRM or a chat channel.
		 *
		 * @param array $data       Sanitised enquiry fields.
		 * @param int   $enquiry_id Stored enquiry ID, or 0 when storage is off.
		 * @param bool  $sent       Whether the notification email was accepted for delivery.
		 */
		do_action( 'groundwork_enquiry_received', $data, $enquiry_id, $sent );

		return self::success_message();
	}

	/**
	 * Builds the signed timestamp printed in the form.
	 *
	 * @return string
	 */
	public static function create_timestamp(): string {
		$time = (string) time();

		return $time . '.' . wp_hash( $time . '|' . self::ACTION, 'nonce' );
	}

	/**
	 * Message shown after a successful submission.
	 *
	 * @return string
	 */
	public static function success_message(): string {
		return (string) Settings::get( 'success_message' );
	}

	/**
	 * Cleans every accepted field.
	 *
	 * @param array $input Submitted values, already unslashed.
	 * @return array<string, string>
	 */
	private function sanitize( array $input ): array {
		$data = array();

		foreach ( array_keys( self::fields() ) as $key ) {
			$value = isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) ? (string) $input[ $key ] : '';

			switch ( $key ) {
				case 'email':
					$data[ $key ] = sanitize_email( $value );
					break;
				case 'message':
					$data[ $key ] = sanitize_textarea_field( $value );
					break;
				default:
					$data[ $key ] = sanitize_text_field( $value );
			}
		}

		return $data;
	}

	/**
	 * Checks the cleaned fields and explains how to fix each problem.
	 *
	 * @param array<string, string> $data Sanitised fields.
	 * @return array<string, string> Error messages keyed by field.
	 */
	private function validate( array $data ): array {
		$errors = array();

		if ( '' === $data['name'] ) {
			$errors['name'] = __( 'Enter your full name.', 'groundwork' );
		}

		if ( '' === $data['email'] || ! is_email( $data['email'] ) ) {
			$errors['email'] = __( 'Enter an email address in the format name@example.com.', 'groundwork' );
		}

		if ( '' !== $data['phone'] && ! preg_match( '/^[0-9 +().\-]{6,30}$/', $data['phone'] ) ) {
			$errors['phone'] = __( 'Enter a phone number using digits, spaces and the symbols + ( ) - only.', 'groundwork' );
		}

		if ( mb_strlen( $data['message'] ) < 10 ) {
			$errors['message'] = __( 'Write a message of at least 10 characters.', 'groundwork' );
		}

		foreach ( self::fields() as $key => $field ) {
			if ( ! isset( $errors[ $key ] ) && mb_strlen( $data[ $key ] ) > $field['max'] ) {
				/* translators: %d: maximum number of characters. */
				$errors[ $key ] = sprintf( __( 'Shorten this to %d characters or fewer.', 'groundwork' ), $field['max'] );
			}
		}

		return $errors;
	}

	/**
	 * Accepts a timestamp only when it is genuine and the form was on screen
	 * for at least a few seconds.
	 *
	 * @param string $token Value of the hidden timestamp field.
	 * @return bool
	 */
	private function verify_timestamp( string $token ): bool {
		$parts = explode( '.', $token, 2 );

		if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) ) {
			return false;
		}

		if ( ! hash_equals( wp_hash( $parts[0] . '|' . self::ACTION, 'nonce' ), $parts[1] ) ) {
			return false;
		}

		$age = time() - (int) $parts[0];

		return $age >= self::MIN_SECONDS && $age <= self::MAX_AGE;
	}

	/**
	 * Transient key for an address, hashed so raw IPs are never stored.
	 *
	 * @param string $ip IP address.
	 * @return string
	 */
	private function rate_key( string $ip ): string {
		return 'groundwork_rl_' . substr( wp_hash( $ip ), 0, 20 );
	}

	/**
	 * Whether an address has sent too many enquiries recently.
	 *
	 * @param string $ip IP address.
	 * @return bool
	 */
	private function is_rate_limited( string $ip ): bool {
		return (int) get_transient( $this->rate_key( $ip ) ) >= self::RATE_LIMIT;
	}

	/**
	 * Counts an accepted enquiry against an address.
	 *
	 * @param string $ip IP address.
	 * @return void
	 */
	private function record_attempt( string $ip ): void {
		$key = $this->rate_key( $ip );

		set_transient( $key, (int) get_transient( $key ) + 1, self::RATE_WINDOW );
	}

	/**
	 * Visitor's IP address.
	 *
	 * Sites behind a trusted proxy or CDN can use the filter to read the
	 * forwarded address instead.
	 *
	 * @return string
	 */
	private function client_ip(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		/**
		 * Filters the address used to rate-limit enquiries.
		 *
		 * @param string $ip Address taken from REMOTE_ADDR.
		 */
		$ip = (string) apply_filters( 'groundwork_client_ip', $ip );

		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	}

	/**
	 * Emails the enquiry to the site owner, with Reply-To set to the sender.
	 *
	 * @param array<string, string> $data Sanitised fields.
	 * @return bool Whether the email was accepted for delivery.
	 */
	private function send_email( array $data ): bool {
		/**
		 * Filters who receives enquiry notifications.
		 *
		 * @param string|string[] $recipient Email address or addresses.
		 * @param array           $data      Sanitised enquiry fields.
		 */
		$recipient = apply_filters( 'groundwork_enquiry_recipient', Settings::get( 'recipient' ), $data );
		$site_name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

		/* translators: 1: site name, 2: sender's name. */
		$subject = sprintf( __( '[%1$s] New enquiry from %2$s', 'groundwork' ), $site_name, $data['name'] );

		$lines = array();

		foreach ( self::fields() as $key => $field ) {
			if ( 'message' !== $key && '' !== $data[ $key ] ) {
				$lines[] = $field['label'] . ': ' . $data[ $key ];
			}
		}

		$body = implode( "\n", $lines ) . "\n\n" . $data['message'] . "\n\n";

		if ( '' !== $data['source'] ) {
			/* translators: %s: URL of the page the form was sent from. */
			$body .= sprintf( __( 'Sent from %s', 'groundwork' ), $data['source'] ) . "\n";
		}

		$reply_name = str_replace( array( '"', '<', '>' ), '', $data['name'] );
		$headers    = array( sprintf( 'Reply-To: "%1$s" <%2$s>', $reply_name, $data['email'] ) );

		return (bool) wp_mail( $recipient, $subject, $body, $headers );
	}
}
