<?php
/**
 * Custom post types and taxonomy.
 *
 * @package Groundwork
 */

namespace Groundwork;

defined( 'ABSPATH' ) || exit;

/**
 * Registers projects, services, testimonials and the project type taxonomy.
 *
 * Post type keys use the short `gw_` prefix because WordPress limits
 * post type keys to 20 characters.
 */
final class Post_Types {

	public const PROJECT      = 'gw_project';
	public const SERVICE      = 'gw_service';
	public const TESTIMONIAL  = 'gw_testimonial';
	public const PROJECT_TYPE = 'gw_project_type';

	/**
	 * Hooks the registration into WordPress.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'init', array( $this, 'register' ) );
		add_filter( 'enter_title_here', array( $this, 'title_placeholder' ), 10, 2 );
	}

	/**
	 * Registers every post type and taxonomy.
	 *
	 * @return void
	 */
	public function register(): void {
		$this->register_projects();
		$this->register_services();
		$this->register_testimonials();
		$this->register_project_types();
	}

	/**
	 * Projects: completed or ongoing work, shown as case studies.
	 *
	 * @return void
	 */
	private function register_projects(): void {
		register_post_type(
			self::PROJECT,
			array(
				'labels'        => array(
					'name'                  => _x( 'Projects', 'post type general name', 'groundwork' ),
					'singular_name'         => _x( 'Project', 'post type singular name', 'groundwork' ),
					'add_new_item'          => __( 'Add new project', 'groundwork' ),
					'edit_item'             => __( 'Edit project', 'groundwork' ),
					'new_item'              => __( 'New project', 'groundwork' ),
					'view_item'             => __( 'View project', 'groundwork' ),
					'view_items'            => __( 'View projects', 'groundwork' ),
					'search_items'          => __( 'Search projects', 'groundwork' ),
					'not_found'             => __( 'No projects found.', 'groundwork' ),
					'not_found_in_trash'    => __( 'No projects found in Trash.', 'groundwork' ),
					'all_items'             => __( 'All projects', 'groundwork' ),
					'archives'              => __( 'Projects', 'groundwork' ),
					'featured_image'        => __( 'Project image', 'groundwork' ),
					'set_featured_image'    => __( 'Set project image', 'groundwork' ),
					'remove_featured_image' => __( 'Remove project image', 'groundwork' ),
					'item_published'        => __( 'Project published.', 'groundwork' ),
					'item_updated'          => __( 'Project updated.', 'groundwork' ),
				),
				'public'        => true,
				'show_in_rest'  => true,
				'menu_position' => 20,
				'menu_icon'     => 'dashicons-building',
				'has_archive'   => true,
				'rewrite'       => array(
					'slug'       => 'projects',
					'with_front' => false,
				),
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields', 'page-attributes' ),
				'template'      => array(
					array(
						'core/paragraph',
						array( 'placeholder' => __( 'Summarise the project in two or three sentences.', 'groundwork' ) ),
					),
					array( 'core/heading', array( 'content' => __( 'The brief', 'groundwork' ) ) ),
					array(
						'core/paragraph',
						array( 'placeholder' => __( 'What did the client need, and what made it difficult?', 'groundwork' ) ),
					),
					array( 'core/heading', array( 'content' => __( 'Our approach', 'groundwork' ) ) ),
					array(
						'core/paragraph',
						array( 'placeholder' => __( 'How the team designed and delivered the work.', 'groundwork' ) ),
					),
					array( 'core/heading', array( 'content' => __( 'Outcome', 'groundwork' ) ) ),
					array(
						'core/paragraph',
						array( 'placeholder' => __( 'What changed for the client once the work was handed over.', 'groundwork' ) ),
					),
				),
			)
		);
	}

	/**
	 * Services: what the business offers, ordered by hand.
	 *
	 * @return void
	 */
	private function register_services(): void {
		register_post_type(
			self::SERVICE,
			array(
				'labels'        => array(
					'name'               => _x( 'Services', 'post type general name', 'groundwork' ),
					'singular_name'      => _x( 'Service', 'post type singular name', 'groundwork' ),
					'add_new_item'       => __( 'Add new service', 'groundwork' ),
					'edit_item'          => __( 'Edit service', 'groundwork' ),
					'new_item'           => __( 'New service', 'groundwork' ),
					'view_item'          => __( 'View service', 'groundwork' ),
					'view_items'         => __( 'View services', 'groundwork' ),
					'search_items'       => __( 'Search services', 'groundwork' ),
					'not_found'          => __( 'No services found.', 'groundwork' ),
					'not_found_in_trash' => __( 'No services found in Trash.', 'groundwork' ),
					'all_items'          => __( 'All services', 'groundwork' ),
					'archives'           => __( 'Services', 'groundwork' ),
					'item_published'     => __( 'Service published.', 'groundwork' ),
					'item_updated'       => __( 'Service updated.', 'groundwork' ),
				),
				'public'        => true,
				'show_in_rest'  => true,
				'menu_position' => 21,
				'menu_icon'     => 'dashicons-hammer',
				'has_archive'   => true,
				'rewrite'       => array(
					'slug'       => 'services',
					'with_front' => false,
				),
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'page-attributes' ),
			)
		);
	}

	/**
	 * Testimonials: client quotes. They have no pages of their own and are
	 * shown through the Testimonials block.
	 *
	 * @return void
	 */
	private function register_testimonials(): void {
		register_post_type(
			self::TESTIMONIAL,
			array(
				'labels'              => array(
					'name'               => _x( 'Testimonials', 'post type general name', 'groundwork' ),
					'singular_name'      => _x( 'Testimonial', 'post type singular name', 'groundwork' ),
					'add_new_item'       => __( 'Add new testimonial', 'groundwork' ),
					'edit_item'          => __( 'Edit testimonial', 'groundwork' ),
					'new_item'           => __( 'New testimonial', 'groundwork' ),
					'search_items'       => __( 'Search testimonials', 'groundwork' ),
					'not_found'          => __( 'No testimonials found.', 'groundwork' ),
					'not_found_in_trash' => __( 'No testimonials found in Trash.', 'groundwork' ),
					'all_items'          => __( 'All testimonials', 'groundwork' ),
					'featured_image'     => __( 'Photo', 'groundwork' ),
					'set_featured_image' => __( 'Set photo', 'groundwork' ),
				),
				'public'              => false,
				'show_ui'             => true,
				'show_in_rest'        => true,
				'exclude_from_search' => true,
				'menu_position'       => 22,
				'menu_icon'           => 'dashicons-format-quote',
				'supports'            => array( 'title', 'editor', 'thumbnail', 'custom-fields', 'page-attributes' ),
				'template'            => array(
					array(
						'core/paragraph',
						array( 'placeholder' => __( 'Paste the client\'s words exactly as they gave them.', 'groundwork' ) ),
					),
				),
			)
		);
	}

	/**
	 * Project types group projects, for example "Bridges and roads".
	 *
	 * @return void
	 */
	private function register_project_types(): void {
		register_taxonomy(
			self::PROJECT_TYPE,
			array( self::PROJECT ),
			array(
				'labels'            => array(
					'name'          => _x( 'Project types', 'taxonomy general name', 'groundwork' ),
					'singular_name' => _x( 'Project type', 'taxonomy singular name', 'groundwork' ),
					'search_items'  => __( 'Search project types', 'groundwork' ),
					'all_items'     => __( 'All project types', 'groundwork' ),
					'edit_item'     => __( 'Edit project type', 'groundwork' ),
					'update_item'   => __( 'Update project type', 'groundwork' ),
					'add_new_item'  => __( 'Add new project type', 'groundwork' ),
					'new_item_name' => __( 'New project type name', 'groundwork' ),
					'menu_name'     => __( 'Project types', 'groundwork' ),
					'not_found'     => __( 'No project types found.', 'groundwork' ),
				),
				'hierarchical'      => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array(
					'slug'       => 'project-type',
					'with_front' => false,
				),
			)
		);
	}

	/**
	 * Replaces "Add title" with a prompt that matches the content.
	 *
	 * @param string   $placeholder Default placeholder text.
	 * @param \WP_Post $post        Post being edited.
	 * @return string
	 */
	public function title_placeholder( $placeholder, $post ) {
		switch ( $post->post_type ) {
			case self::PROJECT:
				return __( 'Project name', 'groundwork' );
			case self::SERVICE:
				return __( 'Service name', 'groundwork' );
			case self::TESTIMONIAL:
				return __( 'Client\'s full name', 'groundwork' );
		}

		return $placeholder;
	}
}
