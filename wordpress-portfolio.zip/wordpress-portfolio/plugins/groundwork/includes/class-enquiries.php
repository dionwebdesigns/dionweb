<?php
/**
 * Stored enquiries.
 *
 * @package Groundwork
 */

namespace Groundwork;

use WP_Post;
use WP_Query;

defined( 'ABSPATH' ) || exit;

/**
 * Keeps a private copy of each enquiry in the dashboard and plugs it into
 * the WordPress privacy tools, so an enquirer's data can be exported or
 * erased on request (as data protection laws such as the NDPA and GDPR
 * require).
 */
final class Enquiries {

	public const POST_TYPE = 'gw_enquiry';

	/**
	 * Fields stored as post meta, with their meta keys.
	 *
	 * @var array<string, string>
	 */
	private const META_KEYS = array(
		'name'    => '_gw_name',
		'email'   => '_gw_email',
		'phone'   => '_gw_phone',
		'company' => '_gw_company',
		'subject' => '_gw_subject',
		'source'  => '_gw_source',
	);

	/**
	 * Hooks storage, admin screens and privacy tools into WordPress.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_action( 'add_meta_boxes_' . self::POST_TYPE, array( $this, 'add_meta_box' ) );
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( $this, 'columns' ) );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( $this, 'render_column' ), 10, 2 );
		add_filter( 'post_row_actions', array( $this, 'row_actions' ), 10, 2 );
		add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'register_eraser' ) );
		add_action( 'admin_init', array( $this, 'suggest_privacy_policy_text' ) );
	}

	/**
	 * Capability needed to read enquiries. Administrators only by default,
	 * because enquiries hold personal data.
	 *
	 * @return string
	 */
	public static function capability(): string {
		/**
		 * Filters the capability required to see stored enquiries.
		 *
		 * @param string $capability Default 'manage_options'.
		 */
		return (string) apply_filters( 'groundwork_enquiry_capability', 'manage_options' );
	}

	/**
	 * Registers the private post type that holds enquiries.
	 *
	 * @return void
	 */
	public function register_post_type(): void {
		$capability = self::capability();

		register_post_type(
			self::POST_TYPE,
			array(
				'labels'            => array(
					'name'               => _x( 'Enquiries', 'post type general name', 'groundwork' ),
					'singular_name'      => _x( 'Enquiry', 'post type singular name', 'groundwork' ),
					'edit_item'          => __( 'Enquiry', 'groundwork' ),
					'search_items'       => __( 'Search enquiries', 'groundwork' ),
					'not_found'          => __( 'No enquiries yet. Messages sent through the contact form will appear here.', 'groundwork' ),
					'not_found_in_trash' => __( 'No enquiries found in Trash.', 'groundwork' ),
					'all_items'          => __( 'Enquiries', 'groundwork' ),
				),
				'public'            => false,
				'show_ui'           => true,
				'show_in_rest'      => false,
				'show_in_admin_bar' => false,
				'menu_position'     => 23,
				'menu_icon'         => 'dashicons-email-alt',
				'supports'          => false,
				'map_meta_cap'      => false,
				'capabilities'      => array(
					'create_posts'           => 'do_not_allow',
					'edit_post'              => $capability,
					'read_post'              => $capability,
					'delete_post'            => $capability,
					'edit_posts'             => $capability,
					'edit_others_posts'      => $capability,
					'edit_private_posts'     => $capability,
					'edit_published_posts'   => $capability,
					'delete_posts'           => $capability,
					'delete_others_posts'    => $capability,
					'delete_private_posts'   => $capability,
					'delete_published_posts' => $capability,
					'publish_posts'          => $capability,
					'read_private_posts'     => $capability,
				),
			)
		);
	}

	/**
	 * Saves an enquiry as a private post.
	 *
	 * @param array<string, string> $data Sanitised enquiry fields.
	 * @return int Enquiry ID, or 0 on failure.
	 */
	public static function store( array $data ): int {
		$meta = array();

		foreach ( self::META_KEYS as $field => $meta_key ) {
			$meta[ $meta_key ] = isset( $data[ $field ] ) ? $data[ $field ] : '';
		}

		$title = '' !== $data['subject']
			/* translators: 1: sender's name, 2: enquiry type. */
			? sprintf( __( '%1$s: %2$s', 'groundwork' ), $data['name'], $data['subject'] )
			: $data['name'];

		$enquiry_id = wp_insert_post(
			wp_slash(
				array(
					'post_type'    => self::POST_TYPE,
					'post_status'  => 'private',
					'post_title'   => $title,
					'post_content' => $data['message'],
					'meta_input'   => $meta,
				)
			),
			true
		);

		return is_wp_error( $enquiry_id ) ? 0 : (int) $enquiry_id;
	}

	/**
	 * Replaces the editor with a read-only view of the enquiry.
	 *
	 * @return void
	 */
	public function add_meta_box(): void {
		add_meta_box( 'groundwork-enquiry', __( 'Enquiry details', 'groundwork' ), array( $this, 'render_meta_box' ), self::POST_TYPE, 'normal', 'high' );
	}

	/**
	 * Outputs the enquiry details.
	 *
	 * @param WP_Post $post Enquiry post.
	 * @return void
	 */
	public function render_meta_box( WP_Post $post ): void {
		$email = (string) get_post_meta( $post->ID, '_gw_email', true );
		$phone = (string) get_post_meta( $post->ID, '_gw_phone', true );
		$rows  = array(
			__( 'Name', 'groundwork' )         => esc_html( (string) get_post_meta( $post->ID, '_gw_name', true ) ),
			__( 'Email', 'groundwork' )        => $email ? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : '',
			__( 'Phone', 'groundwork' )        => $phone ? '<a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ) . '">' . esc_html( $phone ) . '</a>' : '',
			__( 'Organisation', 'groundwork' ) => esc_html( (string) get_post_meta( $post->ID, '_gw_company', true ) ),
			__( 'Enquiry type', 'groundwork' ) => esc_html( (string) get_post_meta( $post->ID, '_gw_subject', true ) ),
			__( 'Received', 'groundwork' )     => esc_html( get_the_date( '', $post ) . ' ' . get_the_time( '', $post ) ),
			__( 'Sent from', 'groundwork' )    => esc_url( (string) get_post_meta( $post->ID, '_gw_source', true ) ),
		);
		?>
		<table class="form-table" role="presentation">
			<?php foreach ( array_filter( $rows ) as $label => $value ) : ?>
				<tr>
					<th scope="row"><?php echo esc_html( $label ); ?></th>
					<td><?php echo wp_kses( $value, array( 'a' => array( 'href' => array() ) ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Message', 'groundwork' ); ?></th>
				<td><?php echo wp_kses_post( wpautop( esc_html( $post->post_content ) ) ); ?></td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Columns on the Enquiries screen.
	 *
	 * @param string[] $columns Default columns.
	 * @return string[]
	 */
	public function columns( $columns ): array {
		return array(
			'cb'       => isset( $columns['cb'] ) ? $columns['cb'] : '',
			'title'    => __( 'From', 'groundwork' ),
			'gw_email' => __( 'Email', 'groundwork' ),
			'gw_phone' => __( 'Phone', 'groundwork' ),
			'date'     => __( 'Received', 'groundwork' ),
		);
	}

	/**
	 * Outputs the custom columns.
	 *
	 * @param string $column  Column name.
	 * @param int    $post_id Enquiry ID.
	 * @return void
	 */
	public function render_column( $column, $post_id ): void {
		if ( 'gw_email' === $column ) {
			$email = (string) get_post_meta( $post_id, '_gw_email', true );
			printf( '<a href="mailto:%1$s">%2$s</a>', esc_attr( $email ), esc_html( $email ) );
		}

		if ( 'gw_phone' === $column ) {
			echo esc_html( (string) get_post_meta( $post_id, '_gw_phone', true ) );
		}
	}

	/**
	 * Swaps Quick Edit for a Reply link.
	 *
	 * @param string[] $actions Row actions.
	 * @param WP_Post  $post    Current post.
	 * @return string[]
	 */
	public function row_actions( $actions, $post ): array {
		if ( self::POST_TYPE !== $post->post_type ) {
			return $actions;
		}

		unset( $actions['inline hide-if-no-js'] );

		$email = (string) get_post_meta( $post->ID, '_gw_email', true );

		if ( $email ) {
			$subject          = (string) get_post_meta( $post->ID, '_gw_subject', true );
			$actions['reply'] = sprintf(
				'<a href="%1$s">%2$s</a>',
				esc_url( 'mailto:' . $email . '?subject=' . rawurlencode( 'Re: ' . ( $subject ? $subject : get_bloginfo( 'name' ) ) ) ),
				esc_html__( 'Reply', 'groundwork' )
			);
		}

		return $actions;
	}

	/**
	 * Registers the personal data exporter.
	 *
	 * @param array $exporters Registered exporters.
	 * @return array
	 */
	public function register_exporter( $exporters ): array {
		$exporters['groundwork-enquiries'] = array(
			'exporter_friendly_name' => __( 'Contact form enquiries', 'groundwork' ),
			'callback'               => array( $this, 'export' ),
		);

		return $exporters;
	}

	/**
	 * Registers the personal data eraser.
	 *
	 * @param array $erasers Registered erasers.
	 * @return array
	 */
	public function register_eraser( $erasers ): array {
		$erasers['groundwork-enquiries'] = array(
			'eraser_friendly_name' => __( 'Contact form enquiries', 'groundwork' ),
			'callback'             => array( $this, 'erase' ),
		);

		return $erasers;
	}

	/**
	 * Exports every enquiry sent from an email address.
	 *
	 * @param string $email Email address from the privacy request.
	 * @param int    $page  Page of results, starting at 1.
	 * @return array{data: array, done: bool}
	 */
	public function export( $email, $page = 1 ): array {
		$query  = $this->find_by_email( $email, (int) $page );
		$items  = array();
		$labels = wp_list_pluck( Contact_Form::fields(), 'label' );

		$labels['source'] = __( 'Sent from', 'groundwork' );

		foreach ( $query->posts as $post ) {
			$data = array();

			foreach ( self::META_KEYS as $field => $meta_key ) {
				$value = (string) get_post_meta( $post->ID, $meta_key, true );

				if ( '' !== $value ) {
					$data[] = array(
						'name'  => $labels[ $field ],
						'value' => $value,
					);
				}
			}

			$data[] = array(
				'name'  => __( 'Message', 'groundwork' ),
				'value' => $post->post_content,
			);
			$data[] = array(
				'name'  => __( 'Received', 'groundwork' ),
				'value' => get_the_date( 'Y-m-d H:i', $post ),
			);

			$items[] = array(
				'group_id'    => 'groundwork-enquiries',
				'group_label' => __( 'Contact form enquiries', 'groundwork' ),
				'item_id'     => 'groundwork-enquiry-' . $post->ID,
				'data'        => $data,
			);
		}

		return array(
			'data' => $items,
			'done' => $query->max_num_pages <= $page,
		);
	}

	/**
	 * Deletes every enquiry sent from an email address.
	 *
	 * @param string $email Email address from the privacy request.
	 * @return array{items_removed: int, items_retained: int, messages: string[], done: bool}
	 */
	public function erase( $email ): array {
		// Deleting shifts later pages forward, so always read the first page.
		$query   = $this->find_by_email( $email, 1 );
		$removed = 0;

		foreach ( $query->posts as $post ) {
			if ( wp_delete_post( $post->ID, true ) ) {
				++$removed;
			}
		}

		return array(
			'items_removed'  => $removed,
			'items_retained' => 0,
			'messages'       => array(),
			'done'           => $query->max_num_pages <= 1,
		);
	}

	/**
	 * Finds enquiries sent from an email address.
	 *
	 * @param string $email Email address.
	 * @param int    $page  Page of results.
	 * @return WP_Query
	 */
	private function find_by_email( $email, int $page ): WP_Query {
		return new WP_Query(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 50,
				'paged'          => max( 1, $page ),
				'orderby'        => 'ID',
				'order'          => 'ASC',
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Privacy requests are rare, admin-only operations.
				'meta_query'     => array(
					array(
						'key'   => '_gw_email',
						'value' => sanitize_email( $email ),
					),
				),
			)
		);
	}

	/**
	 * Suggests text for the site's privacy policy under Settings > Privacy.
	 *
	 * @return void
	 */
	public function suggest_privacy_policy_text(): void {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$text = '<p>' . __( 'When you send an enquiry through our contact form, we collect the name, email address and message you enter, plus your phone number and organisation if you give them. We use these details only to reply to your enquiry.', 'groundwork' ) . '</p>'
			. '<p>' . __( 'Enquiries are emailed to our team and a copy is kept in our website dashboard, which only administrators can open. You can ask us to send you a copy of this data or to delete it.', 'groundwork' ) . '</p>';

		wp_add_privacy_policy_content( __( 'Groundwork contact form', 'groundwork' ), wp_kses_post( $text ) );
	}
}
