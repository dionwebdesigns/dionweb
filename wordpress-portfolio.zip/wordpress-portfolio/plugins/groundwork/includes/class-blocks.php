<?php
/**
 * Block registration.
 *
 * @package Groundwork
 */

namespace Groundwork;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the blocks compiled into the build folder.
 *
 * The build step writes a manifest of every block.json, which lets
 * WordPress 6.8+ register all blocks without reading each file from disk.
 */
final class Blocks {

	/**
	 * Hooks the registration into WordPress.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'init', array( $this, 'register' ) );
		add_filter( 'block_categories_all', array( $this, 'register_category' ) );
	}

	/**
	 * Registers every block listed in the build manifest.
	 *
	 * @return void
	 */
	public function register(): void {
		$build    = GROUNDWORK_PATH . 'build';
		$manifest = $build . '/blocks-manifest.php';

		if ( ! is_readable( $manifest ) ) {
			return;
		}

		// WordPress 6.8 and later: one call registers the whole collection.
		if ( function_exists( 'wp_register_block_types_from_metadata_collection' ) ) {
			wp_register_block_types_from_metadata_collection( $build, $manifest );
			return;
		}

		// WordPress 6.7: register the collection, then each block.
		if ( function_exists( 'wp_register_block_metadata_collection' ) ) {
			wp_register_block_metadata_collection( $build, $manifest );
		}

		$blocks = require $manifest;

		foreach ( array_keys( $blocks ) as $block_folder ) {
			register_block_type( $build . '/' . $block_folder );
		}
	}

	/**
	 * Groups the plugin's blocks under their own heading in the inserter.
	 *
	 * @param array[] $categories Registered block categories.
	 * @return array[]
	 */
	public function register_category( $categories ): array {
		$categories[] = array(
			'slug'  => 'groundwork',
			'title' => __( 'Groundwork', 'groundwork' ),
			'icon'  => null,
		);

		return $categories;
	}
}
