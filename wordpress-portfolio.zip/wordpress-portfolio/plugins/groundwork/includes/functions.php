<?php
/**
 * Template functions for themes.
 *
 * Themes should check `function_exists()` before calling these, so they
 * keep working when the plugin is switched off.
 *
 * @package Groundwork
 */

defined( 'ABSPATH' ) || exit;

/**
 * Returns the filled-in details of a project, in display order.
 *
 * Empty fields are left out, so the result can be looped over directly.
 *
 * @param int|WP_Post|null $post Project post or ID. Defaults to the current post.
 * @return array<string, array{label: string, value: string}>
 */
function groundwork_get_project_details( $post = null ): array {
	$post = get_post( $post );

	if ( ! $post || \Groundwork\Post_Types::PROJECT !== $post->post_type ) {
		return array();
	}

	$details = array();

	foreach ( \Groundwork\Meta::project_fields() as $name => $field ) {
		$value = (string) get_post_meta( $post->ID, $field['key'], true );

		if ( 'status' === $name ) {
			$value = \Groundwork\Meta::status_label( $value );
		}

		if ( '' === $value ) {
			continue;
		}

		$details[ $name ] = array(
			'label' => $field['label'],
			'value' => $value,
		);
	}

	/**
	 * Filters the project details shown by themes and blocks.
	 *
	 * @param array   $details Details keyed by field name.
	 * @param WP_Post $post    Project post.
	 */
	return (array) apply_filters( 'groundwork_project_details', $details, $post );
}

/**
 * Returns the name, role and organisation behind a testimonial.
 *
 * @param int|WP_Post|null $post Testimonial post or ID. Defaults to the current post.
 * @return array{name: string, role: string, organisation: string}
 */
function groundwork_get_testimonial_details( $post = null ): array {
	$post = get_post( $post );

	if ( ! $post || \Groundwork\Post_Types::TESTIMONIAL !== $post->post_type ) {
		return array(
			'name'         => '',
			'role'         => '',
			'organisation' => '',
		);
	}

	return array(
		'name'         => get_the_title( $post ),
		'role'         => (string) get_post_meta( $post->ID, '_gw_role', true ),
		'organisation' => (string) get_post_meta( $post->ID, '_gw_organisation', true ),
	);
}

/**
 * Renders the contact form outside the block editor, for example from a
 * PHP template or a page builder.
 *
 * @param array $attributes Optional block attributes, such as `buttonLabel`.
 * @return string Form markup.
 */
function groundwork_get_contact_form( array $attributes = array() ): string {
	return render_block(
		array(
			'blockName'    => 'groundwork/contact-form',
			'attrs'        => $attributes,
			'innerBlocks'  => array(),
			'innerHTML'    => '',
			'innerContent' => array(),
		)
	);
}
