<?php
/**
 * Block editor additions.
 *
 * @package Groundwork
 */

namespace Groundwork;

defined( 'ABSPATH' ) || exit;

/**
 * Loads the "Details" sidebar panel when editing projects and testimonials.
 */
final class Editor {

	/**
	 * Hooks the editor assets into WordPress.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_details_panel' ) );
	}

	/**
	 * Enqueues the panel only on the screens that use it.
	 *
	 * @return void
	 */
	public function enqueue_details_panel(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( ! $screen || ! in_array( $screen->post_type, array( Post_Types::PROJECT, Post_Types::TESTIMONIAL ), true ) ) {
			return;
		}

		$asset_file = GROUNDWORK_PATH . 'build/details-panel/index.asset.php';

		if ( ! is_readable( $asset_file ) ) {
			return;
		}

		$asset = require $asset_file;

		wp_enqueue_script(
			'groundwork-details-panel',
			GROUNDWORK_URL . 'build/details-panel/index.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);

		wp_set_script_translations( 'groundwork-details-panel', 'groundwork', GROUNDWORK_PATH . 'languages' );
	}
}
