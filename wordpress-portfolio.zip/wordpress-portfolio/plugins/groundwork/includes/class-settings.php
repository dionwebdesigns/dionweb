<?php
/**
 * Settings screen.
 *
 * @package Groundwork
 */

namespace Groundwork;

defined( 'ABSPATH' ) || exit;

/**
 * Adds Settings > Groundwork, where site owners choose who receives
 * enquiries and what visitors see after sending one.
 */
final class Settings {

	public const OPTION = 'groundwork_settings';
	private const PAGE  = 'groundwork';

	/**
	 * Hooks the settings screen into WordPress.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_menu', array( $this, 'add_page' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( GROUNDWORK_FILE ), array( $this, 'add_action_link' ) );
	}

	/**
	 * Default values for every setting.
	 *
	 * @return array{recipient: string, success_message: string, store_enquiries: bool}
	 */
	public static function defaults(): array {
		return array(
			'recipient'       => (string) get_option( 'admin_email' ),
			'success_message' => __( 'Thank you. Your enquiry has been sent and we will reply within two working days.', 'groundwork' ),
			'store_enquiries' => true,
		);
	}

	/**
	 * Returns one setting, falling back to its default.
	 *
	 * @param string $key Setting name.
	 * @return mixed
	 */
	public static function get( string $key ) {
		$settings = wp_parse_args( (array) get_option( self::OPTION, array() ), self::defaults() );

		return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
	}

	/**
	 * Registers the option, its section and its fields.
	 *
	 * @return void
	 */
	public function register_settings(): void {
		register_setting(
			self::PAGE,
			self::OPTION,
			array(
				'type'              => 'object',
				'sanitize_callback' => array( $this, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);

		add_settings_section(
			'groundwork_enquiries',
			__( 'Contact form', 'groundwork' ),
			static function () {
				echo '<p>' . esc_html__( 'Applies to every Contact form block and [groundwork_contact_form] shortcode on the site.', 'groundwork' ) . '</p>';
			},
			self::PAGE
		);

		add_settings_field(
			'groundwork_recipient',
			__( 'Send enquiries to', 'groundwork' ),
			array( $this, 'render_recipient_field' ),
			self::PAGE,
			'groundwork_enquiries',
			array( 'label_for' => 'groundwork_recipient' )
		);

		add_settings_field(
			'groundwork_success_message',
			__( 'Message after sending', 'groundwork' ),
			array( $this, 'render_success_field' ),
			self::PAGE,
			'groundwork_enquiries',
			array( 'label_for' => 'groundwork_success_message' )
		);

		add_settings_field(
			'groundwork_store_enquiries',
			__( 'Keep a copy', 'groundwork' ),
			array( $this, 'render_store_field' ),
			self::PAGE,
			'groundwork_enquiries'
		);
	}

	/**
	 * Cleans submitted settings before they are saved.
	 *
	 * @param mixed $input Raw submitted values.
	 * @return array
	 */
	public function sanitize( $input ): array {
		$input    = is_array( $input ) ? $input : array();
		$defaults = self::defaults();
		$clean    = array();

		$recipient = isset( $input['recipient'] ) ? sanitize_email( $input['recipient'] ) : '';

		if ( '' !== $recipient && ! is_email( $recipient ) ) {
			add_settings_error( self::OPTION, 'invalid_recipient', __( 'Enter a valid email address for enquiries.', 'groundwork' ) );
			$recipient = '';
		}

		$clean['recipient']       = '' !== $recipient ? $recipient : $defaults['recipient'];
		$clean['success_message'] = isset( $input['success_message'] ) && '' !== trim( $input['success_message'] )
			? sanitize_textarea_field( $input['success_message'] )
			: $defaults['success_message'];
		$clean['store_enquiries'] = ! empty( $input['store_enquiries'] );

		return $clean;
	}

	/**
	 * Adds the settings page under Settings.
	 *
	 * @return void
	 */
	public function add_page(): void {
		add_options_page(
			__( 'Groundwork settings', 'groundwork' ),
			__( 'Groundwork', 'groundwork' ),
			'manage_options',
			self::PAGE,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Adds a Settings link to the plugin's row on the Plugins screen.
	 *
	 * @param string[] $links Existing action links.
	 * @return string[]
	 */
	public function add_action_link( $links ): array {
		$url = admin_url( 'options-general.php?page=' . self::PAGE );

		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'groundwork' ) . '</a>' );

		return $links;
	}

	/**
	 * Outputs the settings page.
	 *
	 * @return void
	 */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			<form action="options.php" method="post">
				<?php
				settings_fields( self::PAGE );
				do_settings_sections( self::PAGE );
				submit_button( __( 'Save settings', 'groundwork' ) );
				?>
			</form>
		</div>
		<?php
	}

	/**
	 * Outputs the recipient field.
	 *
	 * @return void
	 */
	public function render_recipient_field(): void {
		printf(
			'<input type="email" class="regular-text" id="groundwork_recipient" name="%1$s[recipient]" value="%2$s" autocomplete="email" /><p class="description">%3$s</p>',
			esc_attr( self::OPTION ),
			esc_attr( self::get( 'recipient' ) ),
			esc_html__( 'Defaults to the site administration email address.', 'groundwork' )
		);
	}

	/**
	 * Outputs the success message field.
	 *
	 * @return void
	 */
	public function render_success_field(): void {
		printf(
			'<textarea class="large-text" rows="3" id="groundwork_success_message" name="%1$s[success_message]">%2$s</textarea>',
			esc_attr( self::OPTION ),
			esc_textarea( self::get( 'success_message' ) )
		);
	}

	/**
	 * Outputs the "keep a copy" checkbox.
	 *
	 * @return void
	 */
	public function render_store_field(): void {
		printf(
			'<label><input type="checkbox" name="%1$s[store_enquiries]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION ),
			checked( (bool) self::get( 'store_enquiries' ), true, false ),
			esc_html__( 'Save each enquiry under Enquiries in the dashboard, in case an email goes missing.', 'groundwork' )
		);
	}
}
