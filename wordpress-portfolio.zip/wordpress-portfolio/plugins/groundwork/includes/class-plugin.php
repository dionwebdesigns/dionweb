<?php
/**
 * Plugin bootstrap.
 *
 * @package Groundwork
 */

namespace Groundwork;

defined( 'ABSPATH' ) || exit;

/**
 * Wires every feature of the plugin into WordPress.
 *
 * Each feature is a small class with a `register_hooks()` method, so a
 * feature can be read, tested or removed without touching the others.
 */
final class Plugin {

	/**
	 * Shared instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Feature classes, in the order they are booted.
	 *
	 * @var string[]
	 */
	private const FEATURES = array(
		Post_Types::class,
		Meta::class,
		Blocks::class,
		Editor::class,
		Contact_Form::class,
		Enquiries::class,
		Settings::class,
		Shortcodes::class,
	);

	/**
	 * Returns the shared instance.
	 *
	 * @return Plugin
	 */
	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Registers the hooks of every feature.
	 *
	 * @return void
	 */
	public function boot(): void {
		foreach ( self::FEATURES as $feature ) {
			( new $feature() )->register_hooks();
		}

		add_action( 'init', array( $this, 'load_textdomain' ) );
	}

	/**
	 * Loads translations shipped in the languages folder.
	 *
	 * @return void
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain( 'groundwork', false, dirname( plugin_basename( GROUNDWORK_FILE ) ) . '/languages' );
	}

	/**
	 * Registers the post types before flushing rewrite rules, so the
	 * /projects/ and /services/ archives work straight after activation.
	 *
	 * @return void
	 */
	public static function activate(): void {
		( new Post_Types() )->register();
		flush_rewrite_rules();
	}

	/**
	 * Removes the plugin's rewrite rules.
	 *
	 * @return void
	 */
	public static function deactivate(): void {
		flush_rewrite_rules();
	}
}
