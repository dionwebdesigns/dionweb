<?php
/**
 * Post meta for projects and testimonials.
 *
 * @package Groundwork
 */

namespace Groundwork;

defined( 'ABSPATH' ) || exit;

/**
 * Registers structured fields so they are sanitised on save, exposed to the
 * block editor through the REST API and protected from users who cannot
 * edit the post.
 */
final class Meta {

	/**
	 * Hooks the registration into WordPress.
	 *
	 * @return void
	 */
	public function register_hooks(): void {
		add_action( 'init', array( $this, 'register' ) );
	}

	/**
	 * Fields recorded for each project, keyed by a short name.
	 *
	 * @return array<string, array{key: string, label: string}>
	 */
	public static function project_fields(): array {
		return array(
			'client'   => array(
				'key'   => '_gw_client',
				'label' => __( 'Client', 'groundwork' ),
			),
			'location' => array(
				'key'   => '_gw_location',
				'label' => __( 'Location', 'groundwork' ),
			),
			'year'     => array(
				'key'   => '_gw_year',
				'label' => __( 'Year', 'groundwork' ),
			),
			'scope'    => array(
				'key'   => '_gw_scope',
				'label' => __( 'Scope', 'groundwork' ),
			),
			'duration' => array(
				'key'   => '_gw_duration',
				'label' => __( 'Duration', 'groundwork' ),
			),
			'status'   => array(
				'key'   => '_gw_status',
				'label' => __( 'Status', 'groundwork' ),
			),
		);
	}

	/**
	 * Fields recorded for each testimonial.
	 *
	 * @return array<string, array{key: string, label: string}>
	 */
	public static function testimonial_fields(): array {
		return array(
			'role'         => array(
				'key'   => '_gw_role',
				'label' => __( 'Role', 'groundwork' ),
			),
			'organisation' => array(
				'key'   => '_gw_organisation',
				'label' => __( 'Organisation', 'groundwork' ),
			),
		);
	}

	/**
	 * Allowed project statuses and their labels.
	 *
	 * @return array<string, string>
	 */
	public static function statuses(): array {
		return array(
			'completed'   => __( 'Completed', 'groundwork' ),
			'in-progress' => __( 'In progress', 'groundwork' ),
			'design'      => __( 'In design', 'groundwork' ),
		);
	}

	/**
	 * Registers every field.
	 *
	 * @return void
	 */
	public function register(): void {
		foreach ( self::project_fields() as $name => $field ) {
			$args = array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => array( $this, 'can_edit' ),
			);

			if ( 'status' === $name ) {
				$args['default']           = 'completed';
				$args['sanitize_callback'] = array( $this, 'sanitize_status' );
				$args['show_in_rest']      = array(
					'schema' => array(
						'type' => 'string',
						'enum' => array_keys( self::statuses() ),
					),
				);
			}

			register_post_meta( Post_Types::PROJECT, $field['key'], $args );
		}

		foreach ( self::testimonial_fields() as $field ) {
			register_post_meta(
				Post_Types::TESTIMONIAL,
				$field['key'],
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => true,
					'sanitize_callback' => 'sanitize_text_field',
					'auth_callback'     => array( $this, 'can_edit' ),
				)
			);
		}
	}

	/**
	 * Only people who can edit the post may change its fields.
	 *
	 * The keys start with an underscore, which hides them from the generic
	 * Custom Fields panel, so this callback is what grants REST access.
	 *
	 * @param bool   $allowed   Whether the user can edit the field.
	 * @param string $meta_key  Meta key.
	 * @param int    $object_id Post ID.
	 * @return bool
	 */
	public function can_edit( $allowed, $meta_key, $object_id ): bool {
		return current_user_can( 'edit_post', $object_id );
	}

	/**
	 * Keeps the status to one of the known values.
	 *
	 * @param mixed $value Submitted value.
	 * @return string
	 */
	public function sanitize_status( $value ): string {
		$value = sanitize_key( (string) $value );

		return array_key_exists( $value, self::statuses() ) ? $value : 'completed';
	}

	/**
	 * Translates a stored status into its label.
	 *
	 * @param string $status Stored status.
	 * @return string
	 */
	public static function status_label( $status ): string {
		$statuses = self::statuses();

		return isset( $statuses[ $status ] ) ? $statuses[ $status ] : '';
	}
}
