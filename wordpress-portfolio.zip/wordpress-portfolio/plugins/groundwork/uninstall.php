<?php
/**
 * Removes the plugin's settings when it is deleted from the Plugins screen.
 *
 * Projects, services, testimonials and enquiries are content, so they are
 * kept. Delete them from their screens first if they are no longer needed.
 *
 * @package Groundwork
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'groundwork_settings' );
