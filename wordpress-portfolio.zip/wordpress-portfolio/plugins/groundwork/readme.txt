=== Groundwork ===
Contributors: emediong
Tags: portfolio, projects, testimonials, contact form, blocks
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Projects, services and testimonials, three editor blocks and a secure contact form.

== Description ==

Groundwork holds the parts of a business site that should survive a change of theme.

* Post types for projects, services and testimonials, with a project type taxonomy
* A "Project details" panel in the editor sidebar, built in React, saving to registered and sanitised post meta
* Three dynamic blocks: Project grid, Testimonials and Contact form
* Shortcodes for page builders and the Classic Editor
* A contact form that works with and without JavaScript, filters spam without a CAPTCHA, emails the site owner and keeps a private copy
* Privacy tools: enquiries can be exported or erased from Tools > Export / Erase Personal Data

== Shortcodes ==

`[groundwork_projects count="6" columns="3" type="bridges-and-roads"]`
`[groundwork_testimonials count="2"]`
`[groundwork_contact_form button="Request a quote" company="yes"]`

== Hooks ==

* `groundwork_enquiry_received` (action): runs after an enquiry passes every check. Use it to send enquiries to a CRM.
* `groundwork_enquiry_recipient` (filter): who receives enquiry emails.
* `groundwork_project_details` (filter): the project details shown by themes and blocks.
* `groundwork_client_ip` (filter): the address used for rate limiting, for sites behind a proxy.
* `groundwork_enquiry_capability` (filter): who can read stored enquiries. Administrators by default.

== Frequently Asked Questions ==

= My site caches pages. Will the form still work? =

The form includes a security token that expires after 24 hours. If pages are cached for longer, exclude the page that holds the form from the cache.

== Changelog ==

= 1.0.0 =
* Initial release.
