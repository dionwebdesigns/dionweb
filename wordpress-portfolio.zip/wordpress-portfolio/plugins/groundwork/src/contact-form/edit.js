/**
 * Editor interface for the Contact form block.
 */
import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import {
	PanelBody,
	TextControl,
	TextareaControl,
	ToggleControl,
} from '@wordpress/components';

import ServerPreview from '../shared/server-preview';
import { contactFormIcon } from '../shared/icons';

export default function Edit( { attributes, setAttributes } ) {
	const { buttonLabel, showPhone, showCompany, subjects } = attributes;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Fields', 'groundwork' ) }>
					<ToggleControl
						__nextHasNoMarginBottom
						label={ __( 'Ask for a phone number', 'groundwork' ) }
						checked={ showPhone }
						onChange={ ( value ) =>
							setAttributes( { showPhone: value } )
						}
					/>
					<ToggleControl
						__nextHasNoMarginBottom
						label={ __(
							'Ask for a company or organisation',
							'groundwork'
						) }
						checked={ showCompany }
						onChange={ ( value ) =>
							setAttributes( { showCompany: value } )
						}
					/>
					<TextareaControl
						__nextHasNoMarginBottom
						label={ __( 'Enquiry types', 'groundwork' ) }
						help={ __(
							'One option per line, shown as a dropdown. Leave empty to hide the dropdown.',
							'groundwork'
						) }
						value={ subjects }
						onChange={ ( value ) =>
							setAttributes( { subjects: value } )
						}
						rows={ 4 }
					/>
					<TextControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={ __( 'Button label', 'groundwork' ) }
						help={ __(
							'Name the action, for example "Request a quote".',
							'groundwork'
						) }
						placeholder={ __( 'Send enquiry', 'groundwork' ) }
						value={ buttonLabel }
						onChange={ ( value ) =>
							setAttributes( { buttonLabel: value } )
						}
					/>
				</PanelBody>
				<PanelBody
					title={ __( 'Delivery', 'groundwork' ) }
					initialOpen={ false }
				>
					<p>
						{ __(
							'Choose who receives enquiries, and the message people see after sending one, under Settings > Groundwork.',
							'groundwork'
						) }
					</p>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<ServerPreview
					block="groundwork/contact-form"
					attributes={ attributes }
					icon={ contactFormIcon }
					label={ __( 'Contact form', 'groundwork' ) }
				/>
			</div>
		</>
	);
}
