/**
 * Contact form block.
 */
import { registerBlockType } from '@wordpress/blocks';

import metadata from './block.json';
import Edit from './edit';
import { contactFormIcon } from '../shared/icons';
import './style.scss';

registerBlockType( metadata.name, {
	icon: contactFormIcon,
	edit: Edit,
} );
