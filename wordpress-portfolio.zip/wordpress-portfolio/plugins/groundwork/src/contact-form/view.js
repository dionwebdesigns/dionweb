/**
 * Contact form: progressive enhancement.
 *
 * Without this script the form posts to admin-post.php and the page
 * reloads with the result. With it, the form sends JSON to the REST API,
 * shows each error next to its field, and announces the result through
 * the status region, so screen reader users hear it too.
 */

/**
 * Shows or clears the error message under one field.
 *
 * @param {HTMLFormElement} form    Form element.
 * @param {string}          name    Field name.
 * @param {string}          message Error message, or an empty string to clear it.
 */
function setFieldError( form, name, message ) {
	const control = form.elements.namedItem( name );
	const error = form.querySelector( `[data-error-for="${ name }"]` );

	if ( ! control || ! error ) {
		return;
	}

	error.textContent = message;
	error.hidden = ! message;

	if ( message ) {
		control.setAttribute( 'aria-invalid', 'true' );
	} else {
		control.removeAttribute( 'aria-invalid' );
	}
}

/**
 * Writes a message into the status region.
 *
 * @param {HTMLElement} status  Status element.
 * @param {string}      message Text to show.
 * @param {string}      state   Either "success" or "error".
 */
function setStatus( status, message, state ) {
	status.classList.remove( 'is-success', 'is-error' );
	status.classList.add( `is-${ state }` );
	status.textContent = message;
}

/**
 * Sends the form through the REST API.
 *
 * @param {SubmitEvent} event Submit event.
 */
async function handleSubmit( event ) {
	const form = event.currentTarget;
	const { endpoint, restNonce, sendingLabel, errorLabel } = form.dataset;

	if ( ! endpoint || ! window.fetch ) {
		return; // Let the browser post the form normally.
	}

	event.preventDefault();

	const status = form.querySelector( '.gw-contact-form__status' );
	const button = form.querySelector( '[type="submit"]' );
	const buttonLabel = button.textContent;

	Array.from( form.querySelectorAll( '[data-error-for]' ) ).forEach(
		( error ) => setFieldError( form, error.dataset.errorFor, '' )
	);

	form.setAttribute( 'aria-busy', 'true' );
	button.disabled = true;
	button.textContent = sendingLabel;

	try {
		const response = await window.fetch( endpoint, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				Accept: 'application/json',
				'Content-Type': 'application/json',
				'X-WP-Nonce': restNonce,
			},
			body: JSON.stringify( Object.fromEntries( new FormData( form ) ) ),
		} );
		const result = await response.json();

		if ( response.ok && result.success ) {
			form.reset();
			setStatus( status, result.message, 'success' );
			status.focus();
			return;
		}

		Object.entries( result.errors || {} ).forEach( ( [ name, message ] ) =>
			setFieldError( form, name, message )
		);
		setStatus( status, result.message || errorLabel, 'error' );

		const firstInvalid = form.querySelector( '[aria-invalid="true"]' );
		( firstInvalid || status ).focus();
	} catch {
		setStatus( status, errorLabel, 'error' );
		status.focus();
	} finally {
		form.removeAttribute( 'aria-busy' );
		button.disabled = false;
		button.textContent = buttonLabel;
	}
}

document
	.querySelectorAll( '.gw-contact-form' )
	.forEach( ( form ) => form.addEventListener( 'submit', handleSubmit ) );
