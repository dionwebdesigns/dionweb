<?php
/**
 * Front-end markup for the Contact form block.
 *
 * The form posts to admin-post.php, so it works without JavaScript.
 * view.js upgrades it to send through the REST API without a page reload.
 *
 * @package Groundwork
 *
 * @var array    $attributes Block attributes.
 * @var string   $content    Block content.
 * @var WP_Block $block      Block instance.
 */

defined( 'ABSPATH' ) || exit;

$groundwork_id     = wp_unique_id( 'gw-contact-' );
$groundwork_result = null;

// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lookup of a random, short-lived result key.
$groundwork_key = isset( $_GET[ \Groundwork\Contact_Form::RESULT_PARAM ] ) ? sanitize_text_field( wp_unslash( $_GET[ \Groundwork\Contact_Form::RESULT_PARAM ] ) ) : '';

if ( '' !== $groundwork_key ) {
	$groundwork_result = \Groundwork\Contact_Form::get_result( $groundwork_key, $groundwork_id );
}

$groundwork_values   = $groundwork_result ? (array) $groundwork_result['values'] : array();
$groundwork_errors   = $groundwork_result ? (array) $groundwork_result['errors'] : array();
$groundwork_labels   = \Groundwork\Contact_Form::fields();
$groundwork_subjects = array_values( array_filter( array_map( 'trim', explode( "\n", (string) $attributes['subjects'] ) ) ) );
$groundwork_button   = '' !== trim( (string) $attributes['buttonLabel'] ) ? (string) $attributes['buttonLabel'] : __( 'Send enquiry', 'groundwork' );
$groundwork_source   = is_singular() ? get_permalink() : home_url( '/' );
$groundwork_privacy  = get_the_privacy_policy_link();

$groundwork_status_class = '';
if ( $groundwork_result ) {
	$groundwork_status_class = 'sent' === $groundwork_result['status'] ? ' is-success' : ' is-error';
}

$groundwork_fields = array(
	'name'    => array(
		'type'         => 'text',
		'autocomplete' => 'name',
		'half'         => true,
	),
	'email'   => array(
		'type'         => 'email',
		'autocomplete' => 'email',
		'half'         => true,
	),
	'phone'   => array(
		'type'         => 'tel',
		'autocomplete' => 'tel',
		'half'         => true,
		'enabled'      => ! empty( $attributes['showPhone'] ),
	),
	'company' => array(
		'type'         => 'text',
		'autocomplete' => 'organization',
		'half'         => true,
		'enabled'      => ! empty( $attributes['showCompany'] ),
	),
	'subject' => array(
		'type'    => 'select',
		'enabled' => (bool) $groundwork_subjects,
	),
	'message' => array(
		'type' => 'textarea',
	),
);
?>
<div <?php echo wp_kses_data( get_block_wrapper_attributes( array( 'id' => $groundwork_id ) ) ); ?>>
	<form
		class="gw-contact-form"
		action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
		method="post"
		data-endpoint="<?php echo esc_url( rest_url( \Groundwork\Contact_Form::REST_NAMESPACE . \Groundwork\Contact_Form::REST_ROUTE ) ); ?>"
		data-rest-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
		data-sending-label="<?php esc_attr_e( 'Sending', 'groundwork' ); ?>"
		data-error-label="<?php esc_attr_e( 'Your enquiry could not be sent. Check your connection, then try again.', 'groundwork' ); ?>"
	>
		<div class="gw-contact-form__status<?php echo esc_attr( $groundwork_status_class ); ?>" role="status" tabindex="-1"><?php echo $groundwork_result ? esc_html( $groundwork_result['message'] ) : ''; ?></div>

		<div class="gw-contact-form__fields">
			<?php
			foreach ( $groundwork_fields as $groundwork_name => $groundwork_field ) :
				if ( isset( $groundwork_field['enabled'] ) && ! $groundwork_field['enabled'] ) {
					continue;
				}

				$groundwork_input_id = $groundwork_id . '-' . $groundwork_name;
				$groundwork_error_id = $groundwork_input_id . '-error';
				$groundwork_required = $groundwork_labels[ $groundwork_name ]['required'];
				$groundwork_value    = isset( $groundwork_values[ $groundwork_name ] ) ? (string) $groundwork_values[ $groundwork_name ] : '';
				$groundwork_error    = isset( $groundwork_errors[ $groundwork_name ] ) ? (string) $groundwork_errors[ $groundwork_name ] : '';
				?>
				<div class="gw-field<?php echo empty( $groundwork_field['half'] ) ? '' : ' gw-field--half'; ?>">
					<label class="gw-field__label" for="<?php echo esc_attr( $groundwork_input_id ); ?>">
						<?php echo esc_html( $groundwork_labels[ $groundwork_name ]['label'] ); ?>
						<?php if ( ! $groundwork_required ) : ?>
							<span class="gw-field__optional"><?php esc_html_e( '(optional)', 'groundwork' ); ?></span>
						<?php endif; ?>
					</label>

					<?php if ( 'textarea' === $groundwork_field['type'] ) : ?>
						<textarea
							class="gw-field__control"
							id="<?php echo esc_attr( $groundwork_input_id ); ?>"
							name="<?php echo esc_attr( $groundwork_name ); ?>"
							rows="6"
							maxlength="<?php echo esc_attr( $groundwork_labels[ $groundwork_name ]['max'] ); ?>"
							aria-describedby="<?php echo esc_attr( $groundwork_error_id ); ?>"
							<?php echo $groundwork_required ? 'required' : ''; ?>
							<?php echo $groundwork_error ? 'aria-invalid="true"' : ''; ?>
						><?php echo esc_textarea( $groundwork_value ); ?></textarea>
					<?php elseif ( 'select' === $groundwork_field['type'] ) : ?>
						<select
							class="gw-field__control"
							id="<?php echo esc_attr( $groundwork_input_id ); ?>"
							name="<?php echo esc_attr( $groundwork_name ); ?>"
							aria-describedby="<?php echo esc_attr( $groundwork_error_id ); ?>"
						>
							<option value=""><?php esc_html_e( 'Choose one', 'groundwork' ); ?></option>
							<?php foreach ( $groundwork_subjects as $groundwork_subject ) : ?>
								<option value="<?php echo esc_attr( $groundwork_subject ); ?>" <?php selected( $groundwork_value, $groundwork_subject ); ?>><?php echo esc_html( $groundwork_subject ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php else : ?>
						<input
							class="gw-field__control"
							type="<?php echo esc_attr( $groundwork_field['type'] ); ?>"
							id="<?php echo esc_attr( $groundwork_input_id ); ?>"
							name="<?php echo esc_attr( $groundwork_name ); ?>"
							value="<?php echo esc_attr( $groundwork_value ); ?>"
							autocomplete="<?php echo esc_attr( $groundwork_field['autocomplete'] ); ?>"
							maxlength="<?php echo esc_attr( $groundwork_labels[ $groundwork_name ]['max'] ); ?>"
							aria-describedby="<?php echo esc_attr( $groundwork_error_id ); ?>"
							<?php echo $groundwork_required ? 'required' : ''; ?>
							<?php echo $groundwork_error ? 'aria-invalid="true"' : ''; ?>
						/>
					<?php endif; ?>

					<p class="gw-field__error" id="<?php echo esc_attr( $groundwork_error_id ); ?>" data-error-for="<?php echo esc_attr( $groundwork_name ); ?>"<?php echo '' === $groundwork_error ? ' hidden' : ''; ?>><?php echo esc_html( $groundwork_error ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="gw-contact-form__trap" aria-hidden="true">
			<label for="<?php echo esc_attr( $groundwork_id ); ?>-website"><?php esc_html_e( 'Leave this field empty', 'groundwork' ); ?></label>
			<input type="text" id="<?php echo esc_attr( $groundwork_id ); ?>-website" name="website" value="" tabindex="-1" autocomplete="off" />
		</div>

		<input type="hidden" name="action" value="<?php echo esc_attr( \Groundwork\Contact_Form::ACTION ); ?>" />
		<input type="hidden" name="_gw_nonce" value="<?php echo esc_attr( wp_create_nonce( \Groundwork\Contact_Form::ACTION ) ); ?>" />
		<input type="hidden" name="_gw_ts" value="<?php echo esc_attr( \Groundwork\Contact_Form::create_timestamp() ); ?>" />
		<input type="hidden" name="_gw_source" value="<?php echo esc_url( $groundwork_source ); ?>" />
		<input type="hidden" name="_gw_anchor" value="<?php echo esc_attr( $groundwork_id ); ?>" />

		<div class="gw-contact-form__footer">
			<button type="submit" class="gw-contact-form__submit wp-element-button"><?php echo esc_html( $groundwork_button ); ?></button>

			<?php if ( $groundwork_privacy ) : ?>
				<p class="gw-contact-form__privacy">
					<?php
					printf(
						/* translators: %s: link to the privacy policy page. */
						esc_html__( 'We use your details only to reply to you. %s', 'groundwork' ),
						wp_kses_post( $groundwork_privacy )
					);
					?>
				</p>
			<?php endif; ?>
		</div>
	</form>
</div>
