/**
 * "Project details" and "Testimonial details" panels in the editor sidebar.
 *
 * The fields are post meta registered in includes/class-meta.php, which
 * sanitises them on save and only lets people who can edit the post
 * change them.
 */
import { __ } from '@wordpress/i18n';
import { registerPlugin } from '@wordpress/plugins';
import {
	PluginDocumentSettingPanel,
	store as editorStore,
} from '@wordpress/editor';
import { SelectControl, TextControl } from '@wordpress/components';
import { useSelect } from '@wordpress/data';
import { useEntityProp } from '@wordpress/core-data';

/**
 * Fields shown for each post type.
 *
 * @return {Object} Panel title and fields, keyed by post type.
 */
function getPanels() {
	return {
		gw_project: {
			title: __( 'Project details', 'groundwork' ),
			fields: [
				{
					key: '_gw_client',
					label: __( 'Client', 'groundwork' ),
					help: __(
						'Leave empty if the client should stay confidential.',
						'groundwork'
					),
				},
				{
					key: '_gw_location',
					label: __( 'Location', 'groundwork' ),
					placeholder: __(
						'Trans-Amadi, Port Harcourt',
						'groundwork'
					),
				},
				{
					key: '_gw_year',
					label: __( 'Year', 'groundwork' ),
					placeholder: '2025',
				},
				{
					key: '_gw_scope',
					label: __( 'Scope', 'groundwork' ),
					placeholder: __( 'Design and build', 'groundwork' ),
				},
				{
					key: '_gw_duration',
					label: __( 'Duration', 'groundwork' ),
					placeholder: __( '14 months', 'groundwork' ),
				},
				{
					key: '_gw_status',
					label: __( 'Status', 'groundwork' ),
					options: [
						{
							label: __( 'Completed', 'groundwork' ),
							value: 'completed',
						},
						{
							label: __( 'In progress', 'groundwork' ),
							value: 'in-progress',
						},
						{
							label: __( 'In design', 'groundwork' ),
							value: 'design',
						},
					],
				},
			],
		},
		gw_testimonial: {
			title: __( 'Testimonial details', 'groundwork' ),
			fields: [
				{
					key: '_gw_role',
					label: __( 'Role', 'groundwork' ),
					placeholder: __( 'Facilities manager', 'groundwork' ),
				},
				{
					key: '_gw_organisation',
					label: __( 'Organisation', 'groundwork' ),
				},
			],
		},
	};
}

function DetailsPanel() {
	const { postType, postId } = useSelect(
		( select ) => ( {
			postType: select( editorStore ).getCurrentPostType(),
			postId: select( editorStore ).getCurrentPostId(),
		} ),
		[]
	);
	const [ meta, setMeta ] = useEntityProp(
		'postType',
		postType,
		'meta',
		postId
	);
	const panel = getPanels()[ postType ];

	if ( ! panel || ! meta ) {
		return null;
	}

	const update = ( key ) => ( value ) =>
		setMeta( { ...meta, [ key ]: value } );

	return (
		<PluginDocumentSettingPanel
			name="groundwork-details"
			title={ panel.title }
			className="groundwork-details-panel"
		>
			<div style={ { display: 'grid', gap: '16px' } }>
				{ panel.fields.map( ( field ) =>
					field.options ? (
						<SelectControl
							key={ field.key }
							__next40pxDefaultSize
							__nextHasNoMarginBottom
							label={ field.label }
							value={
								meta[ field.key ] || field.options[ 0 ].value
							}
							options={ field.options }
							onChange={ update( field.key ) }
						/>
					) : (
						<TextControl
							key={ field.key }
							__next40pxDefaultSize
							__nextHasNoMarginBottom
							label={ field.label }
							help={ field.help }
							placeholder={ field.placeholder }
							value={ meta[ field.key ] || '' }
							onChange={ update( field.key ) }
						/>
					)
				) }
			</div>
		</PluginDocumentSettingPanel>
	);
}

registerPlugin( 'groundwork-details', { render: DetailsPanel } );
