<?php
/**
 * Front-end markup for the Project grid block.
 *
 * @package Groundwork
 *
 * @var array    $attributes Block attributes.
 * @var string   $content    Block content.
 * @var WP_Block $block      Block instance.
 */

defined( 'ABSPATH' ) || exit;

$groundwork_orderby = in_array( $attributes['orderBy'], array( 'date', 'menu_order', 'title' ), true ) ? $attributes['orderBy'] : 'date';

$groundwork_query_args = array(
	'post_type'           => 'gw_project',
	'post_status'         => 'publish',
	'posts_per_page'      => max( 1, min( 12, (int) $attributes['number'] ) ),
	'orderby'             => $groundwork_orderby,
	'order'               => 'date' === $groundwork_orderby ? 'DESC' : 'ASC',
	'ignore_sticky_posts' => true,
	'no_found_rows'       => true,
);

if ( '' !== $attributes['projectType'] ) {
	// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One term filter on an indexed relationship table.
	$groundwork_query_args['tax_query'] = array(
		array(
			'taxonomy' => 'gw_project_type',
			'field'    => 'slug',
			'terms'    => sanitize_title( $attributes['projectType'] ),
		),
	);
}

$groundwork_projects = new WP_Query( $groundwork_query_args );

if ( ! $groundwork_projects->have_posts() ) {
	return;
}

$groundwork_columns = max( 1, min( 4, (int) $attributes['columns'] ) );
?>
<div <?php echo wp_kses_data( get_block_wrapper_attributes( array( 'style' => '--gw-columns:' . $groundwork_columns ) ) ); ?>>
	<ul class="gw-project-grid" role="list">
		<?php
		while ( $groundwork_projects->have_posts() ) :
			$groundwork_projects->the_post();

			$groundwork_details = groundwork_get_project_details();
			$groundwork_types   = get_the_terms( get_the_ID(), 'gw_project_type' );
			$groundwork_meta    = array_filter(
				array(
					isset( $groundwork_details['location'] ) ? $groundwork_details['location']['value'] : '',
					isset( $groundwork_details['year'] ) ? $groundwork_details['year']['value'] : '',
				)
			);
			?>
			<li class="gw-project-card">
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="gw-project-card__media">
						<?php the_post_thumbnail( 'medium_large', array( 'alt' => '' ) ); ?>
					</div>
				<?php endif; ?>

				<div class="gw-project-card__body">
					<?php if ( $groundwork_types && ! is_wp_error( $groundwork_types ) ) : ?>
						<p class="gw-project-card__type"><?php echo esc_html( $groundwork_types[0]->name ); ?></p>
					<?php endif; ?>

					<h3 class="gw-project-card__title">
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					</h3>

					<?php if ( $attributes['showDetails'] && $groundwork_meta ) : ?>
						<p class="gw-project-card__meta">
							<?php foreach ( $groundwork_meta as $groundwork_item ) : ?>
								<span><?php echo esc_html( $groundwork_item ); ?></span>
							<?php endforeach; ?>
						</p>
					<?php endif; ?>

					<?php if ( $attributes['showExcerpt'] && has_excerpt() ) : ?>
						<p class="gw-project-card__summary"><?php echo esc_html( get_the_excerpt() ); ?></p>
					<?php endif; ?>
				</div>
			</li>
		<?php endwhile; ?>
	</ul>
</div>
<?php
wp_reset_postdata();
