/**
 * Editor interface for the Project grid block.
 */
import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import {
	PanelBody,
	RangeControl,
	SelectControl,
	ToggleControl,
} from '@wordpress/components';
import { useSelect } from '@wordpress/data';
import { store as coreStore } from '@wordpress/core-data';

import ServerPreview from '../shared/server-preview';
import { projectGridIcon } from '../shared/icons';

const ORDER_OPTIONS = [
	{ label: __( 'Newest first', 'groundwork' ), value: 'date' },
	{ label: __( 'Custom order', 'groundwork' ), value: 'menu_order' },
	{ label: __( 'Name, A to Z', 'groundwork' ), value: 'title' },
];

export default function Edit( { attributes, setAttributes } ) {
	const { number, columns, projectType, orderBy, showDetails, showExcerpt } =
		attributes;

	const projectTypes = useSelect(
		( select ) =>
			select( coreStore ).getEntityRecords(
				'taxonomy',
				'gw_project_type',
				{ per_page: 100, _fields: 'id,name,slug' }
			),
		[]
	);

	const typeOptions = [
		{ label: __( 'All project types', 'groundwork' ), value: '' },
		...( projectTypes ?? [] ).map( ( term ) => ( {
			label: term.name,
			value: term.slug,
		} ) ),
	];

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Projects to show', 'groundwork' ) }>
					<RangeControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={ __( 'Number of projects', 'groundwork' ) }
						value={ number }
						onChange={ ( value ) =>
							setAttributes( { number: value } )
						}
						min={ 1 }
						max={ 12 }
					/>
					<RangeControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={ __( 'Columns', 'groundwork' ) }
						help={ __(
							'On narrow screens the cards stack into fewer columns.',
							'groundwork'
						) }
						value={ columns }
						onChange={ ( value ) =>
							setAttributes( { columns: value } )
						}
						min={ 1 }
						max={ 4 }
					/>
					<SelectControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={ __( 'Project type', 'groundwork' ) }
						value={ projectType }
						options={ typeOptions }
						onChange={ ( value ) =>
							setAttributes( { projectType: value } )
						}
					/>
					<SelectControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={ __( 'Order', 'groundwork' ) }
						value={ orderBy }
						options={ ORDER_OPTIONS }
						onChange={ ( value ) =>
							setAttributes( { orderBy: value } )
						}
					/>
				</PanelBody>
				<PanelBody title={ __( 'Card content', 'groundwork' ) }>
					<ToggleControl
						__nextHasNoMarginBottom
						label={ __( 'Show location and year', 'groundwork' ) }
						checked={ showDetails }
						onChange={ ( value ) =>
							setAttributes( { showDetails: value } )
						}
					/>
					<ToggleControl
						__nextHasNoMarginBottom
						label={ __( 'Show summary', 'groundwork' ) }
						help={ __(
							'Uses the excerpt written for each project.',
							'groundwork'
						) }
						checked={ showExcerpt }
						onChange={ ( value ) =>
							setAttributes( { showExcerpt: value } )
						}
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<ServerPreview
					block="groundwork/project-grid"
					attributes={ attributes }
					icon={ projectGridIcon }
					label={ __( 'Project grid', 'groundwork' ) }
					instructions={ __(
						'No published projects match these settings yet. Add one under Projects in the dashboard menu.',
						'groundwork'
					) }
				/>
			</div>
		</>
	);
}
