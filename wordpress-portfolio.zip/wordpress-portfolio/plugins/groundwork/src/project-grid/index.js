/**
 * Project grid block.
 */
import { registerBlockType } from '@wordpress/blocks';

import metadata from './block.json';
import Edit from './edit';
import { projectGridIcon } from '../shared/icons';
import './style.scss';
import './editor.scss';

registerBlockType( metadata.name, {
	icon: projectGridIcon,
	edit: Edit,
} );
