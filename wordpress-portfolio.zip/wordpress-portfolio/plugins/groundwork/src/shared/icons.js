/**
 * Block icons, drawn on the 24px grid used by WordPress icons.
 */
import { SVG, Path } from '@wordpress/primitives';

export const projectGridIcon = (
	<SVG xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
		<Path d="M4 4h7v7H4V4Zm1.5 1.5v4h4v-4h-4ZM13 4h7v7h-7V4Zm1.5 1.5v4h4v-4h-4ZM4 13h7v7H4v-7Zm1.5 1.5v4h4v-4h-4ZM13 13h7v7h-7v-7Z" />
	</SVG>
);

export const testimonialsIcon = (
	<SVG xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
		<Path d="M4 6h6v6.5c0 3-1.6 5-4.6 5.5l-.4-1.5c1.6-.5 2.5-1.6 2.5-3H4V6Zm10 0h6v6.5c0 3-1.6 5-4.6 5.5l-.4-1.5c1.6-.5 2.5-1.6 2.5-3H14V6Z" />
	</SVG>
);

export const contactFormIcon = (
	<SVG xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
		<Path d="M4 5h16v14H4V5Zm1.5 1.5v1.2L12 12l6.5-4.3V6.5h-13Zm13 2.98L12 13.8 5.5 9.48v8.02h13V9.48Z" />
	</SVG>
);
