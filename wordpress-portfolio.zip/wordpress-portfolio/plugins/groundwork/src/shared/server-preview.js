/**
 * Live preview of a dynamic block, rendered by its render.php on the server.
 */
import ServerSideRender from '@wordpress/server-side-render';
import { Disabled, Placeholder } from '@wordpress/components';

/**
 * Block support attributes are already applied to the editor wrapper by
 * useBlockProps(), so they are left out of the request. Otherwise colours,
 * spacing and extra classes would be applied twice in the editor.
 */
const WRAPPER_ATTRIBUTES = [
	'align',
	'backgroundColor',
	'className',
	'style',
	'textColor',
];

/**
 * @param {Object}  props
 * @param {string}  props.block        Block name.
 * @param {Object}  props.attributes   Block attributes.
 * @param {Element} props.icon         Icon shown in the empty state.
 * @param {string}  props.label        Block title shown in the empty state.
 * @param {string}  props.instructions What to do when there is nothing to show.
 */
export default function ServerPreview( {
	block,
	attributes,
	icon,
	label,
	instructions,
} ) {
	const previewAttributes = Object.fromEntries(
		Object.entries( attributes ).filter(
			( [ name ] ) => ! WRAPPER_ATTRIBUTES.includes( name )
		)
	);

	return (
		<Disabled>
			<ServerSideRender
				block={ block }
				attributes={ previewAttributes }
				EmptyResponsePlaceholder={ () => (
					<Placeholder
						icon={ icon }
						label={ label }
						instructions={ instructions }
					/>
				) }
			/>
		</Disabled>
	);
}
