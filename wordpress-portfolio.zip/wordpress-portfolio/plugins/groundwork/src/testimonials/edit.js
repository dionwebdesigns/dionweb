/**
 * Editor interface for the Testimonials block.
 */
import { __ } from '@wordpress/i18n';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, RangeControl } from '@wordpress/components';

import ServerPreview from '../shared/server-preview';
import { testimonialsIcon } from '../shared/icons';

export default function Edit( { attributes, setAttributes } ) {
	const { number, columns } = attributes;

	return (
		<>
			<InspectorControls>
				<PanelBody title={ __( 'Testimonials to show', 'groundwork' ) }>
					<RangeControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={ __( 'Number of testimonials', 'groundwork' ) }
						help={ __(
							'Ordered by the Order value set on each testimonial.',
							'groundwork'
						) }
						value={ number }
						onChange={ ( value ) =>
							setAttributes( { number: value } )
						}
						min={ 1 }
						max={ 6 }
					/>
					<RangeControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={ __( 'Columns', 'groundwork' ) }
						value={ columns }
						onChange={ ( value ) =>
							setAttributes( { columns: value } )
						}
						min={ 1 }
						max={ 3 }
					/>
				</PanelBody>
			</InspectorControls>
			<div { ...useBlockProps() }>
				<ServerPreview
					block="groundwork/testimonials"
					attributes={ attributes }
					icon={ testimonialsIcon }
					label={ __( 'Testimonials', 'groundwork' ) }
					instructions={ __(
						'No testimonials yet. Add one under Testimonials in the dashboard menu.',
						'groundwork'
					) }
				/>
			</div>
		</>
	);
}
