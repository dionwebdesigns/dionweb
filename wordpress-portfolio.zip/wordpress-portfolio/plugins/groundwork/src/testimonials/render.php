<?php
/**
 * Front-end markup for the Testimonials block.
 *
 * @package Groundwork
 *
 * @var array    $attributes Block attributes.
 * @var string   $content    Block content.
 * @var WP_Block $block      Block instance.
 */

defined( 'ABSPATH' ) || exit;

$groundwork_testimonials = new WP_Query(
	array(
		'post_type'           => 'gw_testimonial',
		'post_status'         => 'publish',
		'posts_per_page'      => max( 1, min( 6, (int) $attributes['number'] ) ),
		'orderby'             => array(
			'menu_order' => 'ASC',
			'date'       => 'DESC',
		),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);

if ( ! $groundwork_testimonials->have_posts() ) {
	return;
}

$groundwork_columns = max( 1, min( 3, (int) $attributes['columns'] ) );
?>
<div <?php echo wp_kses_data( get_block_wrapper_attributes( array( 'style' => '--gw-columns:' . $groundwork_columns ) ) ); ?>>
	<?php
	while ( $groundwork_testimonials->have_posts() ) :
		$groundwork_testimonials->the_post();

		$groundwork_person = groundwork_get_testimonial_details();
		$groundwork_role   = implode( ', ', array_filter( array( $groundwork_person['role'], $groundwork_person['organisation'] ) ) );
		?>
		<figure class="gw-testimonial">
			<blockquote class="gw-testimonial__quote">
				<?php echo wp_kses_post( wpautop( wp_strip_all_tags( get_the_content() ) ) ); ?>
			</blockquote>
			<figcaption class="gw-testimonial__source">
				<?php if ( has_post_thumbnail() ) : ?>
					<?php
					the_post_thumbnail(
						'thumbnail',
						array(
							'class' => 'gw-testimonial__photo',
							'alt'   => '',
						)
					);
					?>
				<?php endif; ?>
				<span class="gw-testimonial__name"><?php echo esc_html( $groundwork_person['name'] ); ?></span>
				<?php if ( $groundwork_role ) : ?>
					<span class="gw-testimonial__role"><?php echo esc_html( $groundwork_role ); ?></span>
				<?php endif; ?>
			</figcaption>
		</figure>
	<?php endwhile; ?>
</div>
<?php
wp_reset_postdata();
