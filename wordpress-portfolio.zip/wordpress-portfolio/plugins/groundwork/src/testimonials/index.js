/**
 * Testimonials block.
 */
import { registerBlockType } from '@wordpress/blocks';

import metadata from './block.json';
import Edit from './edit';
import { testimonialsIcon } from '../shared/icons';
import './style.scss';

registerBlockType( metadata.name, {
	icon: testimonialsIcon,
	edit: Edit,
} );
